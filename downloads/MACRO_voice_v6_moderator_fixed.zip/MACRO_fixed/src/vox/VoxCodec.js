const crypto = require('crypto');
const path = require('path');
const { createRequire } = require('module');
const { loadedFrom } = require('../KakaoForgeLoader').loadKakaoForge();
const BSON = createRequire(path.join(loadedFrom, '__macro_resolve__.js'))('bson');
// Public IV from the 25.11.2 VOX framing implementation, not a user session key.
const IV = Buffer.from('6d10dd11ba3761c9771e22f36e10c19d', 'hex');
const HEADER = 12, MAX_ENCRYPTED = 102400;
function integer(value, max, name) {
  if (!Number.isInteger(value) || value < 0 || value > max) throw new Error(`잘못된 VOX ${name}`);
}
function requireCipher() {
  if (!crypto.getCiphers().includes('seed-cbc')) throw new Error('VOX에는 SEED-CBC가 필요합니다. node --openssl-legacy-provider로 실행하세요.');
}
function encodeRaw(sequence, command, body, field12 = 0) {
  integer(sequence, 0xffffffff, 'sequence'); integer(command, 65535, 'command'); integer(field12, 65535, 'header');
  if (!Buffer.isBuffer(body) || body.length < 5 || body.readInt32LE(0) !== body.length || body.at(-1) !== 0) throw new Error('VOX 본문은 완전한 BSON 문서여야 합니다.');
  const size = (Math.floor(body.length / 16) + 1) * 16;
  if (size > MAX_ENCRYPTED) throw new Error('VOX 본문 크기를 초과했습니다.');
  requireCipher();
  const header = Buffer.alloc(HEADER);
  header.writeUInt32LE(sequence, 0); header.writeUInt16LE(field12, 4); header.writeUInt16LE(command, 6); header.writeUInt32LE(size, 8);
  const key = crypto.createHash('md5').update(header.subarray(0, 8)).digest();
  const cipher = crypto.createCipheriv('seed-cbc', key, IV);
  return Buffer.concat([header, cipher.update(body), cipher.final()]);
}
function encode(sequence, command, body, field12 = 0) { return encodeRaw(sequence, command, BSON.serialize(body), field12); }
function decode(frame) {
  if (frame.length < HEADER) throw new Error('불완전한 VOX 헤더');
  const size = frame.readUInt32LE(8);
  if (!size || size % 16 || size > MAX_ENCRYPTED || frame.length !== HEADER + size) throw new Error('잘못된 VOX 프레임 길이');
  requireCipher();
  const key = crypto.createHash('md5').update(frame.subarray(0, 8)).digest();
  const cipher = crypto.createDecipheriv('seed-cbc', key, IV);
  let raw;
  try { raw = Buffer.concat([cipher.update(frame.subarray(HEADER)), cipher.final()]); }
  catch { throw new Error('VOX 본문 복호화/패딩 검증 실패'); }
  if (raw.length < 5 || raw.readInt32LE(0) !== raw.length || raw.at(-1) !== 0) throw new Error('VOX BSON 길이 검증 실패');
  return { sequence: frame.readUInt32LE(0), field12: frame.readUInt16LE(4), command: frame.readUInt16LE(6), body: BSON.deserialize(raw, { promoteLongs: false }) };
}
class Decoder {
  constructor() { this.buffer = Buffer.alloc(0); }
  feed(chunk) {
    if (!Buffer.isBuffer(chunk) || chunk.length > 4 * 1024 * 1024) throw new Error('VOX 수신 청크 크기 초과');
    this.buffer = Buffer.concat([this.buffer, chunk]); const result = [];
    while (this.buffer.length >= HEADER) {
      const size = this.buffer.readUInt32LE(8);
      if (!size || size % 16 || size > MAX_ENCRYPTED) { this.buffer = Buffer.alloc(0); throw new Error('VOX 수신 프레임 길이 오류'); }
      if (this.buffer.length < HEADER + size) break;
      result.push(decode(this.buffer.subarray(0, HEADER + size))); this.buffer = this.buffer.subarray(HEADER + size);
    }
    return result;
  }
}
module.exports = { BSON, encodeRaw, encode, decode, Decoder, HEADER, MAX_ENCRYPTED };
