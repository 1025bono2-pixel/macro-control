const tls = require('tls');
const crypto = require('crypto');
const { EventEmitter } = require('events');
const { encode, Decoder } = require('./VoxCodec');
class VoxConnection extends EventEmitter {
  constructor(options = {}) {
    super(); this.options = options; this.pending = new Map(); this.decoder = new Decoder(); this.socket = null;
    this.on('error', () => {});
  }
  async connect({ host, port, servername = host }) {
    if (this.socket) throw new Error('VOX 연결이 이미 열려 있습니다.');
    if (!host || !servername || !Number.isInteger(port) || port < 1 || port > 65535) throw new Error('VOX 서버 주소가 잘못되었습니다.');
    const socket = (this.options.connect || tls.connect)({ host, port, servername, rejectUnauthorized: true });
    this.socket = socket;
    socket.on('data', chunk => {
      try { for (const packet of this.decoder.feed(chunk)) this.onPacket(packet); }
      catch { this.fail(new Error('VOX 응답 해석에 실패했습니다.')); }
    });
    socket.on('error', () => this.fail(new Error('VOX 연결 오류')));
    socket.on('close', () => { this.rejectPending(new Error('VOX 연결이 종료됐습니다.')); this.emit('disconnected'); });
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { socket.destroy(); reject(new Error('VOX 연결 시간 초과')); }, 10000);
      socket.once('secureConnect', () => { clearTimeout(timer); socket.setKeepAlive?.(true, 30000); resolve(); });
      socket.once('error', () => { clearTimeout(timer); reject(new Error('VOX TLS 인증/연결 실패')); });
      socket.once('close', () => { clearTimeout(timer); reject(new Error('VOX 연결이 닫혔습니다.')); });
    });
  }
  onPacket(packet) {
    const pending = this.pending.get(packet.sequence);
    if (pending && pending.command === packet.command) {
      clearTimeout(pending.timer); this.pending.delete(packet.sequence); pending.resolve(packet);
    } else this.emit('push', packet);
  }
  send(sequence, command, body, field12 = 0) {
    if (!this.socket || this.socket.destroyed) throw new Error('VOX 서버에 연결되지 않았습니다.');
    this.socket.write(encode(sequence, command, body, field12));
  }
  request(command, body, timeout = 15000) {
    let sequence; do { sequence = crypto.randomInt(1, 0x7fffffff); } while (this.pending.has(sequence));
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(sequence);
        reject(Object.assign(new Error('VOX 응답 시간 초과. 서버 처리 결과는 미확인입니다. 자동 재시도하지 않습니다.'), { code: 'VOX_REQUEST_TIMEOUT' }));
      }, timeout);
      this.pending.set(sequence, { command, resolve, reject, timer });
      try { this.send(sequence, command, body); } catch (e) { clearTimeout(timer); this.pending.delete(sequence); reject(e); }
    });
  }
  rejectPending(error) { for (const p of this.pending.values()) { clearTimeout(p.timer); p.reject(error); } this.pending.clear(); }
  fail(error) { this.rejectPending(error); this.emit('error', error); this.socket?.destroy(); }
  close() { this.rejectPending(new Error('VOX 연결을 닫았습니다.')); this.socket?.destroy(); this.socket = null; }
}
module.exports = VoxConnection;
