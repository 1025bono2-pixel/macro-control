'use strict';

const { kakaoId: userId, senderId } = require('./KakaoIdentity');
const { createRequire } = require('node:module');
let parseLossless;
const isIdCommand = text => typeof text === 'string' && /^!id(?:\s|$)/i.test(text.trim());

function decode(value) {
  if (typeof value !== 'string') return value;
  if (!parseLossless) {
    const { loadedFrom } = require('./KakaoForgeLoader').loadKakaoForge();
    parseLossless = createRequire(require.resolve(loadedFrom))('lossless-json').parse;
  }
  try { return parseLossless(value, null, number => number); } catch { return null; }
}

function attachments(msg) {
  const chatLog = msg.raw?.chatLog ?? msg.raw;
  // KakaoForge's attachmentsRaw may already contain rounded JSON numbers.
  const raw = chatLog?.attachment ?? chatLog?.attachments ?? chatLog?.extra ?? msg.attachmentsRaw;
  const value = decode(raw);
  return (Array.isArray(value) ? value : value ? [value] : [])
    .map(decode).filter(value => value && typeof value === 'object');
}

async function handleIdCommand(client, chat, msg) {
  const text = String(msg?.message?.text ?? msg?.text ?? '').trim();
  if (!isIdCommand(text)) return false;
  const sender = senderId(msg);
  if (sender && sender === userId(client.userId)) return true;
  const roomId = userId(msg?.room?.id ?? msg?.chatId ?? chat?.id);
  if (!roomId) return true;
  const extra = attachments(msg);
  const hasArgument = text.replace(/^!id/i, '').trim().length > 0;
  // A typed nickname is not proof of a mention. Use server-supplied metadata.
  const mentions = extra.flatMap(item => Array.isArray(item.mentions) ? item.mentions : []);
  const ids = [...new Set(mentions.map(item => userId(item.user_id ?? item.userId)).filter(Boolean))];
  let response;
  if (hasArgument) {
    response = ids.length ? ids.map(id => `사용자 ID: ${id}`).join('\n') : '사용자를 실제로 멘션하여 !id @멘션 으로 입력해 주세요.';
  } else {
    const reply = extra.find(item => Object.hasOwn(item, 'src_userId'));
    const isReply = Number(msg.message?.type ?? msg.type) === 26;
    const id = reply ? userId(reply.src_userId) : isReply ? null : sender;
    response = id ? `사용자 ID: ${id}` : '사용자 ID를 확인할 수 없습니다.';
  }
  // Reply to the command itself when the client supports Kakao reply messages.
  if (typeof client.sendReply === 'function' && sender && (msg.message?.logId ?? msg.logId)) {
    const replyEvent = String(msg.sender?.id ?? msg.senderId) === sender ? msg
      : { ...msg, sender: { ...msg.sender, id: sender }, senderId: sender };
    await client.sendReply(roomId, response, replyEvent);
  } else {
    await client.sendText(roomId, response);
  }
  return true;
}

module.exports = { handleIdCommand, isIdCommand };
