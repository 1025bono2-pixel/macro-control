const fs=require("fs"), path=require("path");
const ROOT=require("../DataPaths").ACCOUNTS;
const safe=v=>String(v??"unknown").replace(/[^a-zA-Z0-9._-]/g,"_");
const day=(ts=Date.now())=>new Date(ts).toISOString().slice(0,10);
function json(v){const seen=new WeakSet();return JSON.stringify(v,(_,x)=>{if(typeof x==="bigint")return x.toString();if(x&&typeof x==="object"&&typeof x.toString==="function"&&/Long/.test(x.constructor?.name||""))return x.toString();if(x&&typeof x==="object"){if(seen.has(x))return "[Circular]";seen.add(x);}return x;});}
function readJson(p,d={}){try{return JSON.parse(fs.readFileSync(p,"utf8"));}catch{return d;}}
function readJsonl(p,limit=200){try{const lines=fs.readFileSync(p,"utf8").trim().split(/\r?\n/).filter(Boolean);return lines.slice(-limit).map(x=>{try{return JSON.parse(x)}catch{return null}}).filter(Boolean)}catch{return[]}}
function readDirJsonl(dir,limit=500){if(!fs.existsSync(dir))return[];let out=[];for(const f of fs.readdirSync(dir).filter(x=>x.endsWith('.jsonl')).sort())out=out.concat(readJsonl(path.join(dir,f),limit));return out.slice(-limit).reverse();}
class ArchiveStore{
 constructor(account){this.base=path.join(ROOT,safe(account));this.recentOutgoing=[];}
 roomId(chat,msg){const v=msg?.room?.id??msg?.room?.roomId??msg?.room?.chatId??msg?.room?.channelId??chat?.id??chat?.channelId??msg?.chatId??msg?.raw?.chatLog?.chatId??"unknown";return typeof v?.toString==="function"?v.toString():String(v);}
 append(roomId,folder,data){const dir=path.join(this.base,"rooms",safe(roomId),folder);fs.mkdirSync(dir,{recursive:true});fs.appendFileSync(path.join(dir,`${day()}.jsonl`),json({savedAt:new Date().toISOString(),...data})+"\n");}
 markOutgoing(roomId,kind,data={}){const x={at:Date.now(),roomId:String(roomId),kind:String(kind||''),text:String(data.text||'')};this.recentOutgoing=this.recentOutgoing.filter(v=>Date.now()-v.at<15000);this.recentOutgoing.push(x);}
 isRecentOutgoing(roomId,text){this.recentOutgoing=this.recentOutgoing.filter(v=>Date.now()-v.at<15000);const i=this.recentOutgoing.findIndex(v=>v.roomId===String(roomId)&&(!text||!v.text||v.text===String(text)));if(i<0)return false;this.recentOutgoing.splice(i,1);return true;}
 incoming(chat,msg,ownUserId=''){const roomId=this.roomId(chat,msg),senderId=String(msg?.sender?.id??msg?.senderId??''),text=msg?.message?.text??msg?.text??'',isSelf=!!ownUserId&&senderId===String(ownUserId);if(isSelf&&this.isRecentOutgoing(roomId,text))return {skippedDuplicate:true,direction:'SENT'};const direction=isSelf?'SENT':'RECEIVED';this.append(roomId,"messages",{direction,source:isSelf?'SERVER_SELF_EVENT':'SERVER_EVENT',roomId,messageId:String(msg?.id??msg?.logId??msg?.raw?.chatLog?.logId??""),senderId,senderName:String(msg?.sender?.name??msg?.sender?.nickname??""),text,messageType:msg?.raw?.chatLog?.type??msg?.type??null,attachment:msg?.raw?.chatLog?.attachment??msg?.message?.attachment??null});return{direction};}
 outgoing(roomId,kind,data={}){this.markOutgoing(roomId,kind,data);this.append(roomId,"messages",{direction:"SENT",roomId:String(roomId),kind,source:data.source||'LOCAL_SEND',...data});}
 event(roomId,name,payload){this.append(roomId,"events",{event:name,payload});}
 log(name,payload){const dir=path.join(this.base,"logs");fs.mkdirSync(dir,{recursive:true});fs.appendFileSync(path.join(dir,`${safe(name)}.jsonl`),json({at:new Date().toISOString(),...payload})+"\n");}
 summary(){const root=path.join(this.base,"rooms");if(!fs.existsSync(root))return{rooms:[],totals:{received:0,sent:0,total:0}};let received=0,sent=0;const rooms=[];for(const d of fs.readdirSync(root,{withFileTypes:true}).filter(x=>x.isDirectory())){const rp=path.join(root,d.name),meta=readJson(path.join(rp,"room.json"),{roomId:d.name,roomName:'이름 확인 중'}),mp=path.join(rp,"messages");let rr=0,ss=0,latest=[];if(fs.existsSync(mp)){for(const f of fs.readdirSync(mp).filter(x=>x.endsWith('.jsonl')).sort()){const rows=readJsonl(path.join(mp,f),100000);for(const x of rows){if(x.direction==='RECEIVED')rr++;else if(x.direction==='SENT')ss++;}latest=latest.concat(rows).slice(-200);}}received+=rr;sent+=ss;rooms.push({...meta,received:rr,sent:ss,total:rr+ss,latest:latest.slice(-100).reverse(),events:readDirJsonl(path.join(rp,'events'),100)});}rooms.sort((a,b)=>String(a.roomName).localeCompare(String(b.roomName),'ko'));return{rooms,totals:{received,sent,total:received+sent}};}
 resetDetail(){
  const rooms=path.join(this.base,'rooms');
  if(fs.existsSync(rooms))for(const d of fs.readdirSync(rooms,{withFileTypes:true})){
   if(!d.isDirectory())continue;
   for(const sub of ['messages','events']){const x=path.join(rooms,d.name,sub);if(fs.existsSync(x))fs.rmSync(x,{recursive:true,force:true});}
   const meta=path.join(rooms,d.name,'room.json');if(fs.existsSync(meta))fs.rmSync(meta,{force:true});
  }
  const logs=path.join(this.base,'logs');if(fs.existsSync(logs))fs.rmSync(logs,{recursive:true,force:true});
  this.recentOutgoing=[];
  return{ok:true};
 }
 detail(){const summary=this.summary(),logs={};const lp=path.join(this.base,'logs');if(fs.existsSync(lp))for(const f of fs.readdirSync(lp).filter(x=>x.endsWith('.jsonl')))logs[path.basename(f,'.jsonl')]=readJsonl(path.join(lp,f),300).reverse();return{...summary,logs};}
}
module.exports=ArchiveStore;
