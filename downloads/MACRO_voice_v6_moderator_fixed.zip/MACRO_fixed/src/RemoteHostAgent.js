const http = require('http');
const { WebSocket } = require('ws');

class RemoteHostAgent {
  constructor(opts = {}) {
    this.remoteUrl = String(opts.remoteUrl || process.env.MACRO_REMOTE_URL || 'https://macro-control.onrender.com').replace(/\/$/, '');
    this.secret = String(opts.secret || process.env.MACRO_HOST_SECRET || '');
    this.localPort = Number(opts.localPort || process.env.MACRO_PORT || 8787);
    this.ws = null;
    this.timer = null;
    this.heartbeat = null;
    this.stopped = false;
  }

  start() {
    if (!this.secret) {
      console.log('[REMOTE] MACRO_HOST_SECRET가 없어 원격 연결을 건너뜁니다.');
      return;
    }
    this.stopped = false;
    this.connect();
  }

  connect() {
    if (this.stopped) return;
    const wsUrl = this.remoteUrl.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:') + '/host';
    console.log('[REMOTE] Render 연결 중: ' + this.remoteUrl);
    const ws = new WebSocket(wsUrl, {
      headers: { Authorization: `Bearer ${this.secret}` },
      handshakeTimeout: 15000
    });
    this.ws = ws;

    ws.on('open', () => {
      console.log('[REMOTE] WebSocket 연결됨 - 서버 인증 확인 중');
      clearInterval(this.heartbeat);
      this.heartbeat = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          try { ws.ping(); } catch {}
        }
      }, 20000);
    });
    ws.on('message', raw => this.onMessage(raw));
    ws.on('unexpected-response', (_req, res) => console.error('[REMOTE] 서버 HTTP 응답:', res.statusCode));
    ws.on('close', (code, reason) => {
      clearInterval(this.heartbeat); this.heartbeat = null;
      console.log(`[REMOTE] 연결 종료 code=${code} reason=${String(reason || '')} - 5초 후 재연결`);
      this.scheduleReconnect();
    });
    ws.on('error', e => console.error('[REMOTE]', e.message));
  }

  scheduleReconnect() {
    if (this.stopped || this.timer) return;
    this.timer = setTimeout(() => { this.timer = null; this.connect(); }, 5000);
  }

  async onMessage(raw) {
    let msg;
    try { msg = JSON.parse(String(raw)); } catch { return; }
    if (msg.type === 'host.ready') {
      console.log('[REMOTE] Render 인증/연결 완료');
      return;
    }
    if (msg.type !== 'proxy.http' || !msg.requestId) return;
    try {
      const result = await this.proxy(msg.payload || {});
      this.send({ requestId: msg.requestId, ok: true, result });
    } catch (e) {
      this.send({ requestId: msg.requestId, ok: false, error: e.message });
    }
  }

  send(obj) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(obj));
  }

  proxy(p) {
    return new Promise((resolve, reject) => {
      const headers = { ...(p.headers || {}) };
      delete headers.host; delete headers.connection; delete headers['content-length'];
      const body = p.bodyBase64 ? Buffer.from(p.bodyBase64, 'base64') : Buffer.alloc(0);
      headers['content-length'] = body.length;
      const req = http.request({hostname:'127.0.0.1',port:this.localPort,method:p.method||'GET',path:p.path||'/',headers}, res => {
        const chunks=[];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({status:res.statusCode||500,headers:res.headers,bodyBase64:Buffer.concat(chunks).toString('base64')}));
      });
      req.on('error', reject);
      if (body.length) req.write(body);
      req.end();
    });
  }
}
module.exports = RemoteHostAgent;
