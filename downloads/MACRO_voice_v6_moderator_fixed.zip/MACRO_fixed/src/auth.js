'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { ACCOUNTS } = require('./DataPaths');
const { loadKakaoForge } = require('./KakaoForgeLoader');
const { saveSession } = require('./services/KakaoSession');
const { qrLogin } = require('./vox-bot/QrLogin.cjs');

async function main() {
  const key = process.argv[2] || 'main';
  if (!/^[a-zA-Z0-9_-]+$/.test(key)) throw new Error('잘못된 계정 별칭');
  const directory = path.join(ACCOUNTS, key);
  const file = path.join(directory, 'auth.json');
  const existing = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')) : undefined;
  const { loadedFrom } = loadKakaoForge();
  const session = await qrLogin({ loadedFrom, existing, emit: ({ url }) => console.log('이 PC에서 QR 주소를 여세요 ' + url) });
  fs.mkdirSync(directory, { recursive: true });
  saveSession(file, session);
  console.log('카카오톡 인증을 저장했습니다. MACRO를 실행하거나 해당 봇을 다시 시작하세요.');
}
main().catch(() => {
  console.error('카카오톡 인증을 완료하지 못했습니다. 같은 계정으로 다시 시도하세요.');
  process.exitCode = 1;
});
