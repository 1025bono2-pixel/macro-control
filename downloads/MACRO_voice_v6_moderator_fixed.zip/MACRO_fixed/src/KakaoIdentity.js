'use strict';

// Kakao's user IDs are signed 64-bit positive integers, not nicknames/profile IDs.
function kakaoId(value) {
  if (typeof value === 'number' && !Number.isSafeInteger(value)) return null;
  if (value && typeof value === 'object') {
    if (value._bsontype !== 'Long' && value.isLosslessNumber !== true) return null;
    value = value.toString();
  }
  if (!['string', 'bigint', 'number'].includes(typeof value)) return null;
  const text = String(value);
  return /^[1-9][0-9]{0,18}$/.test(text) && BigInt(text) <= 9223372036854775807n ? text : null;
}

function senderId(event) {
  const raw = event?.raw?.chatLog ?? event?.raw;
  const author = raw?.authorId ?? raw?.senderId ?? raw?.userId;
  // Prefer the original BSON integer over any already-rounded compatibility alias.
  return kakaoId(author ?? event?.sender?.id ?? event?.senderId);
}

module.exports = { kakaoId, senderId };
