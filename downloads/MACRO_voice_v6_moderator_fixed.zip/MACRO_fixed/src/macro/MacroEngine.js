const crypto=require('crypto'),fs=require('fs'),path=require('path');const Store=require('./MacroStore');
class MacroEngine{
 constructor(manager){this.manager=manager;this.timers=new Map();this.messageGates=new Map();this.running=new Set();manager.engine=this;}
 list(){return Store.load();} visibleFor(keys){const s=new Set(keys||[]);return this.list().filter(x=>s.has(x.accountKey));}
 upsert(input,allowed=null){if(allowed&&!allowed.includes(String(input.accountKey)))throw new Error('이 봇에 대한 권한이 없습니다.');const all=this.list(),old=input.id?all.find(x=>x.id===input.id):null;if(old&&allowed&&!allowed.includes(old.accountKey))throw new Error('수정 권한이 없습니다.');const item={id:input.id||crypto.randomUUID(),kind:input.kind==='keyword'?'keyword':'schedule',name:String(input.name||'새 매크로'),enabled:old?old.enabled===true:input.enabled===true,accountKey:String(input.accountKey||''),roomId:String(input.roomId||''),roomName:String(input.roomName||''),text:String(input.text||''),photoPath:String(input.photoPath||''),keyword:String(input.keyword||''),schedule:input.schedule||{type:'interval',seconds:60},antiConsecutive:{enabled:input.antiConsecutive?.enabled===true,minMessages:Math.max(1,Math.min(5,Number(input.antiConsecutive?.minMessages)||1))}};const i=all.findIndex(x=>x.id===item.id);if(i>=0)all[i]=item;else all.push(item);Store.save(all);this.reload();return item;}
 setEnabled(id,enabled,allowed=null){const all=this.list(),i=all.findIndex(x=>x.id===id);if(i<0)throw new Error('매크로가 없습니다.');if(allowed&&!allowed.includes(all[i].accountKey))throw new Error('권한이 없습니다.');all[i].enabled=!!enabled;Store.save(all);this.reload();return all[i];}
 remove(id,allowed=null){const all=this.list(),old=all.find(x=>x.id===id);if(old&&allowed&&!allowed.includes(old.accountKey))throw new Error('삭제 권한이 없습니다.');Store.save(all.filter(x=>x.id!==id));this.reload();}
 client(i){
  const st=this.manager.states.get(i.accountKey)||{};
  const c=this.manager.clients.get(i.accountKey);
  if(!c||st.online!==true){
   const e=new Error('봇 연결 복구 중이라 이번 전송을 건너뜁니다.');
   e.code='BOT_RECONNECTING';
   throw e;
  }
  return c;
 } resolveFile(p){if(!p)return null;const f=path.resolve(p);if(!fs.existsSync(f)||!fs.statSync(f).isFile())throw new Error('사진을 찾을 수 없습니다.');return f;}
 async send(i){const c=this.client(i),a=this.manager.archives.get(i.accountKey);if(i.text){if(typeof c.chat?.sendText==='function')await c.chat.sendText(i.roomId,i.text);else if(typeof c.sendText==='function')await c.sendText(i.roomId,i.text);else throw new Error('sendText API가 없습니다.');a?.outgoing(i.roomId,'text',{text:i.text,source:'MACRO',macroId:i.id});}if(i.photoPath){if(typeof c.sendPhoto!=='function')throw new Error('현재 KakaoForge에 sendPhoto API가 없습니다.');const f=this.resolveFile(i.photoPath);await c.sendPhoto(i.roomId,f,{});a?.outgoing(i.roomId,'photo',{file:f,source:'MACRO',macroId:i.id});}}
 async run(i){
  if(!i.roomId)throw new Error('채팅방이 선택되지 않았습니다.');
  if(!i.text&&!i.photoPath)throw new Error('보낼 텍스트 또는 사진이 필요합니다.');
  // Prevent overlapping timer callbacks for the same macro.
  if(this.running.has(i.id))return false;
  const guarded=i.kind==='schedule'&&i.antiConsecutive?.enabled;
  const gate=this.messageGates.get(i.id);
  const need=Math.max(1,Math.min(5,Number(i.antiConsecutive?.minMessages)||1));
  if(guarded&&gate&&gate.hasSent&&gate.accountKey===String(i.accountKey)&&gate.roomId===String(i.roomId)&&gate.count<need){
   this.manager.archives.get(i.accountKey)?.log('macro',{macroId:i.id,name:i.name,status:'SKIPPED_CONSECUTIVE_GUARD',roomId:i.roomId,roomName:i.roomName,received:gate.count,required:need});
   return false;
  }
  this.running.add(i.id);
  try{
   // Incoming messages may arrive while the network send is pending.
   // Start the next counting window only after a successful send.
   const countBefore=gate?.count||0;
   await this.send(i);
   if(guarded){
    const latest=this.messageGates.get(i.id);
    const duringSend=latest===gate?Math.max(0,(latest?.count||0)-countBefore):0;
    this.messageGates.set(i.id,{hasSent:true,count:duringSend,accountKey:String(i.accountKey),roomId:String(i.roomId)});
   }
   this.manager.archives.get(i.accountKey)?.log('macro',{macroId:i.id,name:i.name,status:'SUCCESS',roomId:i.roomId,roomName:i.roomName,kind:i.kind});
   return true;
  }finally{this.running.delete(i.id);}
 }
 async onIncoming(k,r,t,s){
  const accountKey=String(k),roomId=String(r);
  const st=this.manager.states.get(k)||{};
  // Only count messages from other people. A missing sender ID is
  // not sufficient evidence that a message came from someone else.
  const senderId=String(s??'');
  if(!senderId||senderId===String(st.userId??''))return;
  for(const [id,g] of this.messageGates){
   if(g.accountKey===accountKey&&g.roomId===roomId&&g.hasSent){
    this.messageGates.set(id,{...g,count:Math.min(g.count+1,1000000)});
   }
  }
  if(!t)return; // Non-text messages still count toward the guard.
  for(const i of this.list().filter(x=>x.enabled&&x.kind==='keyword'&&String(x.accountKey)===accountKey&&String(x.roomId)===roomId&&x.keyword&&String(t).includes(x.keyword))){
   try{await this.run(i)}catch(e){this.manager.logMacroError(i,e)}
  }
 }
 reload(){for(const t of this.timers.values()){clearInterval(t);clearTimeout(t)}this.timers.clear();for(const i of this.list().filter(x=>x.enabled&&x.kind==='schedule'))this.schedule(i);}
 schedule(i){const s=i.schedule||{};if(s.type==='interval'){const seconds=s.seconds!=null?Number(s.seconds):(s.minutes!=null?Number(s.minutes)*60:60);const ms=Math.max(5,seconds||60)*1000;this.timers.set(i.id,setInterval(()=>this.run(i).catch(e=>this.manager.logMacroError(i,e)),ms));}else if(s.type==='daily'){const tick=()=>{const now=new Date(),[h,m]=String(s.time||'18:00').split(':').map(Number),next=new Date(now);next.setHours(h||0,m||0,0,0);if(next<=now)next.setDate(next.getDate()+1);const t=setTimeout(async()=>{try{await this.run(i)}catch(e){this.manager.logMacroError(i,e)}tick()},next-now);this.timers.set(i.id,t)};tick();}}
}
module.exports=MacroEngine;
