'use strict';
const fs = require('node:fs');
const { randomUUID } = require('node:crypto');

function saveSession(file, session) {
  const { userId, accessToken, refreshToken, deviceUuid } = session;
  if (!userId || !accessToken || !deviceUuid) throw new Error('Incomplete Kakao session');
  const temporary = `${file}.${randomUUID()}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify({ userId, accessToken, refreshToken, deviceUuid }), { mode: 0o600, flag: 'wx' });
    fs.renameSync(temporary, file);
  } finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
}

module.exports = { saveSession };
