const BotManager=require("./BotManager");
const MacroEngine=require("./macro/MacroEngine");
const PanelServer=require("./panel/PanelServer");
const RemoteHostAgent=require("./RemoteHostAgent");
try{
  if(!process.env.MACRO_TOKEN||process.env.MACRO_TOKEN==='change-me')throw new Error('MACRO_TOKEN에 관리자 비밀번호를 설정하세요.');
  const manager=new BotManager();
  const engine=new MacroEngine(manager);
  manager.startAll();
  engine.reload();
  new PanelServer(manager,engine).start();
  new RemoteHostAgent().start();
}catch(e){console.error("\n[MACRO START ERROR]\n"+e.message+"\n");process.exitCode=1;}
