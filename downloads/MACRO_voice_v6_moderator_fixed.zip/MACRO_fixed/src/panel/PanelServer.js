const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),Busboy=require('busboy');const Auth=require('../services/AuthStore');
const PUBLIC=path.join(__dirname,'..','..','public'),PATHS=require('../DataPaths'),UPLOADS=PATHS.UPLOADS,NOTICES_FILE=path.join(PATHS.SYSTEM,'notices.json');
const readNotices=()=>{try{const x=JSON.parse(fs.readFileSync(NOTICES_FILE,'utf8'));return Array.isArray(x)?x:[]}catch{return[]}};
const saveNotices=x=>{fs.mkdirSync(path.dirname(NOTICES_FILE),{recursive:true});fs.writeFileSync(NOTICES_FILE,JSON.stringify(x,null,2));};
class PanelServer{constructor(manager,engine,o={}){this.manager=manager;this.engine=engine;this.port=Number(o.port||process.env.MACRO_PORT||8787);this.admin=o.token||process.env.MACRO_TOKEN||'change-me';}
 json(r,c,d){r.writeHead(c,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});r.end(JSON.stringify(d));} body(q){return new Promise((r,j)=>{let s='';q.on('data',c=>{s+=c;if(s.length>2e6)q.destroy();});q.on('end',()=>{try{r(s?JSON.parse(s):{});}catch(e){j(e);}});});}
 session(q){const t=(q.headers.authorization||'').replace(/^Bearer /,'');if(t===this.admin)return{role:'admin',accounts:this.manager.findAccounts().map(x=>x.key),name:'총괄 관리자'};const u=Auth.bySession(t);return u?{role:'user',id:u.id,name:u.displayName||u.username,username:u.username,accounts:u.accounts||[],raw:u}:null;}
 requireLicense(s){if(s.role==='admin')return; if(!Auth.hasLicense(s.raw))throw Object.assign(new Error('라이선스를 등록해야 사용할 수 있습니다.'),{status:403});}
 upload(q,s){return new Promise((resolve,reject)=>{fs.mkdirSync(UPLOADS,{recursive:true});let saved=null;const bb=Busboy({headers:q.headers,limits:{files:1,fileSize:20*1024*1024}});bb.on('file',(name,file,info)=>{if(!String(info.mimeType||'').startsWith('image/')){file.resume();return reject(new Error('이미지 파일만 업로드할 수 있습니다.'));}const ext=path.extname(info.filename||'').slice(0,8)||'.jpg',dir=path.join(UPLOADS,s.role==='admin'?'admin':s.id);fs.mkdirSync(dir,{recursive:true});saved=path.join(dir,`${Date.now()}-${crypto.randomBytes(5).toString('hex')}${ext}`);file.pipe(fs.createWriteStream(saved));});bb.on('close',()=>saved?resolve(saved):reject(new Error('사진이 선택되지 않았습니다.')));bb.on('error',reject);q.pipe(bb);});}
 async api(q,r,u){
  if(u.pathname==='/api/register'&&q.method==='POST'){const b=await this.body(q);return this.json(r,200,{ok:true,user:Auth.register(b.username,b.password)});}
  if(u.pathname==='/api/login'&&q.method==='POST'){const b=await this.body(q);if(String(b.username)==='admin'&&String(b.password)===this.admin)return this.json(r,200,{ok:true,role:'admin',token:this.admin});const x=Auth.login(b.username,b.password);return this.json(r,x?200:401,x?{ok:true,role:'user',token:x.token,user:x.user}:{error:'아이디 또는 비밀번호가 올바르지 않습니다.'});}
  const s=this.session(q);if(!s)return this.json(r,401,{error:'로그인이 필요합니다.'});
  if(u.pathname==='/api/me')return this.json(r,200,{role:s.role,name:s.name,username:s.username,license:s.role==='admin'?{active:true,type:'admin'}:Auth.licenseInfo(s.raw)});
  if(u.pathname==='/api/license/activate'&&q.method==='POST'){if(s.role==='admin')return this.json(r,400,{error:'관리자 계정에는 필요하지 않습니다.'});const b=await this.body(q);return this.json(r,200,Auth.activate(s.id,b.key));}
  if(u.pathname==='/api/voice-settings'&&['GET','PUT','POST'].includes(q.method)){
    if(s.role!=='admin')return this.json(r,403,{error:'총괄 관리자만 보룸봇 설정을 변경할 수 있습니다.'});
    this.requireLicense(s);
    const account=String(u.searchParams.get('account')||'');
    if(!this.manager.findAccounts().some(item=>item.key===account)||(s.role!=='admin'&&!s.accounts.includes(account)))return this.json(r,403,{error:'봇 계정에 접근할 수 없습니다.'});
    if(q.method==='PUT'){
      const input=await this.body(q);
      return this.json(r,200,this.manager.voice.save(account,input.rooms,input.globalOperatorIds));
    }
    if(q.method==='POST'){
      const state=this.manager.states.get(account)||{};
      if(state.authRequired&&!state.authRefreshing)await this.manager.restart(account,{preserveVoice:true});
      return this.json(r,202,{ok:true});
    }
    const state=this.manager.states.get(account)||{};
    return this.json(r,200,{schemaVersion:2,...this.manager.voice.get(account),online:!!state.online,authRequired:!!state.authRequired,authRefreshing:!!state.authRefreshing});
  }
  if(u.pathname==='/api/status'){const a=this.manager.status().filter(x=>s.role==='admin'||s.accounts.includes(x.key));return this.json(r,200,{accounts:a,version:'2.1.0'});}
  if(u.pathname==='/api/macro/recent'&&q.method==='GET'){
    const allowed=s.role==='admin'?this.manager.status().map(x=>String(x.key)):(s.accounts||[]).map(String);
    const names=new Map(this.manager.status().map(x=>[String(x.key),x.displayName||x.key]));
    const rows=[];
    for(const [key,archive] of this.manager.archives.entries()){
      if(!allowed.includes(String(key)))continue;
      const logs=archive.detail()?.logs?.macro||[];
      for(const x of logs)rows.push({...x,accountKey:String(key),accountName:names.get(String(key))||String(key)});
    }
    rows.sort((a,b)=>String(b.at||'').localeCompare(String(a.at||'')));
    return this.json(r,200,rows.slice(0,200));
  }
  if(u.pathname==='/api/notices'&&q.method==='GET'){return this.json(r,200,readNotices().slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))));}
  if(u.pathname==='/api/notices'&&q.method==='POST'){if(s.role!=='admin')return this.json(r,403,{error:'총괄 관리자만 공지사항을 등록할 수 있습니다.'});const b=await this.body(q),title=String(b.title||'').trim(),content=String(b.content||'').trim();if(!title||!content)return this.json(r,400,{error:'제목과 내용을 입력하세요.'});const all=readNotices(),item={id:crypto.randomUUID(),title:title.slice(0,120),content:content.slice(0,10000),createdAt:new Date().toISOString(),author:'총괄 관리자'};all.push(item);saveNotices(all.slice(-300));return this.json(r,200,item);}
  if(/^\/api\/notices\/[^/]+$/.test(u.pathname)&&q.method==='DELETE'){if(s.role!=='admin')return this.json(r,403,{error:'총괄 관리자만 공지사항을 삭제할 수 있습니다.'});const id=decodeURIComponent(u.pathname.split('/').pop()),all=readNotices(),next=all.filter(x=>x.id!==id);saveNotices(next);return this.json(r,200,{ok:true});}
  if(u.pathname==='/api/rooms'){const key=u.searchParams.get('account');if(s.role!=='admin'&&!s.accounts.includes(key))return this.json(r,403,{error:'권한이 없습니다.'});return this.json(r,200,this.manager.rooms(key));}
  if(u.pathname==='/api/rooms/refresh'&&q.method==='POST'){const b=await this.body(q),key=String(b.account||'');if(s.role!=='admin'&&!s.accounts.includes(key))return this.json(r,403,{error:'권한이 없습니다.'});const sync=await this.manager.syncRooms(key);return this.json(r,200,{...sync,rooms:this.manager.rooms(key)});}
  if(u.pathname==='/api/upload/photo'&&q.method==='POST'){this.requireLicense(s);const p=await this.upload(q,s);return this.json(r,200,{ok:true,photoId:path.basename(p),photoPath:p});}
  if(u.pathname==='/api/macros'&&q.method==='GET'){this.requireLicense(s);return this.json(r,200,s.role==='admin'?this.engine.list():this.engine.visibleFor(s.accounts));}
  if(u.pathname==='/api/macros'&&q.method==='POST'){this.requireLicense(s);return this.json(r,200,this.engine.upsert(await this.body(q),s.role==='admin'?null:s.accounts));}
  if(u.pathname.endsWith('/toggle')&&q.method==='POST'){this.requireLicense(s);const id=u.pathname.split('/')[3],b=await this.body(q);return this.json(r,200,this.engine.setEnabled(id,!!b.enabled,s.role==='admin'?null:s.accounts));}
  if(/^\/api\/macros\/[^/]+$/.test(u.pathname)&&q.method==='DELETE'){this.requireLicense(s);this.engine.remove(u.pathname.split('/').pop(),s.role==='admin'?null:s.accounts);return this.json(r,200,{ok:true});}
  if(u.pathname.endsWith('/run')&&q.method==='POST'){this.requireLicense(s);const id=u.pathname.split('/')[3],i=this.engine.list().find(x=>x.id===id);if(!i)return this.json(r,404,{error:'매크로가 없습니다.'});if(s.role!=='admin'&&!s.accounts.includes(i.accountKey))return this.json(r,403,{error:'권한이 없습니다.'});await this.engine.run(i);return this.json(r,200,{ok:true});}
  if(s.role==='admin'&&u.pathname==='/api/admin/users'&&q.method==='GET')return this.json(r,200,Auth.listUsers());
  if(s.role==='admin'&&/^\/api\/admin\/users\/[^/]+$/.test(u.pathname)&&q.method==='POST'){const id=u.pathname.split('/').pop();return this.json(r,200,Auth.updateUser(id,await this.body(q)));}
  if(s.role==='admin'&&u.pathname==='/api/admin/licenses'&&q.method==='GET')return this.json(r,200,Auth.listLicenses());
  if(s.role==='admin'&&u.pathname==='/api/admin/licenses'&&q.method==='POST'){const b=await this.body(q);return this.json(r,200,Auth.issueLicense(b.type));}
  if(s.role==='admin'&&/^\/api\/admin\/licenses\/[^/]+\/revoke$/.test(u.pathname)&&q.method==='POST'){const key=decodeURIComponent(u.pathname.split('/')[4]);return this.json(r,200,Auth.revokeLicense(key));}
  if(s.role==='admin'&&/^\/api\/admin\/users\/[^/]+$/.test(u.pathname)&&q.method==='DELETE'){const id=u.pathname.split('/').pop();return this.json(r,200,Auth.deleteUser(id));}
  if(s.role==='admin'&&u.pathname==='/api/admin/account'&&q.method==='POST'){const b=await this.body(q);this.manager.rename(String(b.key),String(b.displayName));return this.json(r,200,{ok:true});}
  if(s.role==='admin'&&u.pathname==='/api/admin/account'&&q.method==='DELETE'){const b=await this.body(q),key=String(b.key||'');const out=await this.manager.removeAccount(key);Auth.removeAccountFromUsers(key);return this.json(r,200,out);}
  if(s.role==='admin'&&u.pathname==='/api/admin/account/add'&&q.method==='POST'){const b=await this.body(q),key='acc_'+crypto.randomBytes(5).toString('hex');this.manager.addAccountByQR(key,String(b.displayName||'새 봇')).catch(e=>console.error('[QR AUTH]',e));return this.json(r,202,{ok:true,key,message:'총괄 PC CMD에 표시되는 QR로 인증하세요.'});}
  if(s.role==='admin'&&/^\/api\/admin\/detail\/bot\/[^/]+\/reset$/.test(u.pathname)&&q.method==='POST'){const parts=u.pathname.split('/').filter(Boolean),key=decodeURIComponent(parts[4]||'');const a=this.manager.status().find(x=>x.key===key);if(!a)return this.json(r,404,{error:'봇을 찾을 수 없습니다.'});const archive=this.manager.archives.get(key)||new (require('../archive/ArchiveStore'))(key);archive.resetDetail();return this.json(r,200,{ok:true});}
  if(s.role==='admin'&&/^\/api\/admin\/detail\/bot\/[^/]+$/.test(u.pathname)&&q.method==='GET'){const key=u.pathname.split('/').pop(),a=this.manager.status().find(x=>x.key===key);if(!a)return this.json(r,404,{error:'봇을 찾을 수 없습니다.'});const archive=this.manager.archives.get(key)||new (require('../archive/ArchiveStore'))(key);return this.json(r,200,{account:a,loco:this.manager.clientInfo(key),archive:archive.detail(),rooms:this.manager.rooms(key),macros:this.engine.list().filter(x=>x.accountKey===key)});}
  if(s.role==='admin'&&/^\/api\/admin\/detail\/user\/[^/]+$/.test(u.pathname)&&q.method==='GET'){const id=u.pathname.split('/').pop(),x=Auth.listUsers().find(v=>v.id===id);if(!x)return this.json(r,404,{error:'회원을 찾을 수 없습니다.'});return this.json(r,200,{user:x,accounts:this.manager.status().filter(a=>(x.accounts||[]).includes(a.key))});}
  if(s.role==='admin'&&u.pathname==='/api/admin/bots/restart-all'&&q.method==='POST'){const out=await this.manager.restartAll();return this.json(r,200,out);}
  if(s.role==='admin'&&u.pathname.startsWith('/api/admin/bot/')&&q.method==='POST'){const parts=u.pathname.split('/').filter(Boolean),key=decodeURIComponent(parts[3]||''),action=parts[4];if(action==='start')this.manager.startByKey(key);else if(action==='stop')await this.manager.stop(key);else if(action==='restart')await this.manager.restart(key);else return this.json(r,400,{error:'지원하지 않는 동작'});return this.json(r,200,{ok:true,action,key});}
  if(s.role==='user'&&/^\/api\/bot\/[^/]+\/restart$/.test(u.pathname)&&q.method==='POST'){this.requireLicense(s);const parts=u.pathname.split('/').filter(Boolean),key=decodeURIComponent(parts[2]||'');if(!s.accounts.includes(key))return this.json(r,403,{error:'자신에게 할당된 봇만 재시작할 수 있습니다.'});await this.manager.restart(key);return this.json(r,200,{ok:true,action:'restart',key});}
  return this.json(r,404,{error:'없는 API'});
 }
 start(){this.server=http.createServer(async(q,r)=>{try{const u=new URL(q.url,'http://localhost');if(u.pathname.startsWith('/api/'))return await this.api(q,r,u);const f=u.pathname==='/'?'index.html':u.pathname.slice(1),p=path.normalize(path.join(PUBLIC,f));if(!p.startsWith(PUBLIC)||!fs.existsSync(p)){r.writeHead(404);return r.end('404');}const ext=path.extname(p),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};r.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});fs.createReadStream(p).pipe(r);}catch(e){this.json(r,e.status||500,{error:e.message});}});this.server.listen(this.port,'0.0.0.0',()=>console.log(`[MACRO] 패널: http://localhost:${this.port}`));}}
module.exports=PanelServer;
