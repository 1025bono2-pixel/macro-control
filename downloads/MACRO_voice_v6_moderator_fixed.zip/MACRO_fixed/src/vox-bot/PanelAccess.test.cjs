const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');

for(const panel of ['MACRO_Host','MACRO_Render_Server']) {
  test(`${panel}: voice menu follows admin role and direct non-admin rendering is blocked`,async()=>{
    const publicDir=panel==='MACRO_Host' ? path.resolve(__dirname,'../../public') : path.resolve(__dirname,'../../../MACRO_Render_Server/public');
    const nodes=new Map();
    const node=id=>{
      if(!nodes.has(id))nodes.set(id,{classList:{toggle(k,v){this[k]=v},add(){},remove(){}}});
      return nodes.get(id);
    };
    const ctx=vm.createContext({localStorage:{},document:{getElementById:node,body:node('body')},console});
    const script=fs.readFileSync(path.join(publicDir,'app.js'),'utf8');
    const html=fs.readFileSync(path.join(publicDir,'index.html'),'utf8');
    assert.match(html,/<button id="voiceNav" class="hidden"/);
    vm.runInContext(script,ctx);
    for(const role of ['user','admin']) {
      vm.runInContext(`api=async()=>({role:'${role}'});page=async()=>{};startNoticeWatcher=()=>{};`,ctx);
      await vm.runInContext('openApp()',ctx);
      assert.equal(node('voiceNav').classList.hidden,role!=='admin');
    }
    const guarded=vm.createContext({localStorage:{},document:{getElementById(){throw Error('unauthorized DOM access')},body:node('body')},console});
    vm.runInContext(script,guarded);
    await vm.runInContext("role='user';page('voice')",guarded);
    await vm.runInContext('voiceSettingsPage()',guarded);
  });
}
