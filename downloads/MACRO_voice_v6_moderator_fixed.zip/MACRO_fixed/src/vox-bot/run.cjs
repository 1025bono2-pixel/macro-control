'use strict';

const fs = require('node:fs');
const { createVoiceRoomBot } = require('./VoiceRoomBot.cjs');
const { loadKakaoForge } = require('../KakaoForgeLoader');

const output = console.log;
const emit = event => output(JSON.stringify(event));
const readJson = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
let client;
let handle;
let stopping = false;
const pending = new Set();

async function stop() {
  if (stopping) return;
  stopping = true;
  try {
    await Promise.allSettled(pending);
    await handle?.shutdown();
  } finally { await client?.disconnect(); }
}

async function main() {
  const [authPath, rulesPath, loginMode] = process.argv.slice(2);
  if (!authPath || !rulesPath) {
    emit({ event: 'usage', command: 'node --openssl-legacy-provider src/vox-bot/run.cjs <existing-auth.json> <rooms.json> [--qr]' });
    process.exitCode = 1;
    return;
  }
  // KakaoForge's diagnostics can include request-derived fields.
  for (const level of ['log', 'info', 'warn', 'error', 'debug']) console[level] = () => {};
  const existing = readJson(authPath);
  const rooms = readJson(rulesPath);
  const { mod, loadedFrom } = loadKakaoForge();
  const auth = loginMode === '--qr' ? await require('./QrLogin.cjs').qrLogin({ loadedFrom, existing, emit }) : existing;
  client = new mod.KakaoForgeClient({ userId: auth.userId, oauthToken: auth.accessToken,
    deviceUuid: auth.deviceUuid, autoReconnect: false });
  client.on('error', () => emit({ event: 'loco_error' }));
  handle = createVoiceRoomBot({ client, rooms, log: emit });
  client.onMessage(message => {
    if (stopping) return;
    const task = handle(message).catch(() => emit({ event: 'voice_room_command_error' }));
    pending.add(task);
    void task.finally(() => pending.delete(task));
  });
  const result = await client.connect();
  if (result?.status !== 0 || Number(result.body?.status ?? 0) !== 0) throw new Error('LOCO login failed');
  emit({ event: 'loco_ready' });
  const shutdown = () => void stop().catch(() => { process.exitCode = 1; });
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  client.once('disconnected', shutdown);
}

main().catch(async error => {
  emit({ event: error?.code === 'LOCO_AUTH_REJECTED' ? 'loco_auth_rejected' : 'startup_failed' });
  process.exitCode = 1;
  try { await stop(); } catch {}
});
