'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createVoiceRoomCommands}=require('./VoiceRoomCommands.cjs');
const {withCurrentMemberRole}=require('./MemberRole.cjs');

function event(type,room='101',logId='1') {
  return {room:{id:room,isOpenChat:true},sender:{id:'123',type},
    message:{text:'!보룸자동 테스트',type:1,logId}};
}

test('owners and managers need no manually registered operator IDs',()=>{
  for(const type of [1,4]) {
    const command=createVoiceRoomCommands({rooms:[{roomId:'101',operatorIds:[]}]});
    assert.equal(command(event(type)).status,'authorized');
  }
});

test('ordinary members, unknown roles and bot-role aliases do not grant moderator access',()=>{
  for(const type of [2,0,undefined]) {
    const command=createVoiceRoomCommands({rooms:[{roomId:'101',operatorIds:[]}]});
    assert.equal(command({...event(type),type:1,chat:{type:1}}).status,'forbidden');
  }
});

test('owners cannot bypass the allowed-room list or open-chat requirement',()=>{
  const command=createVoiceRoomCommands({rooms:[{roomId:'101',operatorIds:[]}]});
  assert.equal(command(event(1,'102')).status,'forbidden');
  assert.equal(command({...event(1),room:{id:'101',isOpenChat:false}}).status,'forbidden');
});

test('registered operators remain supported; role changes apply to subsequent messages',()=>{
  const command=createVoiceRoomCommands({rooms:[{roomId:'101',operatorIds:[]}]});
  assert.equal(command(event(4)).status,'authorized');
  assert.equal(command(event(2,'101','2')).status,'forbidden');
  command.updateRooms([{roomId:'101',operatorIds:['123']}]);
  assert.equal(command(event(2,'101','3')).status,'authorized');
});

test('moderators still require a valid sender ID and duplicate commands remain blocked',()=>{
  const command=createVoiceRoomCommands({rooms:[{roomId:'101',operatorIds:[]}]});
  assert.equal(command({...event(1),sender:{id:'0',type:1}}).status,'forbidden');
  assert.equal(command(event(1)).status,'authorized');
  assert.equal(command(event(1)).status,'duplicate');
});

test('fresh server membership promotes new managers and revokes demoted owners',async()=>{
  for(const [cached,fresh,expected] of [[2,4,'authorized'],[1,2,'forbidden']]) {
    const command=createVoiceRoomCommands({rooms:[{roomId:'101',operatorIds:[]}]});
    const client={_carriage:{member:async(room,ids)=>{
      assert.equal(room,'101');assert.deepEqual(ids,['123']);
      return {status:0,body:{members:[{userId:'123',mt:fresh}]}};
    }}};
    assert.equal(command(await withCurrentMemberRole(client,event(cached))).status,expected);
  }
});

test('failed member lookup and another member role cannot grant cached owner access',async()=>{
  for(const member of [async()=>{throw Error('offline')},async()=>({body:{members:[{userId:'456',mt:1}]}})]) {
    const command=createVoiceRoomCommands({rooms:[{roomId:'101',operatorIds:[]}]});
    assert.equal(command(await withCurrentMemberRole({_carriage:{member}},event(1))).status,'forbidden');
  }
});
