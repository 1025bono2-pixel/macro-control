'use strict';

const http = require('node:http');
const https = require('node:https');
const path = require('node:path');
const { createRequire } = require('node:module');
const { setTimeout: delay } = require('node:timers/promises');

function renderQr(QR, content) {
  const qr = new QR(-1, 1);
  qr.addData(content);
  qr.make();
  const size = qr.getModuleCount() + 8;
  const dots = qr.modules.flatMap((row, y) => row.map((dark, x) => dark ? `M${x + 4} ${y + 4}h1v1h-1z` : '')).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="white"/><path d="${dots}"/></svg>`;
}

async function checkDevice(subDeviceAllowList, config) {
  const request = https.request;
  https.request = function (options, ...args) {
    if (options?.hostname === 'katalk.kakao.com' && options.method === 'GET' &&
        options.path?.startsWith('/android/account/allowlist.json?')) {
      options = { ...options, headers: { ...options.headers, 'Content-Type': 'application/x-www-form-urlencoded' } };
    }
    return request.call(this, options, ...args);
  };
  try {
    if ((await subDeviceAllowList(config))?.allowlisted !== true) throw new Error('QR device not allowed');
  } finally { https.request = request; }
}

async function qrLogin({ loadedFrom, existing, emit }) {
  if (existing && (!existing.deviceUuid || !existing.userId)) throw new Error('Existing account identity is incomplete');
  const bundled = createRequire(path.join(loadedFrom, '__vox_qr_resolve__.js'));
  const QR = bundled('qrcode-terminal/vendor/QRCode');
  const { subDeviceAllowList, qrGenerate, qrPollLogin, extractQrId, qrCancel, generateDeviceUuid } = bundled('./auth/login.js');
  const config = { deviceUuid: existing?.deviceUuid || generateDeviceUuid(), modelName: 'SM-T733', appVer: '25.11.2' };
  await checkDevice(subDeviceAllowList, config);
  const challenge = await qrGenerate(config);
  const qrId = extractQrId(challenge.url);
  let completed = false;
  let passcode = '';
  let localHost;
  const svg = renderQr(QR, challenge.url);
  const server = http.createServer((req, res) => {
    if (req.headers.host !== localHost || req.url !== '/') {
      res.writeHead(404).end();
      return;
    }
    if (completed || !server.listening) {
      res.writeHead(410, { 'Cache-Control': 'no-store' }).end();
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
      'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" });
    res.end(`<!doctype html><html lang="ko"><meta charset="utf-8"><meta http-equiv="refresh" content="3"><title>카카오톡 로그인</title><style>body{font:18px system-ui;margin:40px;text-align:center}svg{width:360px;height:360px}</style><h1>카카오톡 로그인</h1>${passcode ? `<p>카카오톡에서 입력할 인증번호 <strong>${passcode}</strong></p>` : `<p>테스트 계정으로 QR을 스캔하세요.</p>${svg}`}</html>`);
  });
  try {
    await new Promise((resolve, reject) => server.once('error', reject).listen(0, '127.0.0.1', resolve));
    localHost = `127.0.0.1:${server.address().port}`;
    emit({ event: 'qr_ready', url: `http://${localHost}/` });
    const started = Date.now();
    let deadline = started + (Number(challenge.remainingSeconds) || 60) * 1000;
    let interval = 2000;
    while (Date.now() < deadline) {
      await delay(interval);
      const response = await qrPollLogin({ ...config, qrId });
      if (response.accessToken) {
        completed = true;
        if (existing && String(response.user?.userId) !== String(existing.userId)) throw new Error('QR account mismatch');
        return { userId: String(response.user.userId), accessToken: response.accessToken,
          refreshToken: response.refreshToken, deviceUuid: config.deviceUuid };
      }
      if (/^[A-Za-z0-9-]{1,20}$/.test(String(response.passcode ?? ''))) passcode = String(response.passcode);
      if (response.remainingSeconds > 0) deadline = Math.min(started + 150000, Date.now() + response.remainingSeconds * 1000);
      if (!response.nextRequestIntervalInSeconds && response.status && response.status !== 0) throw new Error('QR rejected');
      interval = Math.max(1000, Number(response.nextRequestIntervalInSeconds || 2) * 1000);
    }
    throw new Error('QR expired');
  } finally {
    server.close();
    if (!completed) await qrCancel({ ...config, qrId }).catch(() => {});
  }
}

module.exports = { qrLogin };
