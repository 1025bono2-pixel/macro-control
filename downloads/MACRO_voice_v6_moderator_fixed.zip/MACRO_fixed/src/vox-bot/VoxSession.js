const { EventEmitter } = require('events');
const crypto = require('crypto');
const { RTCPeerConnection, RTCRtpCodecParameters, RTCRtpHeaderExtensionParameters, MediaStreamTrack } = require('werift');
const VoxConnection = require('../vox/VoxConnection');
const { BSON } = require('../vox/VoxCodec');
const long = value => {
  if (typeof value === 'number' && !Number.isSafeInteger(value)) throw new Error('VOX ID precision');
  const text = String(value ?? '');
  if (!/^(0|[1-9]\d{0,18})$/.test(text) || BigInt(text) > 9223372036854775807n) throw new Error('VOX ID 형식이 잘못되었습니다.');
  return BSON.Long.fromString(text);
};
const ok = packet => {
  if (packet?.body?.resCode !== 0) throw new Error(`VOX 서버가 요청을 승인하지 않았습니다 (코드 ${Number(packet?.body?.resCode) || '미확인'}).`);
  return packet.body;
};
const ipv4 = value => {
  const n = Number(value) >>> 0;
  return [n >>> 24, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
};
class VoxSession extends EventEmitter {
  constructor(context, options = {}) {
    super(); this.context = context; this.options = options; this.status = 'new'; this.connection = null;
    this.pc = null; this.heartbeat = null; this.callId = null; this.csId = null; this.pushWork = Promise.resolve();
    this.earlyPushes = [];
    this.on('error', () => {});
  }
  common() {
    const c = this.context;
    return { userId: long(c.userId), devType: 4, appVer: c.appVer || '25.11.2', lang: 'ko', country: 'KR', voxVer: 5,
      carrierId: '45005', netType: 2, serviceType: 11,
      devInfo: { model: c.modelName || 'SM-T733', os: 'android', osver: '14', buildId: 'MACRO' } };
  }
  newConnection() { return this.options.connectionFactory ? this.options.connectionFactory() : new VoxConnection(); }
  async discover(roomId, checkOnCall = false) {
    const conn = this.newConnection();
    try {
      await conn.connect({ host: this.options.vssHost || process.env.MACRO_VOX_VSS_HOST || '211.183.214.122',
        port: Number(this.options.port || process.env.MACRO_VOX_TLS_PORT || 10009), servername: 'kakao.com' });
      return ok(await conn.request(30000, { ...this.common(), chatId: long(roomId), checkOnCall }));
    } finally { conn.close(); }
  }
  async create(roomId, title) {
    if (this.status !== 'new') throw new Error('VOX 생성은 한 번만 요청할 수 있습니다.');
    if (![1,2,3].includes(this.context.userType)) throw new Error('오픈채팅에서 확인한 본인 역할이 필요합니다.');
    if (!this.context.oauthToken || !this.context.deviceUuid) throw new Error('VOX 인증 정보가 없습니다.');
    long(roomId);
    this.status = 'preparing'; this.roomId = String(roomId); this.title = title;
    const found = await this.discover(roomId);
    if (Number(found.callable) !== 1) { this.status = 'rejected'; throw new Error('이 방에서 보이스룸 생성이 허용되지 않았습니다. 기존 보이스룸/통화 상태를 확인하세요.'); }
    if (!found.csSslAddr?.ip) throw new Error('VOX 서버 주소를 받지 못했습니다.');
    this.pc = this.options.peerFactory ? this.options.peerFactory() : new RTCPeerConnection({
      iceServers: [], iceUseDefaultStunServer: false,
      codecs: { audio: [new RTCRtpCodecParameters({ mimeType: 'audio/opus', payloadType: 111, clockRate: 48000, channels: 2, parameters: 'minptime=10;useinbandfec=1', rtcpFeedback: [{ type: 'transport-cc' }] })] },
      headerExtensions: { audio: [
        new RTCRtpHeaderExtensionParameters({id:1,uri:'urn:ietf:params:rtp-hdrext:ssrc-audio-level'}),
        new RTCRtpHeaderExtensionParameters({id:2,uri:'http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time'}),
        new RTCRtpHeaderExtensionParameters({id:3,uri:'http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01'}),
        new RTCRtpHeaderExtensionParameters({id:4,uri:'urn:ietf:params:rtp-hdrext:sdes:mid'})
      ] }
    });
    // An empty RTP track supplies SDP stream metadata; it captures no microphone.
    const transceiver = this.pc.addTransceiver(new MediaStreamTrack({ kind: 'audio' }), { direction: 'sendonly' });
    transceiver.sender.streamId = crypto.randomUUID();
    await this.pc.setLocalDescription(await this.pc.createOffer());
    const offer = this.pc.localDescription.sdp.split('\r\n').filter(line => !line.startsWith('a=candidate:') && line !== 'a=end-of-candidates').join('\r\n');
    const conn = this.newConnection(); this.connection = conn;
    conn.on('push', packet => {
      if (this.status === 'creating' && !this.callId) {
        if (this.earlyPushes.length < 32) this.earlyPushes.push(packet);
        return;
      }
      this.queuePush(packet);
    });
    conn.on('error', () => this.markUncertain());
    conn.on('disconnected', () => this.markUncertain());
    this.serverAddress = { host: ipv4(found.csSslAddr.ip), port: Number(this.options.port || process.env.MACRO_VOX_TLS_PORT || 10009), servername: 'kakao.com' };
    await conn.connect(this.serverAddress);
    const common = this.common();
    this.status = 'creating';
    const packet = await conn.request(11028, {
      ...common, mediaType: 1, sKey: this.context.sKey || '', oauthToken: this.context.oauthToken, duuid: this.context.deviceUuid,
      chatId: long(roomId), title, userType: this.context.userType, defaultMicOnOff: 1, destId: long(0), simOperator: '45005', isRoaming: 0, mobileNetType: 13,
      devInfo: { ...common.devInfo, devSubType: 7 },
      sdp: { sdp: offer, sdpType: 1, sdpUserId: long(this.context.userId) }, isMultiChat: false
    });
    if (Number.isInteger(packet?.body?.resCode) && packet.body.resCode !== 0) this.status = 'rejected';
    const response = ok(packet);
    if (String(response.userId) !== String(this.context.userId)) throw new Error('VOX 개설 응답의 계정이 일치하지 않습니다.');
    this.callId = long(response.callId); this.csId = long(response.csId);
    if (this.callId.isZero() || this.csId.isZero()) throw new Error('VOX 응답에 유효한 통화 ID가 없습니다.');
    if (this.status !== 'creating') throw new Error('VOX 개설 중 연결 상태가 변경됐습니다.');
    this.status = 'active';
    for (const push of this.earlyPushes.splice(0)) this.queuePush(push);
    if (this.status !== 'active') throw new Error('VOX 개설 확인 중 통화가 종료됐습니다.');
    await this.heartbeatWithRetry();
    const interval = Math.min(5000, Math.max(1000, Number(response.interval || 5) * 1000));
    if (this.status !== 'active') throw new Error('VOX 유지 응답 확인 중 연결이 종료됐습니다.');
    this.heartbeatInterval = interval;
    this.scheduleHeartbeat(interval);
    return { status: 'create_acknowledged', title, negotiated: Boolean(this.negotiated) };
  }
  queuePush(packet) {
    // ACK and termination must not wait behind slow SDP negotiation.
    this.pushWork = this.onPush(packet).catch(() => this.markUncertain());
  }
  markUncertain() {
    if (!['creating', 'active', 'ending'].includes(this.status)) return;
    this.status = 'uncertain';
    clearTimeout(this.heartbeat);
    this.emit('connection_unconfirmed');
  }
  scheduleHeartbeat(interval) {
    this.heartbeat = setTimeout(async () => {
      try {
        await this.heartbeatWithRetry();
        if (this.status === 'active') this.scheduleHeartbeat(interval);
      } catch { if (this.status === 'active') this.markUncertain(); }
    }, interval);
    this.heartbeat.unref();
  }
  async onPush(packet) {
    if (!this.callId) return;
    if (packet.command === 11007) {
      const body = packet.body;
      if (String(body.userId) !== String(this.context.userId) || String(body.callId) !== String(this.callId)) return;
      try { this.connection?.send(packet.sequence, packet.command, { userId: long(this.context.userId), callId: this.callId, resCode: 0, devType: 4 }); } catch {}
      if (this.status === 'ending') {
        this.serverEnded = true;
        this.connection?.rejectPending(new Error('VOX confirmed call end'));
      } else {
        this.status = 'ended'; clearInterval(this.heartbeat);
        this.connection?.rejectPending(new Error(`VOX 서버가 보이스룸을 종료했습니다 (사유 ${Number(body.reason)}).`));
        this.emit('ended', { reason: Number(body.reason) }); await this.close();
      }
      return;
    }
    if (![11003, 12011].includes(packet.command)) { this.emit('notification', { command: packet.command }); return; }
    const body = packet.body;
    if (String(body.userId) !== String(this.context.userId) || String(body.callId) !== String(this.callId)) return;
    this.connection.send(packet.sequence, packet.command, { userId: long(this.context.userId), callId: long(body.callId), resCode: 0, devType: 4 });
    if (packet.command === 11003 && body.sdp?.sdpType === 2 && body.sdp.sdp) {
      // Keep only the newest waiting SDP when a busy room sends a burst.
      this.latestSdp = body.sdp.sdp;
      if (!this.sdpWork) {
        this.sdpWork = (async () => {
          while (this.latestSdp && this.pc && this.status === 'active') {
            const sdp = this.latestSdp;
            this.latestSdp = null;
            try {
              await this.pc.setRemoteDescription({ type: 'answer', sdp });
              if (this.status !== 'active') return;
              this.negotiated = true;
              this.emit('negotiated');
            } catch { this.emit('media_unconfirmed'); }
          }
        })().finally(() => { this.sdpWork = null; });
      }
      await this.sdpWork;
    }
  }
  async heartbeatOnce() {
    if (this.status !== 'active') return;
    ok(await this.connection.request(11015, { userId: long(this.context.userId), csId: this.csId, callId: this.callId,
      devType: 4, voiceFilter: 0, audioState: 0, videoState: 0, recInfo: this.recordInfo() }, 4000));
  }
  async heartbeatWithRetry() {
    for (let attempt = 0; this.status === 'active'; attempt++) {
      try { return await this.heartbeatOnce(); }
      catch (error) {
        if (error.code !== 'VOX_REQUEST_TIMEOUT' || attempt >= 2 || this.status !== 'active') throw error;
      }
    }
  }
  recordInfo() { return { recSessionId: '', recordCount: 0, recordDuration: long(0), recordIds: [] }; }
  async resume() {
    if (this.status !== 'uncertain' || !this.connection) return false;
    const conn = this.connection;
    if (Object.hasOwn(conn, 'socket') && (!conn.socket || conn.socket.destroyed)) return false;
    this.status = 'active';
    try {
      await this.heartbeatWithRetry();
      if (this.status !== 'active') return false;
      this.scheduleHeartbeat(this.heartbeatInterval || 5000);
      return true;
    } catch { this.markUncertain(); return false; }
  }
  async confirmEnded() {
    if (this.status === 'ended') return true;
    const state = await this.discover(this.roomId, true);
    // A fresh server response permitting creation confirms there is no blocking call.
    return Number(state.callable) === 1;
  }
  async reconnectForEnd() {
    const conn = this.connection;
    if (conn && (!Object.hasOwn(conn, 'socket') || (conn.socket && !conn.socket.destroyed))) return;
    if (!this.serverAddress) throw new Error('VOX 서버 주소가 없습니다.');
    const next = this.newConnection();
    this.connection = next;
    next.on('push', packet => this.queuePush(packet));
    next.on('error', () => this.markUncertain());
    next.on('disconnected', () => this.markUncertain());
    await next.connect(this.serverAddress);
  }
  async end() {
    if (this.status === 'ended') return { status: 'already_ended', title: this.title };
    if (!this.callId || !this.csId || this.callId.isZero() || this.csId.isZero()) throw new Error('이 프로그램의 보이스룸 생성 기록이 없습니다.');
    await this.reconnectForEnd();
    this.status = 'ending'; clearTimeout(this.heartbeat);
    let response;
    try {
      response = ok(await this.connection.request(11008, { userId: long(this.context.userId), devType: 4, csId: this.csId, callId: this.callId,
      reason: 0, netType: 2, chatId: long(this.roomId), csQosInfo: '', csSysInfo: '', arSdkInfo: '', appSumInfo: '', appQosInfo: '', appDetailInfo: '', recInfo: this.recordInfo() }));
    } catch (error) {
      if (!this.serverEnded) {
        let absent = false;
        try { absent = await this.confirmEnded(); } catch {}
        if (!absent) { this.markUncertain(); throw error; }
        this.serverEnded = true;
      }
    }
    if (!this.serverEnded && (String(response.userId) !== String(this.context.userId) || String(response.callId) !== String(this.callId))) {
      this.markUncertain();
      throw new Error('VOX 종료 응답의 통화 ID가 일치하지 않습니다.');
    }
    this.status = 'ended'; await this.close(); return { status: 'end_acknowledged', title: this.title };
  }
  async close() {
    clearTimeout(this.heartbeat);
    this.latestSdp = null;
    const peer = this.pc;
    this.pc = null;
    this.connection?.close();
    this.connection = null;
    if (peer) await peer.close();
  }
}
module.exports = { VoxSession, long, ipv4 };

