'use strict';
const {kakaoId,senderId}=require('../KakaoIdentity');

async function withCurrentMemberRole(client,event) {
  if (event?.room?.isOpenChat !== true || typeof client._carriage?.member !== 'function') return event;
  const roomId=kakaoId(event.room.id),userId=senderId(event);
  if (!roomId || !userId) return event;
  let type=0;
  try {
    const response=await client._carriage.member(roomId,[userId]);
    const body=response?.body;
    if (response?.status != null && response.status !== 0) throw new Error('member lookup failed');
    const members=body?.members ?? body?.memberList ?? body?.memList;
    const member=Array.isArray(members) ? members.find(item=>kakaoId(item.userId ?? item.id ?? item.memberId ?? item.user_id)===userId) : null;
    if (member) type=Number(member.mt ?? member.ut ?? member.userType ?? member.memberType ?? member.linkMemberType ?? 0);
  } catch { /* Do not grant moderator access using stale cached roles after a failed lookup. */ }
  return {...event,sender:{...event.sender,type}};
}

module.exports={withCurrentMemberRole};
