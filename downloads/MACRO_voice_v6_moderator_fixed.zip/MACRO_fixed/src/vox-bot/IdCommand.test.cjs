const {test}=require('node:test');
const assert=require('node:assert/strict');
const {handleIdCommand}=require('../IdCommand');

function fixture(text='!id',attachmentsRaw=[]) {
  const sent=[];
  const client={userId:'999',sendText:async(...args)=>sent.push(args)};
  const msg={message:{text,logId:'321'},sender:{id:'123'},room:{id:'456'},attachmentsRaw};
  return {client,msg,sent};
}

test('plain command reports sender; reply command reports original author',async()=>{
  for(const [extra,expected] of [[[],'123'],[[{src_userId:'987'}],'987']]) {
    const f=fixture('!id',extra);
    assert.equal(await handleIdCommand(f.client,{},f.msg),true);
    assert.deepEqual(f.sent,[['456',`사용자 ID: ${expected}`]]);
  }
});
test('mentions use metadata, preserve long IDs and remove duplicates',async()=>{
  const id='9223372036854775806';
  const f=fixture('!id @사용자',[{mentions:[{user_id:id},{user_id:id}]}]);
  await handleIdCommand(f.client,{},f.msg);
  assert.equal(f.sent[0][1],`사용자 ID: ${id}`);
});
test('typed nickname without metadata never falls back to sender',async()=>{
  const f=fixture('!id @사용자');await handleIdCommand(f.client,{},f.msg);
  assert.match(f.sent[0][1],/실제로 멘션/);
});
test('explicit mention takes priority over replied message',async()=>{
  const f=fixture('!id @사용자',[{src_userId:'987',mentions:[{user_id:'654'}]}]);
  await handleIdCommand(f.client,{},f.msg);assert.equal(f.sent[0][1],'사용자 ID: 654');
});
test('unsafe numeric reply IDs do not report rounded values or sender',async()=>{
  const f=fixture('!id',[{src_userId:9223372036854775806}]);
  await handleIdCommand(f.client,{},f.msg);assert.match(f.sent[0][1],/확인할 수 없습니다/);
});
test('responds using Kakao reply API when available',async()=>{
  const f=fixture();f.client.sendReply=async(...args)=>f.sent.push(args);
  await handleIdCommand(f.client,{},f.msg);assert.deepEqual(f.sent,[['456','사용자 ID: 123',f.msg]]);
});
test('unrelated messages and own messages produce no output',async()=>{
  for(const text of ['!identity','안녕하세요']) {
    const f=fixture(text);assert.equal(await handleIdCommand(f.client,{},f.msg),false);assert.equal(f.sent.length,0);
  }
  const f=fixture();f.msg.sender.id='999';await handleIdCommand(f.client,{},f.msg);assert.equal(f.sent.length,0);
});
test('JSON attachments and alternate userId mention field are supported',async()=>{
  const f=fixture('!id @사용자',[JSON.stringify({mentions:[{userId:'678'}]})]);
  await handleIdCommand(f.client,{},f.msg);assert.equal(f.sent[0][1],'사용자 ID: 678');
});
test('send failures propagate to existing BotManager error handler',async()=>{
  const f=fixture();f.client.sendText=async()=>{throw Error('offline')};
  await assert.rejects(handleIdCommand(f.client,{},f.msg),/offline/);
});

test('raw JSON keeps exact numeric mention and reply IDs even when parsed aliases were rounded',async()=>{
  const id='9223372036854775806';
  for(const [text,attachment,alias] of [
    ['!id @사용자',`{"mentions":[{"user_id":${id}}]}`,{mentions:[{user_id:Number(id)}]}],
    ['!id',`{"src_userId":${id}}`,{src_userId:Number(id)}],
  ]) {
    const f=fixture(text,[alias]);f.msg.raw={chatLog:{attachment}};
    await handleIdCommand(f.client,{},f.msg);
    assert.equal(f.sent[0][1],`사용자 ID: ${id}`);
  }
});

test('raw BSON author is used instead of an inaccurate normalized sender alias',async()=>{
  const {long}=require('./VoxSession');
  const id='9223372036854775806',f=fixture();
  f.msg.sender.id=String(Number(id));
  f.msg.raw={chatLog:{authorId:long(id)}};
  await handleIdCommand(f.client,{},f.msg);
  assert.equal(f.sent[0][1],`사용자 ID: ${id}`);
});

test('values beyond Kakao signed int64 range are never returned as usable IDs',async()=>{
  const f=fixture('!id',[{src_userId:'9223372036854775808'}]);
  await handleIdCommand(f.client,{},f.msg);
  assert.match(f.sent[0][1],/확인할 수 없습니다/);
});

test('a reply without readable target metadata never reports the command sender instead',async()=>{
  const f=fixture();f.msg.message.type=26;
  await handleIdCommand(f.client,{},f.msg);
  assert.match(f.sent[0][1],/확인할 수 없습니다/);
});

test('ID output round trips through panel settings and authorizes the same user',async()=>{
  const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
  const VoiceSettings=require('./VoiceSettings.cjs');
  const {createVoiceRoomCommands}=require('./VoiceRoomCommands.cjs');
  const {long}=require('./VoxSession');
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'voice-id-policy-'));
  try {
    const settings=new VoiceSettings(directory),id='9223372036854775806';
    const f=fixture();f.msg.raw={chatLog:{authorId:long(id)}};
    await handleIdCommand(f.client,{},f.msg);
    const returned=f.sent[0][1].split(': ')[1];
    for(const global of [false,true]) {
      settings.save('a',[{roomId:'456',operatorIds:global?[]:[returned]}],global?[returned]:[]);
      const saved=settings.get('a');
      const authorize=createVoiceRoomCommands({rooms:settings.effective(saved.rooms,saved.globalOperatorIds)});
      const event={...f.msg,room:{id:'456',isOpenChat:true},message:{type:1,logId:'654',text:'!보룸자동 테스트'}};
      assert.equal(authorize(event).status,'authorized');
      assert.equal(authorize({...event,raw:{chatLog:{authorId:long('789')}},message:{...event.message,logId:'655'}}).status,'forbidden');
    }
  } finally { fs.rmSync(directory,{recursive:true,force:true}); }
});

test('only configured voice bot accounts reply, including before operator registration',async()=>{
  const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
  const VoiceSettings=require('./VoiceSettings.cjs');
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'voice-id-account-'));
  try {
    const settings=new VoiceSettings(directory),f=fixture();f.msg.room.isOpenChat=true;
    settings.save('voice-bot',[]);
    assert.equal(await settings.idCommand('macro-only',f.client,{},f.msg),false);
    assert.equal(f.sent.length,0);
    assert.equal(await settings.idCommand('voice-bot',f.client,{},f.msg),true);
    assert.equal(f.sent.length,1);
    f.msg.room.isOpenChat=false;
    assert.equal(await settings.idCommand('voice-bot',f.client,{},f.msg),false);
    assert.equal(f.sent.length,1);
    fs.writeFileSync(settings.file,'{}');f.msg.room.isOpenChat=true;
    assert.equal(await settings.idCommand('voice-bot',f.client,{},f.msg),false);
  } finally { fs.rmSync(directory,{recursive:true,force:true}); }
});
