@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js 24 is required.
  pause
  exit /b 1
)
if not defined MACRO_TOKEN (
  echo [ERROR] Set MACRO_TOKEN to your existing panel administrator password.
  pause
  exit /b 1
)
if not exist "vendor\KakaoForge\node_modules\bson\package.json" (
  pushd "vendor\KakaoForge"
  call npm ci --omit=dev
  if errorlevel 1 (
    popd
    exit /b 1
  )
  popd
)
if not exist "node_modules\werift\package.json" (
  call npm ci --omit=dev
  if errorlevel 1 exit /b 1
)
call npm start
pause
