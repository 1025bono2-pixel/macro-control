let token=localStorage.token||'',role='',me=null,editing=null,authView='login';const $=id=>document.getElementById(id),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const _apiMem=new Map(),_apiPending=new Map();let _activePage='',_pageSeq=0;
function invalidateApiCache(){_apiMem.clear()}
async function api(u,o={}){const method=(o.method||'GET').toUpperCase(),key=method+'|'+u,now=Date.now();o.headers={...(o.headers||{}),Authorization:`Bearer ${token}`};if(o.body&&!o.raw)o.headers['Content-Type']='application/json';if(method==='GET'&&!o.noCache){const hit=_apiMem.get(key);if(hit&&now-hit.at<12000)return hit.data;if(_apiPending.has(key))return _apiPending.get(key)}const task=(async()=>{const r=await fetch(u,o),d=await r.json();if(!r.ok)throw new Error(d.error||r.status);if(method==='GET')_apiMem.set(key,{at:Date.now(),data:d});else invalidateApiCache();return d})();if(method==='GET')_apiPending.set(key,task);try{return await task}finally{if(method==='GET'&&_apiPending.get(key)===task)_apiPending.delete(key)}}
async function fetchJson(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),d=await r.json();if(!r.ok)throw new Error(d.error||'오류');return d}
function cachedApi(u){return _apiMem.get('GET|'+u)?.data}
function loadingShell(label='불러오는 중...'){$('content').innerHTML=`<div class="tile muted page-loading">${esc(label)}</div>`}
function authMode(v){authView=v;$('loginTab').classList.toggle('active',v==='login');$('joinTab').classList.toggle('active',v==='join');$('authButton').textContent=v==='login'?'로그인':'회원가입';$('authError').textContent=''}async function submitAuth(){try{const u=$('username').value.trim(),p=$('password').value;if(authView==='join'){await fetchJson('/api/register',{username:u,password:p});authMode('login');$('authError').style.color='#48c78e';$('authError').textContent='가입 완료! 로그인하세요.';return}const d=await fetchJson('/api/login',{username:u,password:p});token=d.token;localStorage.token=token;await openApp()}catch(e){$('authError').textContent=e.message}}function logout(){localStorage.removeItem('token');location.reload()}
async function openApp(){me=await api('/api/me');role=me.role;$('auth').classList.add('hidden');$('app').classList.remove('hidden');$('adminNav').classList.toggle('hidden',role!=='admin');$('voiceNav').classList.toggle('hidden',role!=='admin');page('dashboard');startNoticeWatcher()}
async function page(p){
 if((p==='admin'||p==='voice')&&role!=='admin')return;
 _activePage=p;const seq=++_pageSeq;stopDashboardMacroTimer();stopDetailLive();
 $('content').classList.toggle('dashboard-content',p==='dashboard');
 const titles={dashboard:'대시보드',macros:'매크로',keywords:'키워드 매크로',admin:'총괄 관리',voice:'보룸봇 설정',settings:'설정',help:'도움말',notices:'공지사항'};$('title').textContent=titles[p]||'MACRO';
 if(p==='dashboard'){const st=cachedApi('/api/status'),recent=cachedApi('/api/macro/recent');if(st)renderDashboard(st,recent||[]);else loadingShell('대시보드를 불러오는 중...');return requestAnimationFrame(()=>dashboard(seq))}
 if(p==='macros'||p==='keywords'){const st=cachedApi('/api/status'),all=cachedApi('/api/macros'),kind=p==='keywords'?'keyword':'schedule';window._macroKind=kind;if(st&&all){window._accounts=st.accounts;window._macros=all;renderMacroList()}else loadingShell(p==='keywords'?'키워드 매크로를 불러오는 중...':'매크로를 불러오는 중...');return requestAnimationFrame(()=>macroPage(kind,seq))}
 loadingShell();requestAnimationFrame(()=>{if(seq!==_pageSeq)return;if(p==='admin')adminPage();else if(p==='voice')return voiceSettingsPage();if(p==='settings')settingsPage();else if(p==='help')helpPage();else if(p==='notices')noticesPage()});
}
function fmtRemain(ms){if(ms==null)return'무제한';const h=Math.max(0,Math.floor(ms/3600000)),d=Math.floor(h/24);return`${d}일 ${h%24}시간`}function licHtml(l){return l?.active?`<span class="license-good">● 활성</span> · <b>${fmtRemain(l.remainingMs)}</b>`:`<span class="bad">● 비활성</span>`}
let _dashboardMacroTimer=null;
function stopDashboardMacroTimer(){if(_dashboardMacroTimer){clearInterval(_dashboardMacroTimer);_dashboardMacroTimer=null}}
function macroStatusText(x){if(x.status==='SUCCESS')return 'SUCCESS';if(x.status==='SKIPPED_CONSECUTIVE_GUARD')return 'SKIPPED';if(x.status==='ERROR')return 'ERROR';return String(x.status||'EVENT')}
function renderMacroConsole(rows){
  const box=$('macroConsoleRows');if(!box)return;
  const oldTop=box.scrollTop,atBottom=(box.scrollHeight-box.clientHeight-oldTop)<12;
  box.innerHTML=(rows||[]).map((x,i)=>`<div class="macro-console-line ${i>=6?'console-old':''}"><span class="console-time">${esc(String(x.at||'').replace('T',' ').slice(11,19)||'--:--:--')}</span><span class="console-status status-${esc(macroStatusText(x).toLowerCase())}">[${esc(macroStatusText(x))}]</span><span class="console-name">${esc(x.name||x.macroId||'매크로')}</span><span class="console-room">${esc(x.accountName||'')}${x.roomName||x.roomId?' · '+esc(x.roomName||x.roomId):''}</span></div>`).join('')||'<div class="console-empty">아직 매크로 실행 기록이 없습니다.</div>';
  if(atBottom)box.scrollTop=0;
}
async function refreshDashboardMacro(){try{renderMacroConsole(await api('/api/macro/recent'))}catch{}}
function renderDashboard(s,recent=[]){if(_activePage!=='dashboard')return;$('accountBadge').innerHTML=role==='user'?licHtml(me?.license):'SUPER ADMIN';$('content').innerHTML=`<div class="dashboard-layout"><div class="dashboard-main">${role==='user'?`<div class="tile license-summary"><b>라이선스</b><div>${licHtml(me?.license)}</div></div>`:role==='admin'?`<div class="buttons" style="margin-bottom:16px"><button class="accent" onclick="restartAllBots()">↻ 모든 봇 일괄 재시작</button></div>`:''}<div class="grid">${(s.accounts||[]).map(a=>`<div class="tile"><div class="${a.online?'online':'muted'}">● ${a.online?'온라인':'오프라인'}</div><h3>${esc(a.displayName)}</h3><div class="muted">${a.online?'연결됨':'연결 안 됨'}</div>${role==='admin'?`<button onclick="botDetail('${a.key}')">⋯ 상세 정보</button> <button class="${a.online?'danger':'accent'}" onclick="botControl('${a.key}','${a.online?'stop':'start'}')">${a.online?'끄기':'켜기'}</button> <button onclick="botControl('${a.key}','restart')">재시작</button>`:`<button onclick="userRestartBot('${a.key}')">↻ 내 봇 재시작</button>`}</div>`).join('')||'<div class="tile muted">할당된 봇이 없습니다.</div>'}</div></div><aside class="macro-console"><div class="console-head"><div><span class="console-dot"></span> MACRO ACTIVITY</div><span class="console-live">LIVE</span></div><div id="macroConsoleRows" class="macro-console-rows"></div><div class="console-fade console-fade-bottom"></div></aside></div>`;renderMacroConsole(recent)}
async function dashboard(seq=_pageSeq){try{const[s,recent,newMe]=await Promise.all([api('/api/status'),api('/api/macro/recent').catch(()=>[]),api('/api/me')]);if(seq!==_pageSeq||_activePage!=='dashboard')return;me=newMe;renderDashboard(s,recent);stopDashboardMacroTimer();_dashboardMacroTimer=setInterval(()=>{if(_activePage==='dashboard')refreshDashboardMacro()},10000)}catch(e){if(seq===_pageSeq&&_activePage==='dashboard'&&!cachedApi('/api/status'))$('content').innerHTML=`<div class="tile"><b>${esc(e.message)}</b></div>`}}

async function roomOptions(account,selected=''){if(!account)return'';const rooms=await api('/api/rooms?account='+encodeURIComponent(account));return rooms.map(r=>`<option value="${esc(r.roomId)}" data-name="${esc(r.roomName)}" ${String(r.roomId)===String(selected)?'selected':''}>${esc(r.roomName)}</option>`).join('')||'<option value="">확인된 채팅방이 없습니다</option>'}
async function macroPage(kind,seq=_pageSeq){editing=null;try{const[s,all]=await Promise.all([api('/api/status'),api('/api/macros')]);if(seq!==_pageSeq||!['macros','keywords'].includes(_activePage))return;window._accounts=s.accounts;window._macros=all;window._macroKind=kind;window._macroBotFilter=window._macroBotFilter||'all';renderMacroList()}catch(e){if(seq===_pageSeq)$('content').innerHTML=`<div class="tile"><b>${esc(e.message)}</b><p class="muted">설정에서 라이선스를 확인하세요.</p></div>`}}

function renderMacroList(){const kind=window._macroKind,all=window._macros||[],accounts=window._accounts||[];if(window._macroBotFilter!=='all'&&!accounts.some(a=>a.key===window._macroBotFilter))window._macroBotFilter='all';const list=all.filter(x=>x.kind===kind&&(window._macroBotFilter==='all'||x.accountKey===window._macroBotFilter));$('content').innerHTML=`<button class="accent" onclick="editor('${kind}')">＋ ${kind==='keyword'?'키워드 매크로':'매크로'} 만들기</button>${role==='admin'?`<div class="detail-tabs macro-bot-tabs"><button class="${window._macroBotFilter==='all'?'active':''}" onclick="setMacroBotFilter('all')">전체</button>${accounts.map(a=>`<button class="${window._macroBotFilter===a.key?'active':''}" onclick="setMacroBotFilter('${a.key}')">${esc(a.displayName)}</button>`).join('')}</div>`:''}<div id="editor"></div><h3>목록</h3>${list.map(x=>{const an=accounts.find(a=>a.key===x.accountKey)?.displayName||x.accountKey;return`<div class="row ${x.enabled?'running':''}"><div><b>${esc(x.name)}</b> ${x.enabled?'<span class="runbadge">실행 중</span>':''}${role==='admin'?` <span class="muted">· ${esc(an)}</span>`:''}<div class="muted">${esc(x.roomName)}${kind==='keyword'?' · 키워드: '+esc(x.keyword):''}</div></div><div><button onclick="editMacro('${x.id}','${kind}')">수정</button> <button class="${x.enabled?'danger':'accent'}" onclick="toggleMacro('${x.id}',${!x.enabled},'${kind}')">${x.enabled?'실행 취소':'실행'}</button> <button class="danger" onclick="delMacro('${x.id}','${kind}')">삭제</button></div></div>`}).join('')||'<div class="tile muted">선택한 봇에 등록된 매크로가 없습니다.</div>'}`}
function setMacroBotFilter(key){window._macroBotFilter=key;renderMacroList()}
async function editor(kind,item={}){editing=item.id||null;const acc=item.accountKey||window._accounts?.[0]?.key||'';$('editor').innerHTML=`<div class="tile form"><h3>${editing?'매크로 수정':'새 매크로'}</h3><label>이름<input id="mn" value="${esc(item.name||'')}"></label><label>봇<select id="ma" onchange="loadRooms()">${(window._accounts||[]).map(a=>`<option value="${esc(a.key)}" ${a.key===acc?'selected':''}>${esc(a.displayName)}</option>`).join('')}</select></label><label>채팅방<select id="mr"></select></label><div class="buttons"><button onclick="refreshRooms()">↻ 채팅방 새로고침</button><span id="roomSyncStatus" class="muted"></span></div>${kind==='keyword'?`<label>키워드<input id="kw" value="${esc(item.keyword||'')}" placeholder="이 단어가 포함되면 실행"></label>`:''}<label>보낼 텍스트<textarea id="mt" rows="5">${esc(item.text||'')}</textarea></label><div class="photo-box"><b>사진 (선택)</b><div id="photoState" class="muted">${item.photoPath?'사진 등록됨':'사진 없음'}</div><img id="photoPreview" class="photo-preview ${item.photoPath?'':'hidden'}"><input id="photoFile" type="file" accept="image/*" class="hidden" onchange="uploadPhoto(this)"><button onclick="document.getElementById('photoFile').click()">＋ 사진 추가하기</button><input id="photoPath" type="hidden" value="${esc(item.photoPath||'')}"></div>${kind==='schedule'?`<label>실행 방식<select id="st" onchange="scheduleField()"><option value="interval" ${item.schedule?.type!=='daily'?'selected':''}>몇 초마다</option><option value="daily" ${item.schedule?.type==='daily'?'selected':''}>매일 정해진 시간</option></select></label><div id="sf"></div><div class="guard-box"><label class="check-row"><input id="acEnabled" type="checkbox" ${item.antiConsecutive?.enabled?'checked':''}> 연속 메시지 방지</label><div class="muted">이 매크로가 발송된 뒤, 아래 개수만큼 다른 메시지가 올라와야 다음 자동발송을 허용합니다.</div><label>필요한 메시지 수<select id="acCount">${[1,2,3,4,5].map(n=>`<option value="${n}" ${Number(item.antiConsecutive?.minMessages||1)===n?'selected':''}>${n}개</option>`).join('')}</select></label></div>`:''}<div class="buttons"><button class="accent" onclick="saveMacro('${kind}')">저장</button><button onclick="document.getElementById('editor').innerHTML=''">취소</button></div></div>`;await loadRooms(item.roomId||'');if(kind==='schedule')scheduleField(item.schedule)}
async function uploadPhoto(inp){const f=inp.files?.[0];if(!f)return;const img=$('photoPreview');img.src=URL.createObjectURL(f);img.classList.remove('hidden');$('photoState').textContent=f.name+' · 업로드 중...';const fd=new FormData();fd.append('photo',f);try{const r=await fetch('/api/upload/photo',{method:'POST',headers:{Authorization:`Bearer ${token}`},body:fd}),d=await r.json();if(!r.ok)throw new Error(d.error);$('photoPath').value=d.photoPath;$('photoState').textContent='사진 등록됨 · '+f.name}catch(e){$('photoState').textContent='업로드 실패: '+e.message}}
async function loadRooms(selected=''){if(!$('mr'))return;try{$('mr').innerHTML=await roomOptions($('ma').value,selected)}catch(e){$('mr').innerHTML='<option>방 목록 오류</option>'}}async function refreshRooms(){const a=$('ma').value,n=$('roomSyncStatus');n.textContent='동기화 중...';try{const x=await api('/api/rooms/refresh',{method:'POST',body:JSON.stringify({account:a})});await loadRooms();n.textContent=`${x.stored}개 방 확인됨`}catch(e){n.textContent=e.message}}
function scheduleField(e){const d=$('st').value==='daily';$('sf').innerHTML=d?`<label>시간<input id="sv" type="time" value="${esc(e?.time||'18:00')}"></label>`:`<label>반복 간격 (초)<input id="sv" type="number" min="5" value="${esc(e?.seconds||e?.minutes*60||60)}"></label>`}async function saveMacro(kind){const r=$('mr'),o=r.options[r.selectedIndex],body={id:editing||undefined,kind,name:$('mn').value,accountKey:$('ma').value,roomId:r.value,roomName:o?.dataset.name||o?.text||'',text:$('mt').value,photoPath:$('photoPath').value,keyword:kind==='keyword'?$('kw').value:'',schedule:kind==='schedule'?($('st').value==='daily'?{type:'daily',time:$('sv').value}:{type:'interval',seconds:Number($('sv').value)}):undefined,antiConsecutive:kind==='schedule'?{enabled:$('acEnabled').checked,minMessages:Number($('acCount').value)}:undefined};try{await api('/api/macros',{method:'POST',body:JSON.stringify(body)});page(kind==='keyword'?'keywords':'macros')}catch(e){alert(e.message)}}async function editMacro(id,k){await editor(k,window._macros.find(x=>x.id===id))}async function toggleMacro(id,enabled,k){try{await api(`/api/macros/${id}/toggle`,{method:'POST',body:JSON.stringify({enabled})});page(k==='keyword'?'keywords':'macros')}catch(e){alert(e.message)}}async function delMacro(id,k){if(confirm('삭제할까요?')){await api('/api/macros/'+id,{method:'DELETE'});page(k==='keyword'?'keywords':'macros')}}
async function adminPage(){stopDashboardMacroTimer();if(role!=='admin')return;const[s,users,licenses]=await Promise.all([api('/api/status'),api('/api/admin/users'),api('/api/admin/licenses')]);window._adminAccounts=s.accounts;window._adminUsers=users;$('content').innerHTML=`<div class="tile form"><h3>＋ 카카오 봇 계정 추가</h3><label>봇 이름<input id="newName" placeholder="예: Bot_1"></label><button class="accent" onclick="addBot()">QR로 봇 연결하기</button><div class="muted">내부 계정 키는 자동 생성됩니다.</div></div><details class="admin-section" open><summary><h3>봇 계정</h3><span class="admin-chevron">⌄</span></summary><div class="admin-section-body">${s.accounts.map(a=>`<div class="row"><div><b>${esc(a.displayName)}</b><div class="muted">${a.online?'● 온라인':'○ 오프라인'}</div></div><div><button onclick="botDetail('${a.key}')">⋯ 기록/정보</button> <button onclick="renameBot('${a.key}','${esc(a.displayName)}')">이름 변경</button> <button class="danger" onclick="deleteBot('${a.key}','${esc(a.displayName)}')">삭제</button> ${a.online?`<button class="danger" onclick="bot('${a.key}','stop')">끄기</button>`:`<button class="accent" onclick="bot('${a.key}','start')">켜기</button>`}</div></div>`).join('')||'<div class="tile muted">봇 계정 없음</div>'}</div></details><details class="admin-section" open><summary><h3>회원</h3><span class="admin-chevron">⌄</span></summary><div class="admin-section-body">${users.map(x=>`<div class="row"><div><b>${esc(x.username)}</b><div>${licHtml(x.license)}</div><div class="muted">할당 봇 ${(x.accounts||[]).length}개</div></div><div><button onclick="userDetail('${x.id}')">⋯ 기록/정보</button> <button onclick='userEditor(${JSON.stringify(x)})'>봇 할당</button> <button class="danger" onclick="deleteUser('${x.id}','${esc(x.username)}')">삭제</button></div></div>`).join('')||'<div class="tile muted">회원 없음</div>'}<div id="userEditor"></div></div></details><details class="admin-section" open><summary><h3>라이선스</h3><span class="admin-chevron">⌄</span></summary><div class="admin-section-body"><div class="tile"><button class="accent" onclick="issue('30d')">30일 발급</button> <button onclick="issue('lifetime')">Lifetime 발급</button></div>${licenses.slice().reverse().map(l=>`<div class="row"><div><b>${esc(l.key)}</b><div class="muted">${l.type==='lifetime'?'Lifetime':'30일'} · ${l.userId?'사용자: '+esc(l.displayName||l.username||l.userId):'미사용'}${l.revoked?' · 폐기됨':''}</div></div><div>${!l.revoked?`<button class="danger" onclick="revokeLicense('${esc(l.key)}')">폐기</button>`:''}</div></div>`).join('')}</div></details>`}
async function addBot(){try{const d=await api('/api/admin/account/add',{method:'POST',body:JSON.stringify({displayName:$('newName').value})});alert(d.message)}catch(e){alert(e.message)}}function renameBot(k,n){const v=prompt('봇 이름',n);if(v)api('/api/admin/account',{method:'POST',body:JSON.stringify({key:k,displayName:v})}).then(adminPage)}async function bot(k,a){await api(`/api/admin/bot/${k}/${a}`,{method:'POST'});setTimeout(adminPage,500)}function assignedBotOwnerMap(excludeUserId){const out={};for(const u of (window._adminUsers||[])){if(String(u.id)===String(excludeUserId))continue;for(const k of (u.accounts||[]))out[String(k)]=u.username||u.displayName||'다른 회원'}return out}
function renderUserBotAssignments(x,showAssigned=false){const host=$('userBotAssignments');if(!host)return;const owners=assignedBotOwnerMap(x.id);host.innerHTML=(window._adminAccounts||[]).filter(a=>(x.accounts||[]).includes(a.key)||!owners[String(a.key)]||showAssigned).map(a=>{const mine=(x.accounts||[]).includes(a.key),owner=owners[String(a.key)];return`<label class="assignment-row ${owner&&!mine?'assigned-other':''}"><span>${esc(a.displayName)}${owner&&!mine?` <small class="muted">· ${esc(owner)}에게 적용됨</small>`:''}</span><input type="checkbox" name="ua" value="${esc(a.key)}" ${mine?'checked':''} ${owner&&!mine?'disabled':''}></label>`}).join('')||'<div class="muted">할당 가능한 봇이 없습니다.</div>'}
function toggleAssignedBots(x){renderUserBotAssignments(x,$('showAssignedBots')?.checked===true)}
function userEditor(x){$('userEditor').innerHTML=`<div class="tile form assignment-editor"><div class="assignment-title"><h3>${esc(x.username)} 봇 할당</h3><label class="show-assigned"><input type="checkbox" id="showAssignedBots"> 적용된 봇 표시</label></div><label class="check-row"><input type="checkbox" id="userEnabled" ${x.enabled!==false?'checked':''}> 계정 사용 허용</label><div id="userBotAssignments"></div><button class="accent" onclick="saveUser('${x.id}')">저장</button></div>`;$('showAssignedBots').onchange=()=>toggleAssignedBots(x);renderUserBotAssignments(x,false)}
async function saveUser(id){const accounts=[...document.querySelectorAll('input[name=ua]:checked')].map(x=>x.value);await api('/api/admin/users/'+id,{method:'POST',body:JSON.stringify({accounts,enabled:$('userEnabled')?.checked!==false})});adminPage()}async function issue(type){const x=await api('/api/admin/licenses',{method:'POST',body:JSON.stringify({type})});await navigator.clipboard?.writeText(x.key).catch(()=>{});alert('발급 완료\n'+x.key);adminPage()}
function showModal(html){$('modalBody').innerHTML=html;$('modal').classList.remove('hidden')}function closeModal(){stopDetailLive();_detailKey=null;$('modal').classList.add('hidden')}let _botDetailData=null,_botDetailTab='messages';
function fmtObj(v){try{return esc(JSON.stringify(v,null,2))}catch{return esc(String(v??''))}}
function msgDirection(m){return m.direction==='SENT'?'발송':m.direction==='RECEIVED'?'수신':'기타'}
function eventRows(a,names){const set=new Set(names);return (a.rooms||[]).flatMap(r=>(r.events||[]).filter(e=>set.has(String(e.event||'').toUpperCase())).map(e=>({...e,roomName:r.roomName,roomId:r.roomId}))).sort((x,y)=>String(y.savedAt||'').localeCompare(String(x.savedAt||'')))}
function eventCards(rows,empty){return rows.map(e=>`<div class="tile"><b>${esc(e.event||'EVENT')}</b> · ${esc(e.roomName||e.roomId||'')}<div class="muted">${esc(e.savedAt||'-')}</div><pre>${fmtObj(e.payload)}</pre></div>`).join('')||`<div class="muted">${empty}</div>`}

function parseAttachment(v){if(!v)return null;if(typeof v==='object')return v;if(typeof v==='string'){try{return JSON.parse(v)}catch{return{raw:v}}}return null}
function mediaSize(n){n=Number(n||0);if(!n)return'';if(n<1024)return n+' B';if(n<1048576)return(n/1024).toFixed(1)+' KB';return(n/1048576).toFixed(1)+' MB'}
function safeMediaUrl(v){const s=String(v||'');return /^https:\/\/talk\.kakaocdn\.net\//i.test(s)?s:''}
function attachmentMedia(a){
  a=parseAttachment(a);if(!a)return'';
  const items=[];
  const push=(kind,url,thumb='',meta={})=>{url=safeMediaUrl(url);thumb=safeMediaUrl(thumb);if(url)items.push({kind,url,thumb,meta})};
  if(Array.isArray(a.imageUrls))a.imageUrls.forEach((u,i)=>push('image',u,a.thumbnailUrls?.[i],{w:a.wl?.[i],h:a.hl?.[i],size:a.sl?.[i],mime:a.mtl?.[i]}));
  else if(a.url&&(String(a.mt||'').startsWith('image/')||a.thumbnailUrl))push('image',a.url,a.thumbnailUrl,{w:a.w,h:a.h,size:a.s,mime:a.mt});
  const videoUrl=a.videoUrl||a.vurl||a.video_url||(String(a.mt||'').startsWith('video/')?a.url:'');
  if(videoUrl)push('video',videoUrl,a.thumbnailUrl||a.thumbnailUrls?.[0],{w:a.w,h:a.h,size:a.s,mime:a.mt});
  const audioUrl=a.audioUrl||a.aurl||a.audio_url||(String(a.mt||'').startsWith('audio/')?a.url:'');
  if(audioUrl)push('audio',audioUrl,'',{size:a.s,mime:a.mt});
  const fileUrl=a.fileUrl||a.downloadUrl||a.download_url||((a.url&&!items.length)?a.url:'');
  if(fileUrl&&!items.some(x=>x.url===safeMediaUrl(fileUrl)))push('file',fileUrl,'',{size:a.s,mime:a.mt,name:a.name||a.filename||a.fileName});
  if(!items.length)return`<details class="raw-attachment"><summary>첨부파일 보기</summary><pre>${fmtObj(a)}</pre></details>`;
  return `<div class="attachment-gallery">${items.map(x=>{
    const meta=[x.meta.mime,x.meta.w&&x.meta.h?`${x.meta.w}×${x.meta.h}`:'',mediaSize(x.meta.size)].filter(Boolean).join(' · ');
    if(x.kind==='image')return`<figure class="attachment-item"><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer"><img loading="lazy" src="${esc(x.thumb||x.url)}" data-full="${esc(x.url)}" onerror="if(this.dataset.full&&this.src!==this.dataset.full)this.src=this.dataset.full"></a>${meta?`<figcaption>${esc(meta)}</figcaption>`:''}</figure>`;
    if(x.kind==='video')return`<figure class="attachment-item"><video controls preload="metadata" ${x.thumb?`poster="${esc(x.thumb)}"`:''} src="${esc(x.url)}"></video>${meta?`<figcaption>${esc(meta)}</figcaption>`:''}</figure>`;
    if(x.kind==='audio')return`<div class="attachment-item attachment-audio"><audio controls preload="metadata" src="${esc(x.url)}"></audio>${meta?`<div class="muted">${esc(meta)}</div>`:''}</div>`;
    return`<div class="attachment-item attachment-file"><b>${esc(x.meta.name||'첨부 파일')}</b>${meta?`<div class="muted">${esc(meta)}</div>`:''}<a class="media-open" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">파일 열기</a></div>`;
  }).join('')}</div><details class="raw-attachment"><summary>첨부파일 보기</summary><pre>${fmtObj(a)}</pre></details>`;
}

let _detailLiveTimer=null,_detailKey=null;
function stopDetailLive(){if(_detailLiveTimer){clearInterval(_detailLiveTimer);_detailLiveTimer=null}}
async function refreshBotDetailLive(){
  if(!_detailKey||role!=='admin'||$('modal')?.classList.contains('hidden'))return;
  const input=$('detailMessageSearch'),sel=$('detailMediaFilter');
  const state={q:input?.value||'',filter:sel?.value||'all',focus:document.activeElement===input,start:input?.selectionStart??0,end:input?.selectionEnd??0,open:[...document.querySelectorAll('.room-record[open]')].map(x=>x.dataset.roomid)};
  try{
    _botDetailData=await api('/api/admin/detail/bot/'+encodeURIComponent(_detailKey));
    renderBotDetail();
    const ni=$('detailMessageSearch'),ns=$('detailMediaFilter');
    if(ni)ni.value=state.q;if(ns)ns.value=state.filter;
    state.open.forEach(id=>{const d=document.querySelector(`.room-record[data-roomid="${CSS.escape(String(id))}"]`);if(d)d.open=true});
    filterDetailMessages();
    if(state.focus&&ni){ni.focus();ni.setSelectionRange(state.start,state.end)}
  }catch{}
}
function startDetailLive(key){stopDetailLive();if(role!=='admin')return;_detailKey=key;_detailLiveTimer=setInterval(refreshBotDetailLive,3000)}
function messageSearchControls(){return `<div class="message-tools"><input id="detailMessageSearch" placeholder="메시지 · 보낸 사람 · 채팅방 검색" oninput="filterDetailMessages()"><select id="detailMediaFilter" onchange="filterDetailMessages()"><option value="all">전체</option><option value="text">텍스트</option><option value="media">첨부파일</option></select><span id="detailSearchStatus" class="muted">3초마다 자동 갱신</span></div>`}
function filterDetailMessages(){
  const q=String($('detailMessageSearch')?.value||'').trim().toLocaleLowerCase('ko-KR');
  const f=$('detailMediaFilter')?.value||'all';
  document.querySelectorAll('.room-record').forEach(room=>{
    let visible=0;
    room.querySelectorAll('.msg[data-search]').forEach(el=>{
      const hay=String(el.dataset.search||'').toLocaleLowerCase('ko-KR');
      const media=el.dataset.media==='1';
      const typeOk=f==='all'||(f==='media'&&media)||(f==='text'&&!media);
      const show=typeOk&&(!q||hay.includes(q));
      el.hidden=!show;
      el.style.display=show?'':'none';
      if(show)visible++;
    });
    const roomHay=String(room.dataset.roomsearch||'').toLocaleLowerCase('ko-KR');
    const roomOnlyMatch=!!q&&roomHay.includes(q);
    if(roomOnlyMatch&&visible===0){
      room.querySelectorAll('.msg[data-search]').forEach(el=>{
        const media=el.dataset.media==='1';
        const typeOk=f==='all'||(f==='media'&&media)||(f==='text'&&!media);
        if(typeOk){el.hidden=false;el.style.display='';visible++}
      });
    }
    const showRoom=!q&&f==='all' ? true : visible>0;
    room.hidden=!showRoom;
    room.style.display=showRoom?'':'none';
    if((q||f!=='all')&&showRoom)room.open=true;
  });
  const rooms=[...document.querySelectorAll('.room-record')];
  const count=rooms.filter(x=>!x.hidden).length;
  const status=$('detailSearchStatus');
  if(status)status.textContent=(q||f!=='all')?`검색 결과 ${count}개 채팅방`:'';
}
function renderBotDetail(){const d=_botDetailData;if(!d)return;const a=d.archive||{rooms:[],totals:{}},acc=d.account||{},l=d.loco||{},caps=l.capabilities||{};const tabs=[['messages','메시지'],['hidden','삭제·숨김'],['reactions','리액션'],['rooms','채팅방'],['members','사용자 정보'],['events','기타 이벤트'],['media','첨부/미디어'],['macros','매크로'],['account','봇 정보'],['connection','연결·오류'],['raw','RAW/진단']];let body='';
if(_botDetailTab==='messages'){body=`${messageSearchControls()}<div class="grid"><div class="tile">수신<b class="big">${a.totals?.received||0}</b></div><div class="tile">발송<b class="big">${a.totals?.sent||0}</b></div><div class="tile">전체<b class="big">${a.totals?.total||0}</b></div></div><h3>방별 메시지</h3>${(a.rooms||[]).map(r=>`<details class="tile room-record" data-roomid="${esc(r.roomId||'')}" data-roomsearch="${esc(`${r.roomName||''} ${r.roomId||''}`.toLowerCase())}"><summary><b>${esc(r.roomName||r.roomId)}</b> · 수신 ${r.received||0} / 발송 ${r.sent||0} / 전체 ${r.total||0}</summary><div class="message-list">${(r.latest||[]).map(m=>`<div class="msg ${m.direction==='SENT'?'msg-sent':'msg-received'}" data-media="${m.attachment||m.kind==='photo'?'1':'0'}" data-search="${esc(`${r.roomName||''} ${r.roomId||''} ${m.senderName||''} ${m.senderId||''} ${m.text||''} ${m.savedAt||''} ${m.messageId||''} ${m.messageType??m.kind??''}`.toLowerCase())}"><div class="msg-head"><b>${msgDirection(m)}</b><span>${esc(m.senderName||m.senderId||'')}</span></div><div class="msg-text">${esc(m.text||((m.kind==='photo')?'[사진]':m.kind||'[내용 없음]'))}</div><div class="msg-meta">${esc(m.savedAt||'-')} · ID ${esc(m.messageId||'-')} · 타입 ${esc(m.messageType??m.kind??'-')} · ${esc(m.source||'-')}</div>${m.attachment?attachmentMedia(m.attachment):''}</div>`).join('')||'<div class="muted">기록 없음</div>'}</div></details>`).join('')||'<div class="muted">저장된 메시지가 없습니다.</div>'}`}
else if(_botDetailTab==='hidden'){const rows=eventRows(a,['DELETE','HIDE']);body=`<div class="detail-note">카카오/LOCO 이벤트로 실제 수신된 삭제·숨김 기록만 표시합니다. 원문은 MACRO가 이전에 저장한 경우에만 메시지 기록에서 확인할 수 있습니다.</div>${eventCards(rows,'삭제·숨김 이벤트가 없습니다.')}`}
else if(_botDetailTab==='reactions'){body=eventCards(eventRows(a,['REACTION']),'리액션 이벤트가 없습니다.')}
else if(_botDetailTab==='rooms'){body=`<div class="grid">${(d.rooms||[]).map(r=>{const ar=(a.rooms||[]).find(x=>String(x.roomId)===String(r.roomId))||{};return`<div class="tile"><b>${esc(r.roomName||r.roomId)}</b><div class="detail-lines">Room ID: <code>${esc(r.roomId||'-')}</code><br>최근 확인: ${esc(r.lastSeenAt||r.syncedAt||'-')}<br>수신 ${ar.received||0} · 발송 ${ar.sent||0} · 전체 ${ar.total||0}</div></div>`}).join('')||'<div class="muted">저장된 채팅방이 없습니다.</div>'}</div>`}
else if(_botDetailTab==='members'){const rows=eventRows(a,['JOIN','LEAVE','MEMBER']);body=`<div class="detail-note">사용자 ID·닉네임·멤버 타입 등은 해당 봇이 실제로 받은 이벤트에 포함된 정보만 표시합니다.</div>${eventCards(rows,'현재 저장된 사용자/멤버 이벤트가 없습니다.')}`}
else if(_botDetailTab==='events'){const rows=(a.rooms||[]).flatMap(r=>(r.events||[]).filter(e=>!['DELETE','HIDE','REACTION','JOIN','LEAVE','MEMBER'].includes(String(e.event||'').toUpperCase())).map(e=>({...e,roomName:r.roomName,roomId:r.roomId}))).sort((x,y)=>String(y.savedAt||'').localeCompare(String(x.savedAt||'')));body=eventCards(rows,'기타 이벤트가 없습니다.')}
else if(_botDetailTab==='media'){const rows=(a.rooms||[]).flatMap(r=>(r.latest||[]).filter(m=>m.attachment||m.kind==='photo').map(m=>({...m,roomName:r.roomName})));body=rows.map(m=>`<div class="tile media-record"><b>${esc(m.roomName||m.roomId)}</b> · ${msgDirection(m)}<div class="muted">${esc(m.savedAt||'-')} · ${esc(m.senderName||m.senderId||'')}</div>${attachmentMedia(m.attachment||{kind:m.kind,file:m.file?'저장됨':undefined})}</div>`).join('')||'<div class="muted">최근 첨부/미디어 기록이 없습니다.</div>'}
else if(_botDetailTab==='macros'){const runs=(a.logs?.macro||[]).slice(0,100);body=`<div class="detail-list">${(d.macros||[]).map(m=>`<div class="tile"><b>${esc(m.name)}</b> ${m.enabled?'<span class="runbadge">실행 중</span>':'<span class="muted">중지됨</span>'}<div class="detail-lines">종류 ${m.kind==='keyword'?'키워드':'자동 발송'} · 방 ${esc(m.roomName||m.roomId||'-')} · ID ${esc(m.id||'-')}<br>${m.keyword?'키워드 '+esc(m.keyword)+'<br>':''}${m.text?'텍스트 '+esc(m.text):''}${m.photoPath?'<br>사진 등록됨':''}</div></div>`).join('')||'<div class="muted">등록된 매크로가 없습니다.</div>'}</div><h3>최근 실행 기록</h3>${runs.map(x=>`<div class="row macro-run-row"><div><b>${esc(x.name||x.macroId||'매크로')}</b><div class="muted">${esc(x.at||'-')} · ${esc(x.roomName||x.roomId||'')}</div></div><span class="${x.status==='SUCCESS'?'license-good':x.status==='ERROR'?'bad':'muted'}">${esc(x.status||'-')}</span></div>`).join('')||'<div class="muted">실행 기록이 없습니다.</div>'}`}
else if(_botDetailTab==='account'){body=`<div class="grid"><div class="tile"><b>표시 이름</b><div>${esc(acc.displayName||'-')}</div></div><div class="tile"><b>카카오 User ID</b><div><code>${esc(acc.userId||l.userId||'-')}</code></div></div><div class="tile"><b>상태</b><div>${acc.online?'● 온라인':'○ 오프라인'}</div></div><div class="tile"><b>내부 계정 키</b><div><code>${esc(acc.key||'-')}</code></div></div><div class="tile"><b>연결 시작</b><div>${esc(acc.connectedAt||'-')}</div></div><div class="tile"><b>재시작 횟수</b><div>${esc(acc.restartCount||0)}</div></div></div><div class="tile detail-lines"><b>LOCO/KakaoForge 기능 감지</b><br>메시지 수신 ${caps.onMessage?'지원':'미감지'} · 삭제 ${caps.onDelete?'지원':'미감지'} · 숨김 ${caps.onHide?'지원':'미감지'} · 리액션 ${caps.onReaction?'지원':'미감지'}<br>텍스트 발송 ${caps.sendText?'지원':'미감지'} · 사진 발송 ${caps.sendPhoto?'지원':'미감지'}</div><div class="detail-note">인증 토큰, 세션 키, 비밀번호 등 비밀 인증정보는 표시하지 않습니다.</div>`}
else if(_botDetailTab==='connection'){const logs=a.logs||{},rows=Object.entries(logs).flatMap(([kind,list])=>(list||[]).map(x=>({kind,...x}))).sort((x,y)=>String(y.at||y.savedAt||'').localeCompare(String(x.at||x.savedAt||''))).slice(0,300);body=`<div class="grid"><div class="tile"><b>현재 연결</b><div>${acc.online?'온라인':'오프라인'}</div></div><div class="tile"><b>최근 READY</b><div>${esc(acc.lastReadyAt||acc.connectedAt||'-')}</div></div><div class="tile"><b>최근 재시작</b><div>${esc(acc.lastRestartAt||'-')}</div></div><div class="tile"><b>최근 종료</b><div>${esc(acc.lastStoppedAt||'-')}</div></div></div><h3>오류 해결 / 연결 로그</h3>${rows.map(x=>`<div class="tile"><b>${esc(x.kind)}</b> · ${esc(x.state||x.status||x.message||'')}<div class="muted">${esc(x.at||x.savedAt||'-')}</div><pre>${fmtObj(x)}</pre></div>`).join('')||'<div class="muted">로그가 없습니다.</div>'}`}
else{body=`<div class="tile"><b>진단 정보</b><div class="muted">비밀 인증정보를 제외하고 현재 클라이언트에서 안전하게 읽을 수 있는 기본 필드와 기능 지원 여부입니다.</div><pre>${fmtObj(l)}</pre></div>`}
$('modalBody').innerHTML=`<div class="detail-title-row"><h2>${esc(acc.displayName)} 상세 정보</h2>${role==='admin'?`<button class="danger" onclick="resetBotDetail('${esc(acc.key)}')">초기화</button>`:''}</div><div class="detail-tabs">${tabs.map(([id,n])=>`<button class="${_botDetailTab===id?'active':''}" onclick="_botDetailTab='${id}';renderBotDetail()">${n}</button>`).join('')}</div>${body}`}
async function botDetail(key){_botDetailData=await api('/api/admin/detail/bot/'+key);_botDetailTab='messages';showModal('');renderBotDetail();startDetailLive(key)}
async function resetBotDetail(key){if(!confirm('이 봇의 저장된 메시지, 이벤트, 연결/오류 기록과 저장된 방 이름을 모두 초기화할까요?\n인증, 매크로, 라이선스와 계정 설정은 유지됩니다.'))return;try{await api('/api/admin/detail/bot/'+encodeURIComponent(key)+'/reset',{method:'POST'});_botDetailData=await api('/api/admin/detail/bot/'+encodeURIComponent(key));renderBotDetail()}catch(e){alert(e.message)}}
async function userDetail(id){const d=await api('/api/admin/detail/user/'+id),u=d.user;showModal(`<h2>${esc(u.username)} 회원 정보</h2><div class="tile"><div>라이선스: ${licHtml(u.license)}</div><div class="muted">가입: ${esc(u.createdAt||'-')}</div><div class="muted">최근 로그인: ${esc(u.lastLoginAt||'-')}</div></div><h3>할당된 봇</h3>${d.accounts.map(a=>`<div class="row"><b>${esc(a.displayName)}</b><span>${a.online?'● 온라인':'○ 오프라인'}</span></div>`).join('')||'없음'}`)}
async function settingsPage(){me=await api('/api/me');const l=me.license||{};$('content').innerHTML=`${role==='user'?`<div class="tile form"><h3>라이선스</h3>${l.active?`<div>${licHtml(l)}</div><div>종류: ${l.type==='lifetime'?'Lifetime':'30일'}</div><div class="muted">${esc(l.key||'')}</div>`:`<div class="muted">라이선스를 등록해야 매크로를 실행할 수 있습니다.</div><label>라이선스 키<input id="licenseKey" placeholder="KEY-XXX-XXX"></label><button class="accent" onclick="activateLicense()">등록</button>`}</div>`:''}<div class="tile form"><h3>앱 설정</h3><label>테마<select onchange="setTheme(this.value)"><option value="dark">다크</option><option value="light">라이트</option><option value="system">시스템</option></select></label></div><div class="tile form"><h3>계정</h3><div class="muted">현재 로그인: ${esc(me.username||me.displayName||'')}</div><button class="danger" onclick="logout()">로그아웃</button></div>`}async function activateLicense(){try{await api('/api/license/activate',{method:'POST',body:JSON.stringify({key:$('licenseKey').value})});settingsPage()}catch(e){alert(e.message)}}
function helpPage(){stopDashboardMacroTimer();$('content').innerHTML=`<div class="tile help"><h2>MACRO 도움말</h2><h3>1. 시작</h3><p>회원가입 후 로그인하고 설정에서 관리자가 발급한 라이선스를 등록하세요.</p><h3>2. 매크로</h3><p>할당된 봇 → 채팅방 → 텍스트를 선택하고 필요하면 사진을 추가합니다. 저장 후 <b>실행</b>을 누르면 활성화됩니다.</p><h3>3. 키워드 매크로</h3><p>지정한 채팅방에서 입력한 키워드가 포함된 메시지가 들어오면 설정한 텍스트/사진을 전송합니다.</p><h3>4. 사진</h3><p>＋ 사진 추가하기를 눌러 PC에서는 파일 선택기, 모바일에서는 갤러리/파일 선택기를 사용합니다.</p><h3>5. 채팅방 목록</h3><p>채팅방 목록은 봇이 해당 방에서 <b>메시지를 수신하거나 발신하면 자동으로 기록되어 표시</b>됩니다. 지원되는 경우 채팅방 새로고침으로 서버/캐시의 방 목록도 동기화합니다.</p><h3>6. 문제 해결</h3><p>채팅방이 보이지 않으면 해당 방에서 메시지를 한 번 수신 또는 발신한 뒤 다시 확인하거나 채팅방 새로고침을 누르세요. 봇이 오프라인이면 관리자에게 문의하세요.</p><p class="warning">본 카카오톡 메세지 전송 도움 서비스 프로그램 사용으로 발생하는 모든 문제는 책임지지 않습니다, 잘 확인 후 사용해주세요.</p></div>`}
function setTheme(v){localStorage.theme=v;applyTheme()}function applyTheme(){const v=localStorage.theme||'dark';document.body.classList.toggle('light',v==='light'||(v==='system'&&matchMedia('(prefers-color-scheme:light)').matches))}applyTheme();if(token)openApp().catch(()=>logout());

async function userRestartBot(k){if(!confirm('자신에게 할당된 봇을 재시작할까요?'))return;try{await api(`/api/bot/${encodeURIComponent(k)}/restart`,{method:'POST'});setTimeout(()=>page('dashboard'),900)}catch(e){alert(e.message)}}

async function restartAllBots(){if(role!=='admin')return;if(!confirm('모든 봇을 일괄 재시작할까요?'))return;try{const x=await api('/api/admin/bots/restart-all',{method:'POST'});alert(`${x.count||0}개 봇 재시작을 시작했습니다.`);setTimeout(()=>page('dashboard'),1200)}catch(e){alert(e.message)}}
async function botControl(k,action){if(!confirm(`이 봇을 ${action==='start'?'시작':action==='stop'?'종료':'재시작'}할까요?`))return;try{await api(`/api/admin/bot/${encodeURIComponent(k)}/${action}`,{method:'POST'});setTimeout(()=>page('dashboard'),700)}catch(e){alert(e.message)}}

async function deleteBot(k,n){if(!confirm(`${n} 봇을 삭제할까요?\n인증/로컬 기록도 삭제됩니다.`))return;try{await api('/api/admin/account',{method:'DELETE',body:JSON.stringify({key:k})});adminPage()}catch(e){alert(e.message)}}
async function deleteUser(id,n){if(!confirm(`${n} 회원을 삭제할까요?`))return;try{await api('/api/admin/users/'+id,{method:'DELETE'});adminPage()}catch(e){alert(e.message)}}
async function revokeLicense(key){if(!confirm(`${key} 라이선스를 폐기할까요?`))return;try{await api('/api/admin/licenses/'+encodeURIComponent(key)+'/revoke',{method:'POST'});adminPage()}catch(e){alert(e.message)}}


let noticeTimer=null,noticeCurrentId=null;const noticeShownThisSession=new Set();
function noticeSeenKey(){return 'macro_notice_seen_'+(me?.username||me?.name||role||'guest')}
function getSeenNotices(){try{return new Set(JSON.parse(localStorage.getItem(noticeSeenKey())||'[]'))}catch{return new Set()}}
function markNoticeSeen(id){const s=getSeenNotices();s.add(String(id));localStorage.setItem(noticeSeenKey(),JSON.stringify([...s].slice(-300)))}
function startNoticeWatcher(){if(noticeTimer)clearInterval(noticeTimer);checkNewNotices().catch(()=>{});noticeTimer=setInterval(()=>checkNewNotices().catch(()=>{}),15000)}
async function checkNewNotices(){if(!token)return;const list=await api('/api/notices'),seen=getSeenNotices();const fresh=list.find(n=>!seen.has(String(n.id))&&!noticeShownThisSession.has(String(n.id)));if(fresh)showNoticeToast(fresh)}
function showNoticeToast(n){if(noticeCurrentId===String(n.id))return;noticeCurrentId=String(n.id);noticeShownThisSession.add(String(n.id));markNoticeSeen(n.id);const host=$('noticeToastHost');if(!host)return;host.innerHTML=`<div class="notice-toast" id="noticeToast"><button class="notice-toast-close" onclick="closeNoticeToast(event)">✕</button><div class="notice-toast-body" onclick="openNoticeFromToast('${esc(n.id)}')"><div class="notice-toast-label">새 공지사항</div><b>${esc(n.title)}</b><div class="notice-toast-text">${esc(n.content)}</div></div><div class="notice-toast-progress"><div class="notice-toast-progress-bar"></div></div></div>`;setTimeout(()=>{const el=$('noticeToast');if(el){el.classList.add('closing');setTimeout(()=>{if(el.parentNode)el.remove();noticeCurrentId=null},220)}},10000)}
function closeNoticeToast(e){e?.stopPropagation();const el=$('noticeToast');if(el)el.remove();noticeCurrentId=null}
async function openNoticeFromToast(id){markNoticeSeen(id);closeNoticeToast();await page('notices');setTimeout(()=>document.getElementById('notice-'+CSS.escape(String(id)))?.scrollIntoView({behavior:'smooth',block:'center'}),50)}
async function noticesPage(){const list=await api('/api/notices');for(const n of list)markNoticeSeen(n.id);$('content').innerHTML=`${role==='admin'?`<div class="tile form notice-editor"><h3>공지사항 올리기</h3><label>제목<input id="noticeTitle" maxlength="120" placeholder="공지 제목"></label><label>내용<textarea id="noticeContent" rows="6" maxlength="10000" placeholder="공지 내용을 입력하세요"></textarea></label><button class="accent" onclick="postNotice()">공지 등록</button></div>`:''}<div class="notice-list"><h3>공지사항</h3>${list.map(n=>`<article class="tile notice-item" id="notice-${esc(n.id)}"><div class="notice-head"><div><b>${esc(n.title)}</b><div class="muted">${esc(new Date(n.createdAt).toLocaleString('ko-KR'))}</div></div>${role==='admin'?`<button class="danger" onclick="deleteNotice('${esc(n.id)}')">삭제</button>`:''}</div><div class="notice-content">${esc(n.content)}</div></article>`).join('')||'<div class="tile muted">등록된 공지사항이 없습니다.</div>'}</div>`}
async function postNotice(){try{await api('/api/notices',{method:'POST',body:JSON.stringify({title:$('noticeTitle').value,content:$('noticeContent').value})});await noticesPage()}catch(e){alert(e.message)}}
async function deleteNotice(id){if(!confirm('이 공지사항을 삭제할까요?'))return;try{await api('/api/notices/'+encodeURIComponent(id),{method:'DELETE'});await noticesPage()}catch(e){alert(e.message)}}

async function voiceSettingsPage(){
 if(role!=='admin')return;
 const content=$('content');
 content.innerHTML='<div class="tile form"><p>보룸봇 설정 불러오는 중</p></div>';
 try{
  const {accounts}=await api('/api/status',{noCache:true});
  if($('title').textContent!=='보룸봇 설정')return;
  content.innerHTML='<div class="tile form"><label>봇 계정<select id="voiceAccount" onchange="loadVoiceSettings()">'+accounts.map(a=>'<option value="'+esc(a.key)+'">'+esc(a.displayName||a.key)+'</option>').join('')+'</select></label><div id="voiceForm" aria-live="polite"></div></div>';
  if(accounts.length)await loadVoiceSettings();else $('voiceForm').textContent='연결된 봇 계정이 없습니다.';
 }catch(e){if($('title').textContent==='보룸봇 설정')content.textContent=e.message;}
}
async function loadVoiceSettings(){
 const account=$('voiceAccount').value,form=$('voiceForm');
 const current=()=>$('voiceForm')===form&&$('voiceAccount')?.value===account;
 const settingsUrl='/api/voice-settings?account='+encodeURIComponent(account);
 form.textContent='설정 불러오는 중';
 try{
  const [result,knownRooms]=await Promise.all([
   api(settingsUrl,{noCache:true}),api('/api/rooms?account='+encodeURIComponent(account),{noCache:true})
  ]);
  if(!current())return;
  if(result.schemaVersion!==2){form.textContent='Host PC의 MACRO를 최신 통합판으로 업데이트하세요.';return;}
  const selected=new Map(result.rooms.map(room=>[room.roomId,room.operatorIds.join(', ')]));
  const choices=new Map(knownRooms.map(room=>[String(room.roomId),room.roomName]));
  for(const id of selected.keys())if(!choices.has(id))choices.set(id,id);
  form.innerHTML=`<p id="voiceConnection"></p><button type="button" id="voiceReloadAuth" class="hidden">저장된 인증 다시 확인</button>
  <label>총괄 운영자 ID<input id="voiceGlobal" placeholder="사용자 ID, 사용자 ID"></label>
  <p class="muted">허용된 방의 방장·부방장은 ID 등록 없이 보룸 명령을 사용할 수 있습니다. 아래 운영자 ID는 일반 멤버에게 추가 권한을 줄 때만 입력하세요. 총괄 운영자는 선택한 모든 방에 적용됩니다.</p>
  <details><summary id="voiceSelectedCount">허용 방 선택</summary><div id="voiceChoices"></div></details>
  <div id="voiceRoomOperators"></div>
  <p class="muted">새로 허용한 방에서는 !보룸자동 제목 또는 !보룸 1시간 제목을 보내세요. 허용 해제는 새 명령·자동 재개설을 중단하며, 이미 열린 보룸은 예정된 종료 시각까지 유지됩니다.</p>
  <button class="primary" id="saveVoiceRooms">저장</button> <button type="button" onclick="loadVoiceSettings()">새로고침</button><p id="voiceResult" aria-live="polite"></p>`;
  $('voiceGlobal').value=(result.globalOperatorIds||[]).join(', ');
  const renderStatus=status=>{
   $('voiceConnection').textContent=status.online?'카카오톡 연결됨':status.authRefreshing?'카카오톡 인증 갱신 중':status.authRequired?'카카오톡 인증이 필요합니다. Host PC에서 npm run auth를 실행하세요.':'카카오톡 연결 대기 중';
   $('voiceReloadAuth').classList.toggle('hidden',!status.authRequired||status.online||status.authRefreshing);
  };
  const renderOperators=()=>{
   $('voiceSelectedCount').textContent='허용 방 선택 ('+selected.size+'개)';
   $('voiceRoomOperators').innerHTML=[...selected].map(([id,ids])=>`<label>${esc(choices.get(id))} 운영자 ID<input data-voice-room="${esc(id)}" value="${esc(ids)}" placeholder="사용자 ID, 사용자 ID"></label>`).join('');
   for(const input of $('voiceRoomOperators').querySelectorAll('input'))input.oninput=()=>selected.set(input.dataset.voiceRoom,input.value);
  };
  $('voiceChoices').innerHTML=[...choices].map(([id,name])=>`<label><input type="checkbox" value="${esc(id)}" ${selected.has(id)?'checked':''}> ${esc(name)}</label>`).join('')||'<p>매크로에서 확인된 채팅방이 없습니다.</p>';
  for(const checkbox of $('voiceChoices').querySelectorAll('input'))checkbox.onchange=()=>{
   if(checkbox.checked)selected.set(checkbox.value,'');else selected.delete(checkbox.value);
   renderOperators();
  };
  renderOperators();
  renderStatus(result);
  if(result.lastResult)$('voiceResult').textContent='최근 처리 결과 '+result.lastResult.status;
  const statusNode=$('voiceConnection');
  const poll=async()=>{
   if(!current()||$('voiceConnection')!==statusNode)return;
   try{const status=await api(settingsUrl,{noCache:true});if(current()&&$('voiceConnection')===statusNode)renderStatus(status);}catch{}
   if(current()&&$('voiceConnection')===statusNode)setTimeout(poll,4000);
  };
  setTimeout(poll,4000);
  $('voiceReloadAuth').onclick=async()=>{
   try{await api(settingsUrl,{method:'POST'});if(current())$('voiceResult').textContent='저장된 인증으로 다시 연결하는 중입니다.';}
   catch(e){if(current())$('voiceResult').textContent=e.message;}
  };
  const ids=value=>value.trim()?value.trim().split(/\s*,\s*/):[];
  $('saveVoiceRooms').onclick=async()=>{
   const button=$('saveVoiceRooms');button.disabled=true;
   try{
    const rooms=[...selected].map(([roomId,value])=>({roomId,operatorIds:ids(value)}));
    const saved=await api(settingsUrl,{method:'PUT',body:JSON.stringify({rooms,globalOperatorIds:ids($('voiceGlobal').value)})});
    if(current())$('voiceResult').textContent=saved.appliedRoomIds?'저장 및 적용했습니다. 허용 방 '+saved.appliedRoomIds.length+'개. 새로 허용한 방에서 개설 명령을 입력하세요.':'저장했습니다. Host를 최신 수정판으로 업데이트하면 적용 상태를 확인할 수 있습니다.';
   }catch(e){if(current())$('voiceResult').textContent=e.message;}
   finally{button.disabled=false;}
  };
 }catch(e){if(current())form.textContent=e.message;}
}
