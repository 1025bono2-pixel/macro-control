'use strict';

function userId(value) {
  if (typeof value === 'number' && !Number.isSafeInteger(value)) return null;
  if (value == null) return null;
  const id = String(value);
  return /^[1-9]\d*$/.test(id) ? id : null;
}

function attachments(msg) {
  const raw = msg.attachmentsRaw;
  return (Array.isArray(raw) ? raw : raw ? [raw] : []).map(value => {
    if (typeof value !== 'string') return value;
    try { return JSON.parse(value); } catch { return null; }
  }).filter(value => value && typeof value === 'object');
}

async function handleIdCommand(client, chat, msg) {
  const text = String(msg?.message?.text ?? msg?.text ?? '').trim();
  if (!/^!id(?:\s|$)/i.test(text)) return false;
  const sender = userId(msg?.sender?.id ?? msg?.senderId);
  if (sender && sender === userId(client.userId)) return true;
  const roomId = userId(msg?.room?.id ?? msg?.chatId ?? chat?.id);
  if (!roomId) return true;
  const extra = attachments(msg);
  const hasArgument = text.replace(/^!id/i, '').trim().length > 0;
  // A typed nickname is not proof of a mention. Use server-supplied metadata.
  const mentions = extra.flatMap(item => Array.isArray(item.mentions) ? item.mentions : []);
  const ids = [...new Set(mentions.map(item => userId(item.user_id ?? item.userId)).filter(Boolean))];
  let response;
  if (hasArgument) {
    response = ids.length ? ids.map(id => `사용자 ID: ${id}`).join('\n') : '사용자를 실제로 멘션하여 !id @멘션 으로 입력해 주세요.';
  } else {
    const reply = extra.find(item => Object.hasOwn(item, 'src_userId'));
    const id = reply ? userId(reply.src_userId) : sender;
    response = id ? `사용자 ID: ${id}` : '사용자 ID를 확인할 수 없습니다.';
  }
  // Reply to the command itself when the client supports Kakao reply messages.
  if (typeof client.sendReply === 'function' && sender && (msg.message?.logId ?? msg.logId)) {
    await client.sendReply(roomId, response, msg);
  } else {
    await client.sendText(roomId, response);
  }
  return true;
}

module.exports = { handleIdCommand };
