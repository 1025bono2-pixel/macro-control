const {handleIdCommand}=require('./IdCommand');
const fs=require('fs'),path=require('path');const ArchiveStore=require('./archive/ArchiveStore');const {loadKakaoForge}=require('./KakaoForgeLoader');

const {ACCOUNTS,SYSTEM}=require('./DataPaths');
const VoiceSettings=require('./vox-bot/VoiceSettings.cjs');
const {isVoiceCommand}=require('./vox-bot/VoiceRoomCommands.cjs');
const {saveSession}=require('./services/KakaoSession');

const readJson=(p,d={})=>{try{return JSON.parse(fs.readFileSync(p,'utf8'));}catch{return d;}};const writeJson=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2));};

class BotManager{

 constructor(){this.voice=new VoiceSettings(SYSTEM);this.clients=new Map();this.archives=new Map();this.states=new Map();this.authWatchers=new Map();this.recoveryTimers=new Map();this.kf=loadKakaoForge();this.engine=null;this.startedAt=new Date().toISOString();this.roomDebugSeen=new Set();this.debugDir=path.join(__dirname,'..','debug');}

 clearAuthWatcher(key){
  const watcher=this.authWatchers.get(key);
  if(watcher)fs.unwatchFile(watcher.path,watcher.listener);
  this.authWatchers.delete(key);
 }

 findAccounts(){fs.mkdirSync(ACCOUNTS,{recursive:true});return fs.readdirSync(ACCOUNTS,{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>{const base=path.join(ACCOUNTS,x.name),meta=readJson(path.join(base,'account.json'),{});return{key:x.name,displayName:meta.displayName||x.name,authPath:path.join(base,'auth.json')}}).filter(x=>fs.existsSync(x.authPath));}

 status(){return this.findAccounts().map(a=>({key:a.key,displayName:a.displayName,...(this.states.get(a.key)||{online:false})}));}

 rooms(key){const base=path.join(ACCOUNTS,key,'rooms');if(!fs.existsSync(base))return[];return fs.readdirSync(base,{withFileTypes:true}).filter(x=>x.isDirectory()&&fs.existsSync(path.join(base,x.name,'room.json'))).map(x=>readJson(path.join(base,x.name,'room.json'),null)).filter(x=>x&&x.roomId&&x.roomName).sort((a,b)=>String(a.roomName).localeCompare(String(b.roomName),'ko'));}



 // Synchronize room metadata from supported KakaoForge chat-list APIs/caches.

 // Some builds expose only event-driven rooms; never claim a complete list then.

 async syncRooms(key){

  // Room names are intentionally learned only from real message events (msg.room.name).

  // Generic KakaoForge caches can also contain VoiceRoom/system objects, so they are not

  // allowed to create or rename rooms here.

  const info={count:0,source:'message-events-only',complete:false,stored:this.rooms(key).length};

  this.states.set(key,{...(this.states.get(key)||{}),roomSync:info});

  this.archives.get(key)?.log('connection',{state:'ROOM_SYNC',...info});

  return info;

 }

 async rememberRoom(key,chat,msg,client){

  const archive=this.archives.get(key);if(!archive)return;

  const rawRoomId=msg?.room?.id??msg?.room?.roomId??msg?.room?.chatId??msg?.room?.channelId??archive.roomId(chat,msg);

  const roomId=String(rawRoomId??'');

  if(!roomId||roomId==='unknown')return;



  const eventName=typeof msg?.room?.name==='string'?msg.room.name.trim():'';

  const openLinkId=msg?.room?.openLinkId??msg?.openLinkId??null;

  let resolvedName='';

  let nameSource='';



  // OpenChat: ask KakaoForge for the OpenLink title instead of trusting msg.room.name.

  // This avoids VoiceRoom titles/stale per-account room cache values becoming the room name.

  if(msg?.room?.isOpenChat&&openLinkId!=null&&client&&typeof client._ensureOpenLinkName==='function'){

   try{

    const value=await client._ensureOpenLinkName(openLinkId);

    if(typeof value==='string')resolvedName=value.trim();

    else if(value&&typeof value==='object')resolvedName=String(value.ln??value.name??value.title??value.roomName??'').trim();

    if(resolvedName)nameSource='openLink';

   }catch(e){archive.log('errors',{source:'openLinkName',roomId,openLinkId:String(openLinkId),message:e.message});}

  }



  // Non-open chats, or old KakaoForge builds without OpenLink lookup, keep the event value as fallback.

  if(!resolvedName){resolvedName=eventName;nameSource=resolvedName?'msg.room.name':'pending';}



  const p=path.join(ACCOUNTS,key,'rooms',roomId.replace(/[^a-zA-Z0-9._-]/g,'_'),'room.json');

  const prev=readJson(p,{});

  const roomName=resolvedName||String(prev.roomName||'이름 확인 중');

  writeJson(p,{...prev,roomId,roomName,openLinkId:openLinkId==null?prev.openLinkId:String(openLinkId),lastSeenAt:new Date().toISOString(),nameSource});

  return{roomId,roomName};

 }

 clearRoomMetadata(key){

  // Clear only discovered room metadata. Message/event archives stay intact.

  // This makes stop/start/restart rebuild the selectable room list from fresh msg.room.name values.

  const root=path.join(ACCOUNTS,key,'rooms');

  if(!fs.existsSync(root))return 0;

  let removed=0;

  for(const d of fs.readdirSync(root,{withFileTypes:true})){

   if(!d.isDirectory())continue;

   const meta=path.join(root,d.name,'room.json');

   if(fs.existsSync(meta)){try{fs.rmSync(meta,{force:true});removed++;}catch{}}

  }

  return removed;

 }



 writeRoomDebug(key,displayName,chat,msg){

  // Diagnostic only: one snapshot per bot+room. Stored beside the project, not APPDATA.

  const archive=this.archives.get(key);

  const roomId=String(msg?.room?.id??msg?.room?.roomId??msg?.room?.chatId??msg?.room?.channelId??archive?.roomId(chat,msg)??'unknown');

  const seenKey=`${key}:${roomId}`;if(this.roomDebugSeen.has(seenKey))return;this.roomDebugSeen.add(seenKey);

  const secret=/token|secret|password|auth|credential|cookie|session|ticket|access[_-]?token|refresh[_-]?token/i;

  const clean=(value,depth=0,seen=new WeakSet())=>{if(depth>6)return '[MaxDepth]';if(value==null||['string','number','boolean'].includes(typeof value))return value;if(typeof value==='bigint')return value.toString();if(typeof value==='function')return `[Function ${value.name||''}]`;if(typeof value!=='object')return String(value);if(typeof value.toString==='function'&&/Long/.test(value.constructor?.name||''))return value.toString();if(seen.has(value))return '[Circular]';seen.add(value);if(Array.isArray(value))return value.slice(0,100).map(v=>clean(v,depth+1,seen));const out={};for(const [k,v] of Object.entries(value)){out[k]=secret.test(k)?'[REDACTED]':clean(v,depth+1,seen);}return out;};

  try{fs.mkdirSync(this.debugDir,{recursive:true});fs.appendFileSync(path.join(this.debugDir,'room-debug.jsonl'),JSON.stringify({at:new Date().toISOString(),botKey:key,botName:displayName||key,botUserId:String(this.states.get(key)?.userId||''),roomId,msgRoom:clean(msg?.room),chat:clean(chat),rawChatLog:clean(msg?.raw?.chatLog)})+'\n');}catch{}

 }

 clientInfo(key){

  const c=this.clients.get(key),state=this.states.get(key)||{};

  if(!c)return{available:false,state};

  const redact=/token|secret|password|auth|credential|cookie|session|ticket|key/i;

  const scalar=(obj)=>{const out={};if(!obj||typeof obj!=='object')return out;for(const [k,v] of Object.entries(obj)){if(redact.test(k))continue;if(v==null||['string','number','boolean'].includes(typeof v))out[k]=v==null?v:String(v);else if(v&&typeof v.toString==='function'&&/Long/.test(v.constructor?.name||''))out[k]=v.toString();}return out;};

  return{available:true,userId:String(c.userId??state.userId??''),state,client:scalar(c),chat:scalar(c.chat),capabilities:{disconnect:typeof c.disconnect==='function',close:typeof c.close==='function',stop:typeof c.stop==='function',sendText:typeof c.sendText==='function'||typeof c.chat?.sendText==='function',sendPhoto:typeof c.sendPhoto==='function',onMessage:typeof c.onMessage==='function',onReady:typeof c.onReady==='function',onDelete:typeof c.onDelete==='function',onHide:typeof c.onHide==='function',onReaction:typeof c.onReaction==='function',onPush:typeof c.onPush==='function'}};

 }

 attachOptionalEvents(key,client,archive){
  const roomOf=(chat,evt)=>archive.roomId(chat,evt||{});
  const bind=(name,eventName)=>{
   if(typeof client?.[name]!=='function')return false;
   try{
    client[name]((chat,evt)=>{
     try{archive.event(roomOf(chat,evt),eventName,evt||{});}
     catch(e){archive.log('errors',{source:name,message:e.message});}
    });
    return true;
   }catch(e){
    archive.log('errors',{source:name,message:e.message});
    return false;
   }
  };
  const supported={
   delete:bind('onDelete','DELETE'),
   hide:bind('onHide','HIDE'),
   reaction:bind('onReaction','REACTION'),
   join:bind('onJoin','JOIN'),
   leave:bind('onLeave','LEAVE'),
   member:bind('onMember','MEMBER')
  };
  this.states.set(key,{...(this.states.get(key)||{}),eventHooks:supported});
 }


 async addAccountByQR(key,displayName){
  const dir=path.join(ACCOUNTS,key),authPath=path.join(dir,'auth.json');
  if(fs.existsSync(authPath))throw new Error('이미 존재하는 봇 계정입니다.');
  const {qrLogin}=require('./vox-bot/QrLogin.cjs');
  const auth=await qrLogin({loadedFrom:this.kf.loadedFrom,emit:({url})=>console.log('[QR] 이 PC에서 열기 '+url)});
  fs.mkdirSync(dir,{recursive:true});
  saveSession(authPath,auth);
  writeJson(path.join(dir,'account.json'),{displayName:displayName||key,createdAt:new Date().toISOString()});
  this.startByKey(key);
 }

 rename(key,displayName){const p=path.join(ACCOUNTS,key,'account.json'),m=readJson(p,{});m.displayName=String(displayName||key);writeJson(p,m);}

 async removeAccount(key){key=String(key||'');if(!/^[a-zA-Z0-9._-]+$/.test(key))throw new Error('잘못된 계정 키입니다.');const dir=path.join(ACCOUNTS,key);if(!fs.existsSync(dir))throw new Error('계정을 찾을 수 없습니다.');await this.stop(key,{preserveVoice:false});this.archives.delete(key);this.states.delete(key);fs.rmSync(dir,{recursive:true,force:true});if(this.engine){const all=this.engine.list().filter(x=>x.accountKey!==key);require('./macro/MacroStore').save(all);this.engine.reload();}return{ok:true};}

 clearRecoveryTimer(key){

  const t=this.recoveryTimers.get(key);

  if(t){clearTimeout(t);this.recoveryTimers.delete(key);}

 }

 scheduleRecovery(key,displayName){

  this.clearRecoveryTimer(key);

  const timer=setTimeout(async()=>{

   this.recoveryTimers.delete(key);

   const st=this.states.get(key)||{};

   if(st.online||st.authRequired)return;

   const old=this.clients.get(key);

   // Stop only this client's own reconnect loop/socket. Other bots are untouched.

   if(old){
    this.clearAuthWatcher(key);

    try{old.autoReconnect=false;}catch{}

    for(const fn of ['disconnect','close','stop']){

     if(typeof old[fn]==='function'){try{await old[fn]();}catch{}break;}

    }

    if(this.clients.get(key)===old)this.clients.delete(key);

   }

   const a=this.findAccounts().find(x=>x.key===key);

   if(!a)return;

   const prev=this.states.get(key)||{};

   this.states.set(key,{...prev,online:false,recovering:true,lastRecoveryAt:new Date().toISOString(),recoveryCount:Number(prev.recoveryCount||0)+1});

   this.archives.get(key)?.log('connection',{state:'CLIENT_RECOVERY',reason:'offline_timeout'});

   console.warn(`[${key}] 연결이 오래 복구되지 않아 이 봇만 client를 새로 생성합니다.`);

   try{this.startAccount(a,{preserveRooms:true,recovery:true});}

   catch(e){this.archives.get(key)?.log('errors',{source:'recovery',message:e.message});}

  },90000);

  this.recoveryTimers.set(key,timer);

 }

 startAll(){console.log(`[MACRO] KakaoForge: ${this.kf.loadedFrom}`);for(const x of this.findAccounts())this.startAccount(x);}

 async restartAll(){const accounts=this.findAccounts();for(const a of accounts)await this.stop(a.key);for(const a of accounts)this.startAccount(a);return{ok:true,count:accounts.length};}

 startByKey(key){const a=this.findAccounts().find(x=>x.key===key);if(!a)throw new Error('계정을 찾을 수 없습니다.');this.startAccount(a);}

 startAccount({key,authPath,displayName},opts={}){

  if(this.clients.has(key))return;

  let archive=this.archives.get(key);

  if(!archive){archive=new ArchiveStore(key);this.archives.set(key,archive);}

  const prevState=this.states.get(key)||{};

  this.states.set(key,{...prevState,online:false,authRequired:false,recovering:opts.recovery===true});

  const client=this.kf.mod.createClient({authPath,debug:false,autoConnect:false,autoReconnect:true,sendIntervalMs:400});

  this.clients.set(key,client);


  this.attachOptionalEvents(key,client,archive);

  let refreshing=false;
  let reloadingAuth=false;
  const reloadSavedAuth=async()=>{
   if(refreshing||reloadingAuth||this.clients.get(key)!==client||!this.states.get(key)?.authRequired)return;
   const saved=readJson(authPath);
   if(!saved.accessToken||saved.accessToken===client.oauthToken||String(saved.userId)!==String(client.userId))return;
   reloadingAuth=true;
   try{await this.restart(key,{preserveVoice:true});}catch{archive.log('connection',{state:'AUTH_RELOAD_FAILED'});}
   finally{reloadingAuth=false;}
  };
  const listener=()=>void reloadSavedAuth();
  this.clearAuthWatcher(key);
  this.authWatchers.set(key,{path:authPath,listener});
  fs.watchFile(authPath,{persistent:false,interval:2000},listener);
  const authFailure=()=>{
   if(refreshing||this.clients.get(key)!==client)return;
   refreshing=true;
   this.clearRecoveryTimer(key);
   void this.voice.updateClient(key,client,false);
   this.states.set(key,{...(this.states.get(key)||{}),online:false,reconnecting:false,recovering:false,authRequired:true,authRefreshing:true});
   setImmediate(async()=>{
    try{
     if(this.clients.get(key)!==client||!client.refreshToken)return;
     const oldToken=client.oauthToken;
     await client.refreshAuth();
     if(this.clients.get(key)!==client)return;
     const savedToken=readJson(authPath).accessToken;
     if(savedToken&&savedToken!==oldToken&&savedToken!==client.oauthToken)return;
     saveSession(authPath,{userId:String(client.userId),accessToken:client.oauthToken,refreshToken:client.refreshToken,deviceUuid:client.deviceUuid});
     await client.connect();
    }catch{archive.log('connection',{state:'AUTH_REQUIRED'});}
    finally{
     refreshing=false;
     if(this.clients.get(key)===client)this.states.set(key,{...(this.states.get(key)||{}),authRefreshing:false});
     void reloadSavedAuth();
    }
   });
  };
  client.on('authRejected',authFailure);
  client.on('error',error=>{
   if(error?.code==='LOCO_AUTH_REJECTED')return;
   if(this.clients.get(key)!==client)return;
   archive.log('connection',{state:'CONNECTION_ERROR'});
   this.scheduleRecovery(key,displayName);
  });



  // KakaoForge already has its own reconnect lock/backoff. We only observe it here.

  if(typeof client.on==='function'){

   client.on('disconnected',()=>{

    // Ignore a stale client's late event after it has been replaced.

    if(this.clients.get(key)!==client)return;
    void this.voice.updateClient(key,client,false);

    const prev=this.states.get(key)||{};

    this.states.set(key,{...prev,online:false,reconnecting:true,lastDisconnectedAt:new Date().toISOString()});

    archive.log('connection',{state:'DISCONNECTED'});

    this.scheduleRecovery(key,displayName);

   });

   client.on('connected',()=>{

    if(this.clients.get(key)!==client)return;

    const prev=this.states.get(key)||{};

    this.states.set(key,{...prev,reconnecting:true,lastTransportConnectedAt:new Date().toISOString()});

   });

  }



  client.onReady(()=>{

   if(this.clients.get(key)!==client)return;

   this.clearRecoveryTimer(key);
   void this.voice.updateClient(key,client,true).catch(()=>archive.log('voice',{event:'voice_client_update_failed'}));

   const prev=this.states.get(key)||{};

   const st={...prev,online:true,reconnecting:false,recovering:false,authRequired:false,userId:String(client.userId),connectedAt:prev.connectedAt||new Date().toISOString(),lastReadyAt:new Date().toISOString(),restartCount:Number(prev.restartCount||0)};

   this.states.set(key,st);

   archive.log('connection',{state:'READY',...st});

   console.log(`[${key}] ONLINE / ${st.userId} / ${displayName||key}`);

   this.syncRooms(key).catch(e=>console.warn(`[${key}] 방 동기화 실패: ${e.message}`));

  });



  client.onMessage(async(chat,msg)=>{

   try{

    if(this.clients.get(key)!==client)return;
    if(await handleIdCommand(client,chat,msg))return;
    this.writeRoomDebug(key,displayName,chat,msg);

    const r=await this.rememberRoom(key,chat,msg,client);

    archive.incoming(chat,msg,String((this.states.get(key)||{}).userId||client.userId||''));

    const text=msg?.message?.text??msg?.text??'';

    const senderId=String(msg?.sender?.id??msg?.senderId??'');


    if(this.clients.get(key)===client&&isVoiceCommand(text)){
     void this.voice.incoming(key,client,msg,archive).catch(()=>archive.log('voice',{event:'voice_room_command_error'}));
    }
    if(r&&this.engine)await this.engine.onIncoming(key,r.roomId,text,senderId);

   }catch(e){archive.log('errors',{message:e.message});}

  });
  void client.connect().catch(error=>client.emit('error',error));
 }

 async stop(key,{preserveVoice=true}={}){
  this.clearRecoveryTimer(key);
  this.clearAuthWatcher(key);
  const client=this.clients.get(key);
  this.clients.delete(key);
  this.states.set(key,{...(this.states.get(key)||{}),online:false,reconnecting:false,recovering:false,
   authRefreshing:false,lastStoppedAt:new Date().toISOString()});
  if(!preserveVoice)await this.voice.stop(key);
  else if(client)await this.voice.updateClient(key,client,false);
  if(!client)return;
  const method=['disconnect','close','stop'].find(name=>typeof client[name]==='function');
  if(method){
   try{await client[method]();}
   catch{this.archives.get(key)?.log('errors',{source:'stop',method});}
  }
  if(!this.clients.has(key))this.states.set(key,{...this.states.get(key),lastStopMethod:method||'none'});
  this.archives.get(key)?.log('connection',{state:'STOPPED',method:method||'none'});
 }

 async restart(key,options){const prev=this.states.get(key)||{};await this.stop(key,options);this.states.set(key,{...(this.states.get(key)||{}),restartCount:Number(prev.restartCount||0)+1,lastRestartAt:new Date().toISOString()});this.startByKey(key);}

 logMacroError(item,e){

  if(e?.code==='BOT_RECONNECTING'){

   this.archives.get(item.accountKey)?.log('macro',{macroId:item.id,name:item.name,status:'SKIPPED_RECONNECTING'});

   return;

  }

  console.error(`[MACRO:${item.name}]`,e.message);

  this.archives.get(item.accountKey)?.log('macro',{macroId:item.id,name:item.name,status:'ERROR',error:e.message});

 }

}

module.exports=BotManager;
