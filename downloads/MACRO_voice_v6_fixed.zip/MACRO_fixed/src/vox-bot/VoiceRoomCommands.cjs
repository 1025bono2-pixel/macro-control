'use strict';

const HOUR = 3600000;
const MAX_DURATION = 48 * HOUR;
const isVoiceCommand = text => typeof text === 'string' && /^!보룸(?:자동)?(?:\s|$)/.test(text.trim());

function parseCommand(text) {
  if (!isVoiceCommand(text)) return null;
  const value = text.trim();
  if (/^!보룸\s+종료$/.test(value)) return { action: 'end' };
  const automatic = /^!보룸자동\s+(.+)$/u.exec(value);
  if (automatic) return { action: 'auto', title: automatic[1], durationMs: MAX_DURATION };
  const timed = /^!보룸\s+(\d+(?:\.\d+)?)(시간|분|h|m)?\s+(.+)$/iu.exec(value);
  if (timed) {
    const durationMs = Number(timed[1]) * (/^(분|m)$/i.test(timed[2] || '') ? 60000 : HOUR);
    if (durationMs >= 1 && durationMs <= MAX_DURATION) return { action: 'create', title: timed[3], durationMs: Math.ceil(durationMs) };
  }
  return { action: 'invalid' };
}

function id(value) {
  if (typeof value === 'number' && !Number.isSafeInteger(value)) return null;
  if (!['number', 'bigint', 'string'].includes(typeof value)) return null;
  const text = String(value);
  return /^[1-9][0-9]{0,18}$/.test(text) && BigInt(text) <= 9223372036854775807n
    ? text : null;
}

function createVoiceRoomCommands({ rooms, log = () => {} }) {
  let rules = new Map();
  function updateRooms(rooms) {
    const next = new Map();
    for (const { roomId, operatorIds } of rooms) {
      const room = id(roomId);
      const operators = operatorIds.map(id);
      if (!room || next.has(room) || !operators.length || operators.includes(null)) {
        throw new TypeError('Invalid voice room command policy');
      }
      next.set(room, { operators: new Set(operators), seen: rules.get(room)?.seen || new Set() });
    }
    rules = next;
  }
  updateRooms(rooms);

  // Consumes the MessageEvent passed to KakaoForge's onMessage callback.
  function onVoiceRoomMessage(event) {
    const message = event?.message;
    if (message?.type !== 1 || typeof message.text !== 'string') return undefined;
    const command = parseCommand(message.text);
    if (!command) return undefined;

    const roomId = id(event.room?.id);
    const senderId = id(event.sender?.id);
    const messageId = id(message.logId);
    const rule = rules.get(roomId);
    let status = 'forbidden';
    if (event.room?.isOpenChat === true && rule?.operators.has(senderId) && messageId) {
      if (rule.seen.has(messageId)) {
        status = 'duplicate';
      } else {
        rule.seen.add(messageId);
        if (rule.seen.size > 256) rule.seen.delete(rule.seen.values().next().value);
        status = command.action === 'invalid' ? 'invalid_command' : 'authorized';
      }
    }

    const result = { ...command, status };
    log({ event: 'voice_room_command', action: command.action, status });
    return result;
  }
  onVoiceRoomMessage.updateRooms = updateRooms;
  return onVoiceRoomMessage;
}

module.exports = { createVoiceRoomCommands, isVoiceCommand, MAX_DURATION };
