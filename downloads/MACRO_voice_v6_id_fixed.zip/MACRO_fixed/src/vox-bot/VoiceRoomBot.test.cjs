'use strict';
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { test } = require('node:test');
const { setImmediate: tick } = require('node:timers/promises');
const { createVoiceRoomBot } = require('./VoiceRoomBot.cjs');
const { VoxSession, long } = require('./VoxSession.js');

const rooms = [{ roomId: '101', operatorIds: ['31'] }, { roomId: '102', operatorIds: ['31'] }];
const client = {
  userId: '31', oauthToken: 'test-only', deviceUuid: 'test-only',
  _ensureMemberType: async () => {}, _getCachedMemberType: () => 1,
};
const message = (room, id, action = '1 테스트 방', sender = '31') => ({
  room: { id: room, isOpenChat: true }, sender: { id: sender },
  message: { type: 1, logId: id, text: action.startsWith('!') ? action : `!보룸 ${action}` },
});

function fixture({ failCreate = false, failEnd = false, heartbeatTimeouts = 0, failMedia = false, endByPush = false, callableAfterCreate = 1 } = {}) {
  const requests = [];
  const replies = [];
  const peers = [];
  const sessions = [];
  const timers = new Map();
  let timerId = 0;
  let time = 0;
  const createSession = context => { const session = new VoxSession(context, {
    connectionFactory: () => new class extends EventEmitter {
      async connect() {}
      close() {}
      rejectPending(error) { this.rejectEnd?.(error); }
      send(sequence, command, body) { replies.push({ sequence, command, call: String(body.callId) }); }
      async request(command, body) {
        requests.push({ command, room: String(body.chatId ?? ''), call: String(body.callId ?? ''), title: body.title });
        const response = { resCode: 0, userId: long(context.userId) };
        if (command === 30000) return { body: { ...response, callable: requests.some(x => x.command === 11028) ? callableAfterCreate : 1, csSslAddr: { ip: 2130706433 } } };
        if (command === 11028) {
          if (failCreate) throw new Error('timeout');
          const callId = long(String(body.chatId) + '00');
          const sdp = { sdpType: 2, sdp: 'test-answer' };
          this.emit('push', { sequence: 1, command: 11003, body: { ...response, callId: long('999'), sdp } });
          this.emit('push', { sequence: 2, command: 11003, body: { ...response, callId, sdp } });
          return { body: { ...response, callId, csId: long('1'), interval: 5 } };
        }
        if (command === 11008 && failEnd) throw new Error('timeout');
        if (command === 11008 && endByPush) {
          return new Promise((resolve, reject) => {
            this.rejectEnd = reject;
            this.emit('push', { sequence: 3, command: 11007, body: { ...response, callId: body.callId } });
          });
        }
        if (command === 11015 && heartbeatTimeouts-- > 0) throw Object.assign(new Error('timeout'), { code: 'VOX_REQUEST_TIMEOUT' });
        return { body: { ...response, callId: body.callId } };
      }
    }(),
    peerFactory: () => {
      const peer = {
        addTransceiver: () => ({ sender: {} }), createOffer: async () => ({ sdp: 'test-offer' }),
        async setLocalDescription(description) { this.localDescription = description; },
        async setRemoteDescription(description) {
          if (failMedia) throw new Error('unsupported SDP');
          this.remoteDescription = description;
        },
        async close() { this.closed = true; },
      };
      peers.push(peer);
      return peer;
    },
  });
  sessions.push(session); return session; };
  const handle = createVoiceRoomBot({ client, rooms, createSession,
    setTimer: (callback, delay) => timers.set(++timerId, { callback, delay }) && timerId,
    clearTimer: id => timers.delete(id), now: () => time,
  });
  async function runTimer(delay) {
    const match = [...timers].find(([, timer]) => timer.delay === delay);
    assert.ok(match, 'expected timer with delay '+delay);
    timers.delete(match[0]);
    time += delay;
    match[1].callback();
    await tick();
  }
  return { requests, replies, peers, sessions, handle, timers, runTimer, setFailEnd: value => { failEnd = value; }, setCallable: value => { callableAfterCreate = value; } };
}

test('concurrent rooms have separate calls and only acknowledge SDP from the matching call', async () => {
  const { handle, requests, replies, peers } = fixture();
  const first = handle(message('101', '1'));
  assert.equal((await handle(message('101', '1'))).status, 'duplicate');
  assert.equal((await handle(message('101', '2'))).status, 'busy');
  const results = await Promise.all([first, handle(message('102', '1'))]);
  assert.deepEqual(results.map(x => x.status), ['create_acknowledged', 'create_acknowledged']);
  assert.deepEqual(replies.map(x => x.call).sort(), ['10100', '10200']);
  assert.ok(peers.every(x => x.remoteDescription.sdp === 'test-answer'));
  assert.equal((await handle(message('101', '3', '종료', '32'))).status, 'forbidden');
  assert.equal((await handle(message('101', '4', '종료'))).status, 'end_acknowledged');
  assert.equal(peers[1].closed, undefined);
  assert.equal((await handle(message('102', '2', '종료'))).status, 'end_acknowledged');
  assert.deepEqual(requests.filter(x => x.command === 11008).map(x => [x.room, x.call]),
    [['101', '10100'], ['102', '10200']]);
});

test('unknown creation remains tracked and never duplicates while discovery says occupied', async () => {
  const f = fixture({ failCreate: true, callableAfterCreate: 0 });
  assert.equal((await f.handle(message('101', '1'))).status, 'create_unconfirmed');
  assert.equal((await f.handle(message('101', '2'))).status, 'waiting_for_confirmation');
  await f.runTimer(60000);
  assert.equal(f.requests.filter(x => x.command === 11028).length, 1);
  f.setCallable(1);
  assert.equal((await f.handle(message('101', '3', '종료'))).status, 'absence_confirmed');
  assert.equal(f.timers.size, 0);
  assert.equal(f.handle.hasSessions(), false);
});

test('unknown role, invalid durations and unowned end never reach the VOX client', async () => {
  const handle = createVoiceRoomBot({ rooms, client: { ...client, _getCachedMemberType: () => undefined },
    createSession: () => assert.fail('network session must not start') });
  assert.equal((await handle(message('101', '1'))).status, 'bot_role_unverified');
  assert.equal((await handle(message('101', '2', '49 초과'))).status, 'invalid_command');
  assert.equal((await handle(message('101', '3', '종료'))).status, 'no_owned_call');
});

test('timed command sends the requested title and ends once at the requested time', async () => {
  const { handle, requests, timers, runTimer } = fixture();
  assert.equal((await handle(message('101', '1', '30분 조용한 공부방'))).status, 'create_acknowledged');
  assert.equal(requests.find(x => x.command === 11028).title, '조용한 공부방');
  await runTimer(1800000);
  assert.equal(requests.filter(x => x.command === 11008).length, 1);
  assert.equal(timers.size, 0);
});

test('automatic mode waits 48 hours and then one minute after a confirmed end', async () => {
  const { handle, requests, timers, runTimer } = fixture();
  await handle(message('101', '1', '!보룸자동 매일 공부방'));
  await runTimer(48 * 3600000);
  assert.equal(requests.filter(x => x.command === 11028).length, 1);
  await runTimer(60000);
  assert.deepEqual(requests.filter(x => x.command === 11028).map(x => x.title), ['매일 공부방', '매일 공부방']);
  await runTimer(48 * 3600000);
  assert.equal((await handle(message('101', '2', '종료'))).status, 'automatic_cancelled');
  assert.equal(timers.size, 0);
});

test('automatic mode retries a failed end and reopens only after confirmation', async () => {
  const f = fixture({ failEnd: true, callableAfterCreate: 0 });
  await f.handle(message('101', '1', '!보룸자동 재시도'));
  await f.runTimer(48 * 3600000);
  assert.equal(f.requests.filter(x => x.command === 11008).length, 1);
  await f.runTimer(60000);
  assert.equal(f.requests.filter(x => x.command === 11028).length, 1);
  f.setFailEnd(false);
  f.setCallable(1);
  await f.runTimer(60000);
  await f.runTimer(60000);
  assert.equal(f.requests.filter(x => x.command === 11028).length, 2);
  await f.handle.shutdown();
});

test('temporary heartbeat loss and an SDP error do not tear down an acknowledged call', async () => {
  const { handle, requests, peers } = fixture({ heartbeatTimeouts: 2, failMedia: true });
  assert.equal((await handle(message('101', '1'))).status, 'create_acknowledged');
  assert.equal(requests.filter(x => x.command === 11028).length, 1);
  assert.equal(requests.filter(x => x.command === 11015).length, 3);
  assert.equal(peers[0].closed, undefined);
  await handle.shutdown();
});

test('LOCO replacement preserves VOX and delays automatic reopen until the same account is ready', async () => {
  const { handle, requests, runTimer } = fixture();
  await handle(message('101', '1', '!보룸자동 지속 테스트'));
  assert.equal(handle.setClientReady(client, false), true);
  assert.equal(handle.setClientReady({ ...client, userId: '999' }, true), false);
  assert.equal(requests.filter(x => x.command === 11008).length, 0);
  await runTimer(48 * 3600000);
  await runTimer(60000);
  assert.equal(requests.filter(x => x.command === 11028).length, 1);
  assert.equal(handle.setClientReady({ ...client }, true), true);
  await runTimer(60000);
  assert.equal(requests.filter(x => x.command === 11028).length, 2);
  await handle.shutdown();
});

test('matching server end notification confirms expiry even when the end reply is absent', async () => {
  const { handle, requests, runTimer } = fixture({ endByPush: true });
  await handle(message('101', '1', '!보룸자동 서버 종료'));
  await runTimer(48 * 3600000);
  await runTimer(60000);
  assert.equal(requests.filter(x => x.command === 11028).length, 2);
  assert.equal(requests.filter(x => x.command === 11008).length, 1);
  await handle.shutdown();
});

test('shutdown closes both owned calls and skips a second shutdown', async () => {
  const { handle, requests, peers } = fixture();
  await Promise.all([handle(message('101', '1')), handle(message('102', '1'))]);
  await handle.shutdown();
  await handle.shutdown();
  assert.ok(peers.every(peer => peer.closed));
  assert.equal(requests.filter(request => request.command === 11008).length, 2);
});

test('an early confirmed server end retains automatic mode', async () => {
  const f = fixture();
  await f.handle(message('101','1','!보룸자동 조기 종료'));
  const session = f.sessions[0];
  session.connection.emit('push', { sequence: 10, command: 11007,
    body: { userId: long('31'), callId: session.callId, reason: 1 } });
  await tick();
  await f.runTimer(60000);
  assert.equal(f.requests.filter(x => x.command === 11028).length, 2);
  await f.handle.shutdown();
});

test('manual command can resume automatic mode during the reopen wait', async () => {
  const f=fixture();
  await f.handle(message('101','1','!보룸자동 이전 제목'));
  await f.runTimer(48*3600000);
  assert.equal((await f.handle(message('101','2','!보룸자동 새 제목'))).status,'create_acknowledged');
  assert.deepEqual(f.requests.filter(x=>x.command===11028).map(x=>x.title),['이전 제목','새 제목']);
  await f.handle.shutdown();
});

test('live policy save changes authorization without ending or replacing the call', async () => {
  const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
  const VoiceSettings=require('./VoiceSettings.cjs');
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'voice-live-policy-'));
  const f=fixture();
  try {
    await f.handle(message('101','1','!보룸자동 유지'));
    const settings=new VoiceSettings(directory);
    settings.handlers.set('a',{handle:f.handle,client});
    settings.save('a',[{roomId:'101',operatorIds:['32']}]);
    assert.equal(f.requests.filter(x=>x.command===11008).length,0);
    assert.equal(f.sessions[0].status,'active');
    assert.equal((await f.handle(message('101','2','종료','31'))).status,'forbidden');
    assert.equal((await f.handle(message('101','3','종료','32'))).status,'end_acknowledged');
    assert.equal(f.requests.filter(x=>x.command===11028).length,1);
  } finally { await f.handle.shutdown(); fs.rmSync(directory,{recursive:true,force:true}); }
});

test('removing a room keeps the current call but cancels its next automatic opening', async () => {
  const f=fixture();
  await f.handle(message('101','1','!보룸자동 유지'));
  f.handle.updateRooms([rooms[1]]);
  assert.equal(f.sessions[0].status,'active');
  assert.equal(f.requests.filter(x=>x.command===11008).length,0);
  await f.runTimer(48*3600000);
  assert.equal(f.timers.size,0);
  assert.equal(f.handle.hasSessions(),false);
});

test('policy updates retain duplicate suppression for unchanged rooms', async () => {
  const f=fixture();
  await f.handle(message('101','1'));
  f.handle.updateRooms(rooms);
  assert.equal((await f.handle(message('101','1'))).status,'duplicate');
  await f.handle.shutdown();
});

test('SDP bursts are acknowledged immediately and only the newest waiting SDP is applied', async () => {
  const f=fixture();
  await f.handle(message('101','1'));
  const session=f.sessions[0],peer=f.peers[0];
  let release; const applied=[];
  peer.setRemoteDescription=async description=>{
    applied.push(description.sdp);
    if(description.sdp==='burst-0')await new Promise(resolve=>{release=resolve});
  };
  for(let i=0;i<1000;i++)session.connection.emit('push',{sequence:i+100,command:11003,
    body:{userId:long('31'),callId:session.callId,sdp:{sdpType:2,sdp:'burst-'+i}}});
  assert.equal(f.replies.length,1001);
  assert.deepEqual(applied,['burst-0']);
  await session.heartbeatOnce();
  release();await tick();
  assert.deepEqual(applied,['burst-0','burst-999']);
  await f.handle.shutdown();
});

test('termination is processed even while SDP negotiation is stalled', async () => {
  const f=fixture();await f.handle(message('101','1','!보룸자동 바쁜 방'));
  const session=f.sessions[0];let release;
  f.peers[0].setRemoteDescription=()=>new Promise(resolve=>{release=resolve});
  session.connection.emit('push',{sequence:20,command:11003,
    body:{userId:long('31'),callId:session.callId,sdp:{sdpType:2,sdp:'slow'}}});
  session.connection.emit('push',{sequence:21,command:11007,
    body:{userId:long('31'),callId:session.callId,reason:1}});
  await tick();
  assert.equal(session.status,'ended');
  assert.equal(f.replies.at(-1).command,11007);
  await f.runTimer(60000);
  assert.equal(f.requests.filter(x=>x.command===11028).length,2);
  release();await f.handle.shutdown();
});

test('temporary loss of keepalive recovers the same call without terminating it', async () => {
  const f=fixture();
  await f.handle(message('101','1','!보룸자동 유지 복구'));
  f.sessions[0].markUncertain();
  await f.runTimer(60000);
  assert.equal(f.sessions[0].status,'active');
  assert.equal(f.requests.filter(x=>x.command===11008).length,0);
  assert.equal(f.requests.filter(x=>x.command===11028).length,1);
  assert.ok([...f.timers.values()].some(timer=>timer.delay===48*3600000-60000));
  await f.handle.shutdown();
});

test('a broken VOX socket reconnects to end the recorded call before reopening', async () => {
  const f=fixture();
  await f.handle(message('101','1','!보룸자동 연결 복구'));
  f.sessions[0].connection.socket={destroyed:true};
  f.sessions[0].markUncertain();
  await f.runTimer(60000);
  assert.equal(f.requests.filter(x=>x.command===11008).length,1);
  assert.equal(f.requests.filter(x=>x.command===11028).length,1);
  await f.runTimer(60000);
  assert.equal(f.requests.filter(x=>x.command===11028).length,2);
  await f.handle.shutdown();
});

test('a one-time command replacing an automatic wait does not start another loop', async () => {
  const f=fixture();
  await f.handle(message('101','1','!보룸자동 이전'));
  await f.runTimer(48*3600000);
  await f.handle(message('101','2','1 한 번만'));
  await f.runTimer(3600000);
  assert.equal(f.timers.size,0);
  assert.equal(f.requests.filter(x=>x.command===11028).length,2);
});
