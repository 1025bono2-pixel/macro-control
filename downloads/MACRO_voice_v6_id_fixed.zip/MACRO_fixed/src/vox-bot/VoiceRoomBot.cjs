'use strict';

const { createVoiceRoomCommands } = require('./VoiceRoomCommands.cjs');
const { VoxSession } = require('./VoxSession.js');

const userTypes = new Map([[1, 3], [4, 2], [2, 1]]);
const REOPEN_DELAY = 60000;

function createVoiceRoomBot({
  client, rooms, log = () => {}, createSession = context => new VoxSession(context),
  setTimer = setTimeout, clearTimer = clearTimeout, now = Date.now,
}) {
  const authorize = createVoiceRoomCommands({ rooms });
  const sessions = new Map();
  const pending = new Set();
  let stopping = false;
  let clientReady = true;

  function report(entry, action, status, details = {}) {
    const result = { action, status, ...details };
    log({ event: 'voice_room_command', roomId: entry.roomId, ...result });
    return result;
  }

  function cancelTimer(entry) {
    if (entry.timer != null) clearTimer(entry.timer);
    entry.timer = null;
  }

  function schedule(entry, delay, operation) {
    cancelTimer(entry);
    if (stopping) return;
    entry.timer = setTimer(() => {
      entry.timer = null;
      if (stopping || sessions.get(entry.roomId) !== entry) return;
      const task = Promise.resolve().then(operation).catch(() => report(entry, entry.action, 'operation_failed'));
      pending.add(task);
      void task.finally(() => pending.delete(task));
    }, delay);
    entry.timer?.unref?.();
  }

  function afterEnd(entry, repeat) {
    cancelTimer(entry);
    if ((entry.repeat || entry.reopenRequested) && repeat && !stopping && !entry.stopRequested && !entry.policyRemoved) {
      entry.reopenRequested = false;
      entry.session = null;
      entry.endAttempted = false;
      schedule(entry, REOPEN_DELAY, () => open(entry));
    } else sessions.delete(entry.roomId);
  }

  async function recover(entry) {
    if (stopping || sessions.get(entry.roomId) !== entry) return;
    if (entry.session?.callId && entry.session?.csId) {
      entry.busy = true;
      try {
        if (!entry.stopRequested && !entry.reopenRequested && now() < entry.dueAt && await entry.session.resume?.()) {
          schedule(entry, entry.dueAt - now(), () => end(entry, true));
          return report(entry, 'recover', 'connection_restored');
        }
      } finally { entry.busy = false; }
      return end(entry, !entry.stopRequested);
    }
    entry.busy = true;
    try {
      if (await entry.session?.confirmEnded()) {
        await entry.session.close();
        afterEnd(entry, !entry.stopRequested);
        return report(entry, 'recover', 'absence_confirmed');
      }
    } catch { /* Keep ownership until the room state can be verified. */ }
    finally { entry.busy = false; }
    schedule(entry, REOPEN_DELAY, () => recover(entry));
    return report(entry, 'recover', 'waiting_for_confirmation');
  }

  async function end(entry, repeat) {
    cancelTimer(entry);
    if (!entry.session) {
      sessions.delete(entry.roomId);
      return report(entry, 'end', 'automatic_cancelled');
    }
    if (!entry.session.callId || !entry.session.csId) return recover(entry);
    entry.busy = true;
    entry.endAttempted = true;
    try {
      const result = await entry.session.end();
      afterEnd(entry, repeat);
      return report(entry, 'end', result.status);
    } catch {
      entry.endAttempted = false;
      schedule(entry, REOPEN_DELAY, () => recover(entry));
      return report(entry, 'end', 'end_unconfirmed');
    } finally { entry.busy = false; }
  }

  async function open(entry) {
    if (!clientReady && entry.repeat) {
      schedule(entry, REOPEN_DELAY, () => open(entry));
      return report(entry, entry.action, 'waiting_for_kakao_connection');
    }
    entry.reopenRequested = false;
    entry.busy = true;
    try {
      await client._ensureMemberType(entry.roomId, client.userId);
      const userType = userTypes.get(client._getCachedMemberType(entry.roomId, client.userId));
      if (!userType || stopping || entry.stopRequested || entry.policyRemoved) {
        sessions.delete(entry.roomId);
        return report(entry, entry.action, userType ? 'automatic_cancelled' : 'bot_role_unverified');
      }
      const session = createSession({ userId: client.userId, oauthToken: client.oauthToken,
        deviceUuid: client.deviceUuid, userType });
      entry.session = session;
      session.on('connection_unconfirmed', () => {
        if (sessions.get(entry.roomId) !== entry || entry.session !== session) return;
        report(entry, entry.action, 'connection_unconfirmed');
        if (!entry.busy) schedule(entry, REOPEN_DELAY, () => recover(entry));
      });
      session.on('media_unconfirmed', () => report(entry, entry.action, 'media_unconfirmed'));
      session.once('ended', event => {
        if (sessions.get(entry.roomId) !== entry || entry.session !== session || entry.busy) return;
        afterEnd(entry, true);
        report(entry, 'end', 'ended_by_server', { reason: event?.reason });
      });
      const result = await session.create(entry.roomId, entry.title);
      entry.dueAt = now() + entry.durationMs;
      schedule(entry, entry.stopRequested ? 0 : entry.durationMs, () => end(entry, !entry.stopRequested));
      return report(entry, entry.action, result.status);
    } catch {
      const session = entry.session;
      if (session?.status === 'ended') {
        afterEnd(entry, true);
        return report(entry, entry.action, 'ended_during_create');
      }
      if (session && ['creating', 'active', 'uncertain'].includes(session.status)) {
        session.markUncertain();
        schedule(entry, REOPEN_DELAY, () => recover(entry));
        return report(entry, entry.action, 'create_unconfirmed');
      }
      await session?.close().catch(() => {});
      if (entry.repeat && !entry.stopRequested) {
        entry.session = null;
        schedule(entry, REOPEN_DELAY, () => open(entry));
      } else sessions.delete(entry.roomId);
      return report(entry, entry.action, 'create_failed');
    } finally { entry.busy = false; }
  }

  async function onMessage(event) {
    if (stopping) return;
    const command = authorize(event);
    if (!command) return;
    const roomId = String(event.room?.id ?? '');
    const { action, status } = command;
    if (status !== 'authorized') return report({ roomId }, action, status);
    const current = sessions.get(roomId);
    if (action === 'end') {
      if (!current) return report({ roomId }, action, 'no_owned_call');
      current.repeat = false;
      current.stopRequested = true;
      if (current.busy) return report(current, action, 'stop_requested');
      return end(current, false);
    }
    if (current) {
      if (current.busy) return report(current, action, 'busy');
      if (!current.session || ['uncertain', 'ended', 'ending'].includes(current.session.status)) {
        current.action = action;
        current.title = command.title;
        current.durationMs = command.durationMs;
        current.repeat = action === 'auto';
        current.stopRequested = false;
        current.reopenRequested = true;
        cancelTimer(current);
        return current.session ? recover(current) : open(current);
      }
      return report(current, action, 'already_tracked');
    }
    const entry = { roomId, action, title: command.title, durationMs: command.durationMs,
      repeat: action === 'auto', session: null, timer: null };
    sessions.set(roomId, entry);
    return open(entry);
  }

  onMessage.updateRooms = next => {
    authorize.updateRooms(next);
    const allowed = new Set(next.map(room => room.roomId));
    for (const entry of sessions.values()) {
      if (allowed.has(entry.roomId)) { entry.policyRemoved = false; continue; }
      entry.repeat = false;
      entry.reopenRequested = false;
      entry.policyRemoved = true;
      // Leave live calls running; only cancel future automatic creation.
      if (!entry.session && !entry.busy) {
        cancelTimer(entry);
        sessions.delete(entry.roomId);
      }
    }
  };
  onMessage.hasSessions = () => sessions.size > 0;
  onMessage.setClientReady = (next, ready) => {
    if (String(next.userId) !== String(client.userId)) return false;
    client = next;
    clientReady = ready;
    return true;
  };
  onMessage.shutdown = async () => {
    stopping = true;
    for (const entry of sessions.values()) cancelTimer(entry);
    await Promise.allSettled(pending);
    await Promise.all([...sessions.values()].map(async entry => {
      if (!entry.session) return;
      if (!entry.endAttempted && entry.session.callId && entry.session.csId) await end(entry, false);
      await entry.session?.close().catch(() => {});
    }));
    sessions.clear();
  };
  return onMessage;
}

module.exports = { createVoiceRoomBot };
