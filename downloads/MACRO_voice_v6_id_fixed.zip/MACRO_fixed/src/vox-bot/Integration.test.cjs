'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { setImmediate: tick } = require('node:timers/promises');
const { test } = require('node:test');

const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'macro-voice-test-'));
process.env.MACRO_DATA_DIR = directory;
const VoiceSettings = require('./VoiceSettings.cjs');
const { saveSession } = require('../services/KakaoSession');
const PanelServer = require('../panel/PanelServer');
const rooms = [{ roomId: '9007199254740993', operatorIds: ['31'] }];

test('saves allowlists per account and reloads them after a restart', () => {
  const settings = new VoiceSettings(directory);
  assert.throws(() => settings.save('a', [{ roomId: 9007199254740993, operatorIds: ['31'] }]), { status: 400 });
  settings.save('a', rooms);
  settings.save('b', [{ roomId: '17', operatorIds: ['34'] }]);
  assert.deepEqual(new VoiceSettings(directory).get('a').rooms, rooms);
  assert.deepEqual(new VoiceSettings(directory).get('missing').rooms, []);
});

test('saved Kakao session is replaced without storing the raw login response', () => {
  const file = path.join(directory, 'auth.json');
  const session = { userId: '31', accessToken: 'old-test-value', refreshToken: 'test-refresh', deviceUuid: 'test-device', raw: { secret: 'discard' } };
  saveSession(file, session);
  saveSession(file, { ...session, accessToken: 'new-test-value' });
  assert.deepEqual(JSON.parse(fs.readFileSync(file)), { userId: '31', accessToken: 'new-test-value', refreshToken: 'test-refresh', deviceUuid: 'test-device' });
  assert.ok(!fs.readdirSync(directory).some(file => file.endsWith('.tmp')));
});

test('global operators apply to each selected room and legacy settings remain readable', () => {
  const settings = new VoiceSettings(directory);
  const raw = settings.read();
  fs.writeFileSync(settings.file, JSON.stringify({ ...raw, legacy: rooms }));
  assert.deepEqual(settings.get('legacy').rooms, rooms);
  assert.deepEqual(settings.get('legacy').globalOperatorIds, []);
  const configured = [{ roomId: '11', operatorIds: ['21'] }, { roomId: '12', operatorIds: [] }];
  settings.save('global', configured, ['31']);
  const saved = new VoiceSettings(directory).get('global');
  assert.deepEqual(settings.effective(saved.rooms, saved.globalOperatorIds), [
    { roomId: '11', operatorIds: ['31', '21'] }, { roomId: '12', operatorIds: ['31'] },
  ]);
  assert.throws(() => settings.save('invalid', [], ['bad']), { status: 400 });
});

test('settings route rejects unowned bots and saves for authorized administrators', async () => {
  const manager = { voice: new VoiceSettings(directory), states: new Map(), findAccounts: () => [{ key: 'a' }] };
  const panel = new PanelServer(manager, {}, { token: 'test-token' });
  panel.session = q => q.session;
  panel.body = async q => q.body;
  panel.json = (_r, status, body) => ({ status, body });
  const url = new URL('http://localhost/api/voice-settings?account=a');
  const unauthorized = await panel.api({ method: 'GET' }, {}, url);
  assert.equal(unauthorized.status, 401);
  panel.requireLicense = () => {};
  const forbidden = await panel.api({ method: 'GET', session: { role: 'user', accounts: ['b'] } }, {}, url);
  assert.equal(forbidden.status, 403);
  for (const method of ['GET', 'PUT', 'POST']) {
    const assignedUser = await panel.api({ method, session: { role: 'user', accounts: ['a'] }, body: { rooms } }, {}, url);
    assert.equal(assignedUser.status, 403, `assigned users must not access voice settings via ${method}`);
  }
  const saved = await panel.api({ method: 'PUT', session: { role: 'admin' }, body: { rooms } }, {}, url);
  assert.equal(saved.status, 200);
  assert.deepEqual(saved.body.rooms, rooms);
});

test('a newly saved QR session replaces a running client that requires authentication', async () => {
  const BotManager = require('../BotManager');
  const manager = new BotManager();
  const authPath = path.join(directory, 'watch-auth.json');
  const session = { userId: '31', accessToken: 'expired-test-value', refreshToken: 'test-refresh', deviceUuid: 'test-device' };
  saveSession(authPath, session);
  const account = { key: 'watch-test', authPath, displayName: 'test' };
  manager.findAccounts = () => [account];
  manager.attachOptionalEvents = () => {};
  manager.syncRooms = async () => {};
  let clientCount = 0;
  manager.kf.mod = { createClient: () => {
    const client = new EventEmitter();
    const saved = JSON.parse(fs.readFileSync(authPath));
    Object.assign(client, { userId: saved.userId, oauthToken: saved.accessToken, refreshToken: saved.refreshToken });
    clientCount++;
    client.onReady = fn => client.on('ready', fn);
    client.onMessage = () => {};
    client.disconnect = () => {};
    client.refreshAuth = async () => { throw new Error('expired'); };
    client.connect = async () => {
      if (client.oauthToken !== 'fresh-test-value') {
        const error = Object.assign(new Error('expired'), { code: 'LOCO_AUTH_REJECTED' });
        client.emit('authRejected', error);
        throw error;
      }
      client.emit('ready');
    };
    return client;
  } };
  try {
    manager.startByKey(account.key);
    await tick();
    await tick();
    assert.equal(manager.states.get(account.key).authRequired, true);
    saveSession(authPath, { ...session, accessToken: 'fresh-test-value' });
    manager.authWatchers.get(account.key).listener();
    await tick();
    await tick();
    assert.equal(clientCount, 2);
    assert.equal(manager.states.get(account.key).online, true);
    assert.equal(manager.states.get(account.key).authRequired, false);
  } finally { await manager.stop(account.key); }
});

test('bundled KakaoForge skips auth-rejected reconnects and still retries transient disconnects', () => {
  const { mod } = require('../KakaoForgeLoader').loadKakaoForge();
  const client = new mod.KakaoForgeClient({ autoReconnect: true });
  try {
    client._scheduleReconnect(Object.assign(new Error('rejected'), { code: 'LOCO_AUTH_REJECTED' }));
    assert.ok(!client._reconnectTimer);
    client._authRejected = true;
    client._scheduleReconnect();
    assert.ok(!client._reconnectTimer);
    client._authRejected = false;
    client._scheduleReconnect(new Error('transient disconnect'));
    assert.ok(client._reconnectTimer);
  } finally { client._clearReconnectTimer(); }
});

test('panel-style stop detaches chat without shutting down tracked VOX sessions', async () => {
  const BotManager = require('../BotManager');
  const manager = new BotManager();
  const client = new EventEmitter();
  client.userId = '31';
  const events = [];
  client.disconnect = () => {
    assert.equal(manager.clients.has('main'), false);
    events.push('chat_disconnected');
  };
  manager.clients.set('main', client);
  manager.voice.handlers.set('main', {
    client, pending: new Set(), handle: {
      setClientReady: (_client, ready) => { events.push(ready ? 'chat_ready' : 'chat_offline'); return true; },
      shutdown: async () => { events.push('vox_ended'); },
    },
  });
  await manager.stop('main');
  assert.deepEqual(events, ['chat_offline', 'chat_disconnected']);
  assert.ok(manager.voice.handlers.has('main'));
  assert.equal(manager.states.get('main').online, false);
  await manager.stop('main', { preserveVoice: false });
  assert.deepEqual(events, ['chat_offline', 'chat_disconnected', 'vox_ended']);
});
