'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createVoiceRoomBot } = require('./VoiceRoomBot.cjs');
const { createVoiceRoomCommands } = require('./VoiceRoomCommands.cjs');
const { handleIdCommand, isIdCommand } = require('../IdCommand');

class VoiceSettings {
  constructor(directory) {
    this.file = path.join(directory, 'voice-bot.json');
    this.handlers = new Map();
    this.results = new Map();
  }
  read() {
    try { return JSON.parse(fs.readFileSync(this.file, 'utf8')); }
    catch (error) { if (error.code === 'ENOENT') return {}; throw error; }
  }
  get(account) {
    const settings = this.read();
    const saved = Object.hasOwn(settings, account) ? settings[account] : null;
    return { rooms: Array.isArray(saved) ? saved : saved?.rooms || [],
      globalOperatorIds: saved?.globalOperatorIds || [], lastResult: this.results.get(account) || null };
  }
  effective(rooms, globalOperatorIds) {
    return rooms.map(({ roomId, operatorIds }) => ({ roomId, operatorIds: [...new Set([...globalOperatorIds, ...operatorIds])] }));
  }
  async idCommand(account, client, chat, event) {
    if (!isIdCommand(event?.message?.text ?? event?.text)) return false;
    const settings = this.read();
    if (!Object.hasOwn(settings, account) || event?.room?.isOpenChat !== true) return false;
    // Lookup must also work before any operator ID has been registered.
    return handleIdCommand(client, chat, event);
  }
  save(account, input, globalOperatorIds = []) {
    let rooms;
    try {
      if (!Array.isArray(input) || input.length > 100 || !Array.isArray(globalOperatorIds) || globalOperatorIds.length > 100 || globalOperatorIds.some(x => typeof x !== 'string')) throw new Error();
      rooms = input.map(({ roomId, operatorIds }) => {
        if (typeof roomId !== 'string' || !Array.isArray(operatorIds) || operatorIds.length > 100 || operatorIds.some(x => typeof x !== 'string')) throw new Error();
        return { roomId, operatorIds: [...new Set(operatorIds)] };
      });
      if (globalOperatorIds.length) createVoiceRoomCommands({ rooms: [{ roomId: '1', operatorIds: globalOperatorIds }] });
      createVoiceRoomCommands({ rooms: this.effective(rooms, globalOperatorIds) });
    } catch { throw Object.assign(new Error('각 방의 ID와 운영자 ID를 올바르게 입력하세요.'), { status: 400 }); }
    const next = { ...this.read(), [account]: { rooms, globalOperatorIds: [...new Set(globalOperatorIds)] } };
    fs.writeFileSync(this.file + '.tmp', JSON.stringify(next, null, 2), { mode: 0o600 });
    fs.renameSync(this.file + '.tmp', this.file);
    this.handlers.get(account)?.handle.updateRooms(this.effective(rooms, globalOperatorIds));
    return this.get(account);
  }
  async incoming(account, client, event, archive) {
    let entry = this.handlers.get(account);
    if (entry && entry.client !== client) {
      await this.updateClient(account, client, true);
      entry = this.handlers.get(account);
    }
    if (!entry) {
      const { rooms, globalOperatorIds } = this.get(account);
      if (!rooms.length) return;
      const handle = createVoiceRoomBot({ client, rooms: this.effective(rooms, globalOperatorIds), log: result => {
        const status = { ...result, at: new Date().toISOString() };
        this.results.set(account, status);
        archive.log('voice', status);
      } });
      entry = { client, handle, pending: new Set() };
      this.handlers.set(account, entry);
    }
    if (entry.stopping) return;
    const operation = entry.handle(event);
    entry.pending.add(operation);
    try { await operation; } finally { entry.pending.delete(operation); }
  }
  async updateClient(account, client, ready) {
    const entry = this.handlers.get(account);
    if (!entry || (!ready && entry.client !== client)) return;
    if (entry.handle.setClientReady(client, ready)) entry.client = client;
    else await this.stop(account);
  }
  async stop(account) {
    const entry = this.handlers.get(account);
    if (!entry) return;
    if (!entry.stopping) entry.stopping = (async () => {
      await Promise.allSettled(entry.pending);
      await entry.handle.shutdown();
      if (this.handlers.get(account) === entry) this.handlers.delete(account);
    })();
    await entry.stopping;
  }
}
module.exports = VoiceSettings;
