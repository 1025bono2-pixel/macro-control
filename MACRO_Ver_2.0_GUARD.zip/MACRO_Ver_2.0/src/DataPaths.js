const fs=require('fs'),path=require('path'),os=require('os');
const ROOT=process.env.MACRO_DATA_DIR||path.join(process.env.APPDATA||path.join(os.homedir(),'.macro'),'MACRO');
for(const p of ['accounts','system','uploads'])fs.mkdirSync(path.join(ROOT,p),{recursive:true});
module.exports={ROOT,ACCOUNTS:path.join(ROOT,'accounts'),SYSTEM:path.join(ROOT,'system'),UPLOADS:path.join(ROOT,'uploads')};
