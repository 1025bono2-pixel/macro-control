try {
  const { mod, loadedFrom } = require("./KakaoForgeLoader").loadKakaoForge();
  console.log("[OK] KakaoForge:", loadedFrom);
  console.log("[OK] createClient:", typeof mod.createClient === "function");
  console.log("[OK] createAuthByQR:", typeof mod.createAuthByQR === "function");
} catch (e) {
  console.error("[FAIL]", e.message);
  process.exitCode = 1;
}
