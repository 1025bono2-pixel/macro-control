const BotManager=require("./BotManager");const MacroEngine=require("./macro/MacroEngine");const PanelServer=require("./panel/PanelServer");
try{const manager=new BotManager();const engine=new MacroEngine(manager);manager.startAll();engine.reload();new PanelServer(manager,engine).start();}catch(e){console.error("\n[MACRO START ERROR]\n"+e.message+"\n");process.exitCode=1;}
