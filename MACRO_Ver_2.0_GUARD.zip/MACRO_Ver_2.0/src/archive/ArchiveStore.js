const fs=require("fs"), path=require("path");
const ROOT=require("../DataPaths").ACCOUNTS;
const safe=v=>String(v??"unknown").replace(/[^a-zA-Z0-9._-]/g,"_");
const day=(ts=Date.now())=>new Date(ts).toISOString().slice(0,10);
function json(v){return JSON.stringify(v,(_,x)=>{if(typeof x==="bigint")return x.toString();if(x&&typeof x==="object"&&typeof x.toString==="function"&&/Long/.test(x.constructor?.name||""))return x.toString();return x;});}
function readJson(p,d={}){try{return JSON.parse(fs.readFileSync(p,"utf8"));}catch{return d;}}
function readJsonl(p,limit=200){try{const lines=fs.readFileSync(p,"utf8").trim().split(/\r?\n/).filter(Boolean);return lines.slice(-limit).map(x=>{try{return JSON.parse(x)}catch{return null}}).filter(Boolean)}catch{return[]}}
class ArchiveStore{
 constructor(account){this.base=path.join(ROOT,safe(account));}
 roomId(chat,msg){const v=chat?.id??chat?.channelId??msg?.chatId??msg?.raw?.chatLog?.chatId??"unknown";return typeof v?.toString==="function"?v.toString():String(v);}
 append(roomId,folder,data){const dir=path.join(this.base,"rooms",safe(roomId),folder);fs.mkdirSync(dir,{recursive:true});fs.appendFileSync(path.join(dir,`${day()}.jsonl`),json({savedAt:new Date().toISOString(),...data})+"\n");}
 incoming(chat,msg){const roomId=this.roomId(chat,msg);this.append(roomId,"messages",{direction:"RECEIVED",roomId,messageId:String(msg?.id??msg?.logId??msg?.raw?.chatLog?.logId??""),senderId:String(msg?.sender?.id??msg?.senderId??""),senderName:String(msg?.sender?.name??msg?.sender?.nickname??""),text:msg?.message?.text??msg?.text??"",messageType:msg?.raw?.chatLog?.type??msg?.type??null,attachment:msg?.raw?.chatLog?.attachment??msg?.message?.attachment??null});}
 outgoing(roomId,kind,data={}){this.append(roomId,"messages",{direction:"SENT",roomId:String(roomId),kind,...data});}
 event(roomId,name,payload){this.append(roomId,"events",{event:name,payload});}
 log(name,payload){const dir=path.join(this.base,"logs");fs.mkdirSync(dir,{recursive:true});fs.appendFileSync(path.join(dir,`${safe(name)}.jsonl`),json({at:new Date().toISOString(),...payload})+"\n");}
 summary(){const root=path.join(this.base,"rooms");if(!fs.existsSync(root))return{rooms:[],totals:{received:0,sent:0,total:0}};let received=0,sent=0;const rooms=[];for(const d of fs.readdirSync(root,{withFileTypes:true}).filter(x=>x.isDirectory())){const rp=path.join(root,d.name),meta=readJson(path.join(rp,"room.json"),{roomId:d.name,roomName:d.name}),mp=path.join(rp,"messages");let rr=0,ss=0,latest=[];if(fs.existsSync(mp)){for(const f of fs.readdirSync(mp).filter(x=>x.endsWith('.jsonl')).sort()){const rows=readJsonl(path.join(mp,f),100000);for(const x of rows){if(x.direction==='RECEIVED')rr++;else if(x.direction==='SENT')ss++;}latest=latest.concat(rows).slice(-100);}}received+=rr;sent+=ss;rooms.push({...meta,received:rr,sent:ss,total:rr+ss,latest:latest.slice(-50).reverse()});}rooms.sort((a,b)=>String(a.roomName).localeCompare(String(b.roomName),'ko'));return{rooms,totals:{received,sent,total:received+sent}};}
}
module.exports=ArchiveStore;
