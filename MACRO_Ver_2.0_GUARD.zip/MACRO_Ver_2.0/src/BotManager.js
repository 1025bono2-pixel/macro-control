const fs=require('fs'),path=require('path');const ArchiveStore=require('./archive/ArchiveStore');const {loadKakaoForge}=require('./KakaoForgeLoader');
const ACCOUNTS=require('./DataPaths').ACCOUNTS;
const readJson=(p,d={})=>{try{return JSON.parse(fs.readFileSync(p,'utf8'));}catch{return d;}};const writeJson=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2));};
class BotManager{
 constructor(){this.clients=new Map();this.archives=new Map();this.states=new Map();this.kf=loadKakaoForge();this.engine=null;}
 findAccounts(){fs.mkdirSync(ACCOUNTS,{recursive:true});return fs.readdirSync(ACCOUNTS,{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>{const base=path.join(ACCOUNTS,x.name),meta=readJson(path.join(base,'account.json'),{});return{key:x.name,displayName:meta.displayName||x.name,authPath:path.join(base,'auth.json')}}).filter(x=>fs.existsSync(x.authPath));}
 status(){return this.findAccounts().map(a=>({key:a.key,displayName:a.displayName,...(this.states.get(a.key)||{online:false})}));}
 rooms(key){const base=path.join(ACCOUNTS,key,'rooms');if(!fs.existsSync(base))return[];return fs.readdirSync(base,{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>readJson(path.join(base,x.name,'room.json'),{roomId:x.name,roomName:x.name})).sort((a,b)=>String(a.roomName).localeCompare(String(b.roomName),'ko'));}

 // Synchronize room metadata from supported KakaoForge chat-list APIs/caches.
 // Some builds expose only event-driven rooms; never claim a complete list then.
 async syncRooms(key){
  const client=this.clients.get(key);
  if(!client)throw new Error('봇이 실행 중이지 않습니다.');
  const archive=this.archives.get(key);
  const chat=client.chat;
  let source=null,method=null;
  const candidates=[
   [chat,'getChatList'],[chat,'getChats'],[chat,'getRooms'],[chat,'listChats'],
   [client,'getChatList'],[client,'getChats'],[client,'getRooms'],[client,'listChats']
  ];
  for(const [obj,name] of candidates){
   if(typeof obj?.[name]!=='function')continue;
   try{
    const result=await obj[name]();
    if(result!=null){source=result;method=name;break;}
   }catch(e){console.warn(`[${key}] 방 목록 ${name} 실패: ${e.message}`);}
  }
  if(source==null){
   for(const [obj,name] of [[chat,'rooms'],[chat,'chats'],[chat,'channels'],[client,'rooms'],[client,'chats'],[client,'channels']]){
    if(obj?.[name]!=null){source=obj[name];method=`cache:${name}`;break;}
   }
  }
  const unwrap=v=>{
   if(v instanceof Map)return [...v.values()];
   if(Array.isArray(v))return v;
   if(v&&typeof v==='object'){
    for(const name of ['chatRooms','chatList','rooms','chats','channels','list','items','data']){
     if(v[name]!=null&&v[name]!==v){const x=unwrap(v[name]);if(x.length)return x;}
    }
    if(Object.values(v).some(x=>x&&typeof x==='object'))return Object.values(v);
   }
   return [];
  };
  let count=0;
  for(const room of unwrap(source)){
   const obj=room?.room??room?.chatRoom??room?.channel??room;
   const id=obj?.id??obj?.roomId??obj?.chatId??obj?.channelId??obj?.c;
   const name=obj?.name??obj?.roomName??obj?.title??obj?.channelName??obj?.displayName;
   if(id==null||!name)continue;
   const roomId=String(id),roomName=String(name);
   if(!/^\d+$/.test(roomId))continue;
   const file=path.join(ACCOUNTS,key,'rooms',roomId,'room.json');
   writeJson(file,{roomId,roomName,syncedAt:new Date().toISOString()});count++;
  }
  const info={count,source:method||'not-supported',complete:!!method&&count>0,stored:this.rooms(key).length};
  this.states.set(key,{...(this.states.get(key)||{}),roomSync:info});
  archive?.log('connection',{state:'ROOM_SYNC',...info});
  console.log(`[${key}] 방 동기화: ${count}개 / ${info.source}`);
  return info;
 }
 rememberRoom(key,chat,msg){const archive=this.archives.get(key);if(!archive)return;const roomId=archive.roomId(chat,msg);const roomName=String(msg?.room?.name??chat?.name??chat?.title??chat?.channelName??msg?.roomName??msg?.raw?.chatLog?.roomName??roomId);const p=path.join(ACCOUNTS,key,'rooms',roomId.replace(/[^a-zA-Z0-9._-]/g,'_'),'room.json');writeJson(p,{roomId,roomName,lastSeenAt:new Date().toISOString()});return{roomId,roomName};}
 async addAccountByQR(key,displayName){const dir=path.join(ACCOUNTS,key),authPath=path.join(dir,'auth.json');if(fs.existsSync(authPath))throw new Error('이미 존재하는 봇 계정입니다.');fs.mkdirSync(dir,{recursive:true});writeJson(path.join(dir,'account.json'),{displayName:displayName||key,createdAt:new Date().toISOString()});if(typeof this.kf.mod.createAuthByQR!=='function')throw new Error('createAuthByQR API가 없습니다.');console.log(`\n[MACRO] ${displayName||key} QR 인증을 시작합니다.`);await this.kf.mod.createAuthByQR({authPath});console.log(`[MACRO] ${displayName||key} 인증 완료`);this.startByKey(key);}
 rename(key,displayName){const p=path.join(ACCOUNTS,key,'account.json'),m=readJson(p,{});m.displayName=String(displayName||key);writeJson(p,m);}
 startAll(){console.log(`[MACRO] KakaoForge: ${this.kf.loadedFrom}`);for(const x of this.findAccounts())this.startAccount(x);}
 startByKey(key){const a=this.findAccounts().find(x=>x.key===key);if(!a)throw new Error('계정을 찾을 수 없습니다.');this.startAccount(a);}
 startAccount({key,authPath}){if(this.clients.has(key))return;const archive=new ArchiveStore(key);this.archives.set(key,archive);this.states.set(key,{online:false});const client=this.kf.mod.createClient({authPath,debug:false,autoConnect:true,autoReconnect:true,sendIntervalMs:400});this.clients.set(key,client);client.onReady(()=>{const s={online:true,userId:String(client.userId),connectedAt:new Date().toISOString()};this.states.set(key,s);archive.log('connection',{state:'READY',...s});console.log(`[${key}] ONLINE / ${s.userId}`);this.syncRooms(key).catch(e=>console.warn(`[${key}] 방 동기화 실패: ${e.message}`));});client.onMessage(async(chat,msg)=>{try{const r=this.rememberRoom(key,chat,msg);archive.incoming(chat,msg);const text=msg?.message?.text??msg?.text??'';const senderId=String(msg?.sender?.id??msg?.senderId??'');if(r&&this.engine)await this.engine.onIncoming(key,r.roomId,text,senderId);}catch(e){archive.log('errors',{message:e.message});}});}
 async stop(key){const c=this.clients.get(key);if(!c)return;for(const fn of ['disconnect','close','stop']){if(typeof c[fn]==='function'){try{await c[fn]();}catch{}break;}}this.clients.delete(key);this.states.set(key,{online:false});this.archives.get(key)?.log('connection',{state:'STOPPED'});}
 async restart(key){await this.stop(key);this.startByKey(key);}
 logMacroError(item,e){console.error(`[MACRO:${item.name}]`,e.message);this.archives.get(item.accountKey)?.log('macro',{macroId:item.id,name:item.name,status:'ERROR',error:e.message});}
}
module.exports=BotManager;
