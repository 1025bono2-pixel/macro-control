const fs = require("fs");
const path = require("path");

function candidates() {
  return [
    process.env.KAKAO_FORGE_PATH,
    path.join(__dirname, "..", "vendor", "KakaoForge", "dist"),
    path.join(__dirname, "..", "vendor", "KakaoForge"),
    path.join(process.cwd(), "vendor", "KakaoForge", "dist"),
    path.join(process.cwd(), "vendor", "KakaoForge")
  ].filter(Boolean);
}

function loadKakaoForge() {
  const tried = [];
  for (const p of candidates()) {
    tried.push(p);
    if (!fs.existsSync(p)) continue;
    try {
      const mod = require(p);
      if (mod && typeof mod.createClient === "function") return { mod, loadedFrom: p };
    } catch (e) {
      tried.push(`${p} -> ${e.message}`);
    }
  }
  const error = new Error(
    "KakaoForge를 찾지 못했습니다. 기존 프로젝트의 vendor\\KakaoForge 폴더를 MACRO\\vendor\\KakaoForge 로 복사하세요.\n" +
    "확인한 경로:\n- " + tried.join("\n- ")
  );
  error.code = "KAKAOFORGE_NOT_FOUND";
  throw error;
}
module.exports = { loadKakaoForge };
