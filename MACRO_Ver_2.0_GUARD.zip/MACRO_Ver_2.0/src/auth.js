const fs = require("fs");
const path = require("path");
const readline = require("readline");
const { mod, loadedFrom } = require("./KakaoForgeLoader").loadKakaoForge();
const { createAuthByQR } = mod;
const ACCOUNTS = path.join(__dirname, "..", "data", "accounts");
const ask = q => new Promise(r => { const rl=readline.createInterface({input:process.stdin,output:process.stdout}); rl.question(q,a=>{rl.close();r(a.trim());}); });
const safe = s => s.replace(/[^a-zA-Z0-9_-]/g, "");
(async()=>{
  if (typeof createAuthByQR !== "function") throw new Error("현재 KakaoForge에 createAuthByQR이 없습니다.");
  console.log("[MACRO] KakaoForge:", loadedFrom);
  fs.mkdirSync(ACCOUNTS,{recursive:true});
  const alias=safe(await ask("계정 별칭 (예: main): "));
  if(!alias) throw new Error("사용할 수 없는 별칭입니다.");
  const dir=path.join(ACCOUNTS,alias), authPath=path.join(dir,"auth.json"); fs.mkdirSync(dir,{recursive:true});
  if(fs.existsSync(authPath)){ const y=(await ask("기존 인증을 덮어쓸까요? (y/N): ")).toLowerCase(); if(y!=="y") return; }
  console.log(`[${alias}] QR 인증 시작`);
  await createAuthByQR({authPath});
  console.log(`[${alias}] 인증 완료: ${authPath}`);
})().catch(e=>{console.error("[AUTH ERROR]",e);process.exitCode=1;});
