@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "vendor\KakaoForge\dist" (
  echo.
  echo [MACRO] vendor\KakaoForge\dist 를 찾지 못했습니다.
  echo 기존 프로젝트의 vendor\KakaoForge 폴더를 이 프로젝트의 vendor 폴더에 복사하세요.
  echo.
  pause
  exit /b 1
)
if "%MACRO_TOKEN%"=="" set "MACRO_TOKEN=change-me-now"
node src\index.js
pause
