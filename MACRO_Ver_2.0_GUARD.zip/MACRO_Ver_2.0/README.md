# MACRO Ver 2.0 — 배포용 소스 프로젝트

## 구현 상태
- 도움말/경고 문구, 봇 추가 입력 예시, 저작권 표기 변경.
- 총괄 대시보드에서 봇 시작/종료/재시작 버튼 제공. Host가 실행 중일 때만 제어 가능.
- Windows Electron 설치 프로그램 생성 설정(`electron-builder`) 추가.
- Android Gradle 앱 프로젝트 제공. APK는 Android Studio에서 빌드 필요.
- 회원/봇 데이터는 기존과 같이 `%APPDATA%\MACRO`에 보관. **데이터 폴더를 삭제하지 마세요.**

## 총괄 PC Host
1. 기존 프로젝트의 `vendor/KakaoForge`를 이 프로젝트 `vendor/KakaoForge`에 복사합니다.
2. `npm install`
3. `set MACRO_TOKEN=강력한_관리자_비밀번호`
4. `npm start`

**Host 자체 CMD 창은 켜져 있어야 합니다.** 관리자 화면의 봇 ON/OFF는 Host 안에서 실행되는 개별 봇만 제어합니다.

## Windows 설치 프로그램
Windows PC에 Node.js 설치 후 `apps/windows`에서:
```
npm install
npm run dist
```
완성 시 `apps/windows/dist/` 아래 Setup.exe가 생성됩니다.

## Android APK
Android Studio에서 `apps/android` 프로젝트를 열고 Android SDK 35 / Gradle 환경을 구성한 뒤 **Build > Build APK(s)**를 실행합니다.

## 외부 배포의 전제 조건
현재 앱은 사용자가 지정한 HTTPS 서버 URL을 여는 클라이언트입니다. **서버가 인터넷에 배포되거나 안전한 HTTPS 프록시/릴레이에 연결되지 않으면 외부에서 동작하지 않습니다.** 이번 패키지에 공개 서버 배포/운영, DNS, 인증서 발급은 포함되지 않습니다. 8787 포트를 인터넷에 직접 노출하지 마세요.

## 주의
KakaoForge/LOCO는 카카오 공식 메시지 API가 아니며, 비공식 자동화 및 유상 배포는 이용 제한 위험이 있습니다. 사용 전에 공식 운영정책을 확인하세요.
