package com.macro.app;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.webkit.*;import android.widget.*;
public class MainActivity extends Activity{
 WebView web; ValueCallback<Uri[]> files; static final int PICK=42;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(com.macro.app.R.layout.activity_main);web=findViewById(R.id.web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams p){files=cb;try{startActivityForResult(p.createIntent(),PICK);}catch(Exception e){files=null;return false;}return true;}});String url=getPreferences(0).getString("server","");if(url.isEmpty())ask();else web.loadUrl(url);}
 void ask(){final EditText e=new EditText(this);e.setHint("https://macro.example.com");new AlertDialog.Builder(this).setTitle("MACRO 서버 주소").setMessage("관리자가 알려준 HTTPS 주소를 입력하세요.").setView(e).setCancelable(false).setPositiveButton("연결",(d,w)->{String u=e.getText().toString().trim();if(!u.startsWith("https://")){Toast.makeText(this,"HTTPS 주소를 입력하세요.",Toast.LENGTH_LONG).show();ask();return;}getPreferences(0).edit().putString("server",u).apply();web.loadUrl(u);}).show();}
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&files!=null){files.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));files=null;}}
 public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
